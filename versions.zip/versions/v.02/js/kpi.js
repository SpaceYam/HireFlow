
"use strict";

window.KPI = (() => {
  const fields = [
    ["전체 지원자 수", "applicants"],
    ["서류 합격자 수", "passed"],
    ["면접 대상자 수", "interviews"],
    ["최종 합격자 수", "hired"],
    ["오퍼 발송 수", "offers"],
    ["오퍼 수락 수", "accepted"]
  ];

  function percentage(a, b) {
    return b > 0
      ? (a / b * 100).toFixed(1) + "%"
      : "-";
  }

  function calculate(data) {
    const days = data.start && data.end
      ? Math.round(
          (
            new Date(data.end + "T00:00:00") -
            new Date(data.start + "T00:00:00")
          ) / 86400000
        )
      : null;

    return [
      {
        title: "서류 합격률",
        value: percentage(data.passed, data.applicants),
        formula: "서류 합격자 ÷ 전체 지원자 × 100"
      },
      {
        title: "면접 전환율",
        value: percentage(data.interviews, data.passed),
        formula: "면접 대상자 ÷ 서류 합격자 × 100"
      },
      {
        title: "최종 합격률",
        value: percentage(data.hired, data.applicants),
        formula: "최종 합격자 ÷ 전체 지원자 × 100"
      },
      {
        title: "오퍼 수락률",
        value: percentage(data.accepted, data.offers),
        formula: "오퍼 수락자 ÷ 오퍼 발송자 × 100"
      },
      {
        title: "채용 소요일",
        value: days === null ? "-" : days + "일",
        formula: "입사일 - 채용 시작일"
      }
    ];
  }

  function result(data) {
    return `
      <div class="stats-grid">
        ${calculate(data).map(item => `
          <article class="card kpi-card">
            <span class="stat-label">${item.title}</span>
            <div class="stat-value">${item.value}</div>
            <p class="muted">${item.formula}</p>
          </article>
        `).join("")}
      </div>
    `;
  }

  function page() {
    const data = DB.get("kpi", {});

    return `
      <section class="page-header">
        <h1>채용 KPI 분석</h1>
        <p>채용 데이터를 입력하고 전형별 전환율을 분석합니다.</p>
      </section>

      <section class="card">
        <h2>채용 데이터 입력</h2>

        <div class="form-grid">
          ${fields.map(([label, key]) => `
            <label>
              ${label}

              <input
                type="number"
                min="0"
                step="1"
                data-kpi="${key}"
                value="${data[key] ?? 0}"
              >
            </label>
          `).join("")}

          <label>
            채용 시작일
            <input
              type="date"
              data-kpi="start"
              value="${data.start || ""}"
            >
          </label>

          <label>
            입사일
            <input
              type="date"
              data-kpi="end"
              value="${data.end || ""}"
            >
          </label>
        </div>

        <button class="btn" id="calculate-kpi">
          KPI 계산하기
        </button>
      </section>

      <section id="kpi-results">
        ${result(data)}
      </section>

      <section class="card">
        <h2>KPI 산출 기준</h2>

        <p>서류 합격률: 서류 합격자 ÷ 전체 지원자</p>
        <p>면접 전환율: 면접 대상자 ÷ 서류 합격자</p>
        <p>최종 합격률: 최종 합격자 ÷ 전체 지원자</p>
        <p>오퍼 수락률: 오퍼 수락자 ÷ 오퍼 발송자</p>
        <p>채용 소요일: 입사일 - 채용 시작일</p>

        <div class="guide-box">
          모든 지표는 동일한 채용 코호트와 동일한 집계 기준을
          적용해야 의미 있는 비교가 가능합니다.
          오퍼 수락률은 최종 합격자 수와 별도로 관리합니다.
        </div>
      </section>
    `;
  }

  function bind() {
    document.getElementById("calculate-kpi")
      ?.addEventListener("click", () => {
        const data = {};

        document.querySelectorAll("[data-kpi]")
          .forEach(input => {
            data[input.dataset.kpi] = input.type === "number"
              ? Number(input.value)
              : input.value;
          });

        const valid = fields.every(([, key]) => (
          Number.isInteger(data[key]) && data[key] >= 0
        ));

        if (!valid) {
          alert("모든 수치는 0 이상의 정수로 입력하세요.");
          return;
        }

        if (
          data.passed > data.applicants ||
          data.interviews > data.passed ||
          data.hired > data.interviews ||
          data.accepted > data.offers
        ) {
          alert("채용 단계별 인원수를 확인하세요.");
          return;
        }

        if (
          data.start &&
          data.end &&
          data.end < data.start
        ) {
          alert("입사일이 채용 시작일보다 빠릅니다.");
          return;
        }

        if (DB.set("kpi", data)) {
          document.getElementById("kpi-results").innerHTML =
            result(data);
        }
      });
  }

  return {
    page,
    bind
  };
})();
