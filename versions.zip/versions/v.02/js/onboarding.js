
"use strict";

window.Onboarding = (() => {
  function page() {
    const list = DB.get("onboarding");

    return `
      <section class="page-header">
        <h1>온보딩 관리</h1>
        <p>신규 입사자의 조직 적응과 초기 성과를 관리합니다.</p>
      </section>

      <section class="card">
        <div class="section-header">
          <h2>입사자 목록</h2>

          <button class="btn" id="add-onboarding">
            + 입사자 등록
          </button>
        </div>

        ${list.map(person => {
          const completed = ["d30", "d60", "d90"]
            .filter(key => person[key]).length;

          return `
            <article class="onboard-item">
              <div class="section-header">
                <div>
                  <h3>${DB.esc(person.name)}</h3>
                  <p>
                    ${DB.esc(person.job)} /
                    입사일 ${DB.esc(person.date)}
                  </p>
                  <p>멘토: ${DB.esc(person.mentor || "-")}</p>
                </div>

                <span class="tag">
                  ${Math.round(completed / 3 * 100)}% 완료
                </span>
              </div>

              <div class="progress-track">
                <div
                  class="progress-bar"
                  style="width:${completed / 3 * 100}%"
                ></div>
              </div>

              ${[
                ["d30", "30일 목표"],
                ["d60", "60일 목표"],
                ["d90", "90일 목표"]
              ].map(([key, label]) => `
                <label class="check-item">
                  <input
                    type="checkbox"
                    data-person="${person.id}"
                    data-day="${key}"
                    ${person[key] ? "checked" : ""}
                  >
                  ${label}
                </label>
              `).join("")}

              <p>${DB.esc(person.goal || "")}</p>

              <button
                class="btn secondary"
                data-onboarding-detail="${person.id}"
              >
                상세 정보
              </button>
            </article>
          `;
        }).join("") || "<p>등록된 입사자가 없습니다.</p>"}
      </section>
    `;
  }

  function add() {
    DB.modal(`
      <h2>신규 입사자 등록</h2>

      <form id="onboarding-form">
        <div class="form-grid">
          <label>
            이름
            <input name="name" required>
          </label>

          <label>
            직무
            <input name="job" required>
          </label>

          <label>
            입사일
            <input name="date" type="date" required>
          </label>

          <label>
            담당 멘토
            <input name="mentor">
          </label>
        </div>

        <label>
          30·60·90일 목표
          <textarea name="goal" rows="5"></textarea>
        </label>

        <button class="btn" type="submit">저장하기</button>
      </form>
    `);

    document.getElementById("onboarding-form").onsubmit = event => {
      event.preventDefault();

      const form = new FormData(event.target);
      const person = {
        id: DB.id(),
        name: form.get("name"),
        job: form.get("job"),
        date: form.get("date"),
        mentor: form.get("mentor"),
        goal: form.get("goal"),
        d30: false,
        d60: false,
        d90: false
      };

      const list = DB.get("onboarding");
      list.push(person);

      if (DB.set("onboarding", list)) {
        DB.close();
        App.render();
      }
    };
  }

  function detail(id) {
    const person = DB.get("onboarding")
      .find(item => item.id === id);

    if (!person) return;

    DB.modal(`
      <h2>${DB.esc(person.name)} 온보딩 상세</h2>

      <p>직무: ${DB.esc(person.job)}</p>
      <p>입사일: ${DB.esc(person.date)}</p>
      <p>멘토: ${DB.esc(person.mentor)}</p>

      <h3>성장 목표</h3>
      <div class="guide-box">
        ${DB.esc(person.goal).replace(/\n/g, "<br>")}
      </div>

      <h3>진행 현황</h3>
      <p>30일: ${person.d30 ? "완료" : "진행 중"}</p>
      <p>60일: ${person.d60 ? "완료" : "진행 중"}</p>
      <p>90일: ${person.d90 ? "완료" : "진행 중"}</p>
    `);
  }

  function bind() {
    document.getElementById("add-onboarding")
      ?.addEventListener("click", add);

    document.querySelectorAll("[data-person]")
      .forEach(input => {
        input.onchange = () => {
          const list = DB.get("onboarding");

          const person = list.find(
            item => item.id === input.dataset.person
          );

          if (!person) return;

          person[input.dataset.day] = input.checked;

          DB.set("onboarding", list);
          App.render();
        };
      });

    document.querySelectorAll("[data-onboarding-detail]")
      .forEach(button => {
        button.onclick = () => detail(
          button.dataset.onboardingDetail
        );
      });
  }

  return {
    page,
    bind
  };
})();
