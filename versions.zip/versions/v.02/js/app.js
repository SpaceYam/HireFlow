
"use strict";

window.App = (() => {
  const routes = {
    "/": dashboard,
    "/documents": () => Docs.catalog(),
    "/calendar": () => CalendarTool.page(),
    "/kpi": () => KPI.page(),
    "/applicants": () => Applicants.page(),
    "/onboarding": () => Onboarding.page(),
    "/backup": () => Backup.page(),
    "/trends": trends
  };

  HF.steps.forEach(step => {
    routes["/" + step.id] = () => Process.page(step.id);
  });

  function dashboard() {
    const applicants = DB.get("applicants");
    const events = DB.get("calendar");
    const onboarding = DB.get("onboarding");

    const active = applicants.filter(person =>
      !["합격", "불합격"].includes(person.stage)
    ).length;

    const todayEvents = events.filter(
      event => event.date === DB.today()
    );

    return `
      <section class="page-header">
        <span class="tag">HR MANAGEMENT WORKSPACE</span>
        <h1>HR Dashboard</h1>
        <p>채용 현황과 인재 확보 업무를 통합 관리합니다.</p>
      </section>

      <section class="stats-grid">
        <article class="card">
          <span class="stat-label">전체 지원자</span>
          <div class="stat-value">${applicants.length}</div>
        </article>

        <article class="card">
          <span class="stat-label">진행 중 지원자</span>
          <div class="stat-value">${active}</div>
        </article>

        <article class="card">
          <span class="stat-label">전체 채용 일정</span>
          <div class="stat-value">${events.length}</div>
        </article>

        <article class="card">
          <span class="stat-label">온보딩 대상자</span>
          <div class="stat-value">${onboarding.length}</div>
        </article>
      </section>

      <section class="card">
        <h2>오늘의 채용 일정</h2>

        ${todayEvents.map(event => `
          <div class="event-row">
            <strong>${DB.esc(event.title)}</strong>
            <span>${DB.esc(event.type)}</span>
          </div>
        `).join("") || "<p>오늘 예정된 일정이 없습니다.</p>"}

        <a href="#/calendar" class="btn secondary">
          캘린더 열기
        </a>
      </section>

      <section>
        <h2>채용 프로세스</h2>

        <div class="process-grid">
          ${HF.steps.map((step, index) => `
            <a
              href="#/${step.id}"
              class="process-card"
            >
              <span class="tag">
                STEP ${String(index + 1).padStart(2, "0")}
              </span>

              <h3>${DB.esc(step.name)}</h3>
              <p>${DB.esc(step.description)}</p>
              <span>업무 가이드 보기 →</span>
            </a>
          `).join("")}
        </div>
      </section>

      <section>
        <h2>HR 업무 도구</h2>

        <div class="tool-grid">
          ${[
            ["documents", "문서 자료실", "표준 채용 문서 작성"],
            ["calendar", "채용 캘린더", "일정 및 전형 관리"],
            ["kpi", "KPI 분석", "채용 성과 계산"],
            ["applicants", "지원자 관리", "지원자 및 평가 관리"],
            ["onboarding", "온보딩 관리", "신규 입사자 관리"],
            ["trends", "HR 트렌드", "최신 HR 운영 방향"],
            ["backup", "데이터 백업", "데이터 내보내기 및 복원"]
          ].map(item => `
            <a href="#/${item[0]}" class="tool-card">
              <h3>${item[1]}</h3>
              <p>${item[2]}</p>
            </a>
          `).join("")}
        </div>
      </section>
    `;
  }

  function trends() {
    const items = [
      {
        title: "AI 기반 채용 자동화",
        description: "공고 작성, 일정 조율, 반복 행정 업무에 AI를 활용합니다.",
        action: "AI는 업무 보조 수단으로 사용하고 최종 평가와 의사결정은 담당자가 검토합니다."
      },
      {
        title: "스킬 기반 채용",
        description: "학력과 경력 연수만이 아니라 실제 직무 역량을 중심으로 평가합니다.",
        action: "직무 과제와 구조화 면접을 통해 직무 관련 증거를 확보합니다."
      },
      {
        title: "후보자 경험 개선",
        description: "지원부터 최종 결과 안내까지 후보자 경험을 관리합니다.",
        action: "전형별 안내, 예상 일정, 피드백 전달 기준을 수립합니다."
      },
      {
        title: "구조화 면접",
        description: "공통 질문과 평가 척도를 활용해 면접의 일관성을 확보합니다.",
        action: "면접관별 평가 차이를 줄이고 평가 근거를 기록합니다."
      },
      {
        title: "채용 데이터 분석",
        description: "채용 소요일과 전환율, 오퍼 수락률을 정량적으로 분석합니다.",
        action: "직무별·채널별 데이터를 비교하고 개선 과제를 도출합니다."
      },
      {
        title: "공정성과 다양성",
        description: "직무 관련 평가 기준과 투명한 선발 절차를 운영합니다.",
        action: "평가 기준을 사전에 정의하고 불필요한 개인정보 활용을 제한합니다."
      }
    ];

    return `
      <section class="page-header">
        <span class="tag">HR TREND REPORT</span>
        <h1>HR 트렌드 분석</h1>
        <p>2026년 HR 업무에 적용할 주요 운영 방향입니다.</p>
      </section>

      <div class="trend-grid">
        ${items.map(item => `
          <article class="card">
            <h3>${item.title}</h3>
            <p>${item.description}</p>

            <div class="guide-box">
              <strong>실무 적용</strong>
              <p>${item.action}</p>
            </div>
          </article>
        `).join("")}
      </div>

      <section class="card">
        <h2>HR 운영 개선 우선순위</h2>

        <ol>
          <li>직무기술서와 평가 기준 표준화</li>
          <li>구조화 면접 도입</li>
          <li>채용 단계별 후보자 경험 개선</li>
          <li>채용 KPI 데이터 축적</li>
          <li>AI 기반 반복 업무 보조</li>
        </ol>
      </section>
    `;
  }

  function shell() {
    const navigation = [
      {
        label: "WORKSPACE",
        items: [
          ["/", "대시보드"]
        ]
      },
      {
        label: "RECRUITMENT",
        items: HF.steps.map(step => [
          "/" + step.id,
          step.name
        ])
      },
      {
        label: "HR TOOLS",
        items: [
          ["/documents", "문서 자료실"],
          ["/calendar", "채용 캘린더"],
          ["/kpi", "KPI 분석"],
          ["/applicants", "지원자 관리"],
          ["/onboarding", "온보딩 관리"],
          ["/trends", "HR 트렌드"],
          ["/backup", "데이터 백업"]
        ]
      }
    ];

    document.getElementById("app").innerHTML = `
      <div class="layout">
        <aside class="sidebar" id="sidebar">
          <div class="logo">
            HIRE<span>FLOW</span>
          </div>

          ${navigation.map(group => `
            <div class="nav-label">${group.label}</div>

            ${group.items.map(([path, label]) => `
              <a
                href="#${path}"
                class="nav-link"
                data-link
              >
                ${label}
              </a>
            `).join("")}
          `).join("")}
        </aside>

        <main class="main">
          <header class="topbar">
            <button id="menu" class="btn secondary">
              ☰
            </button>

            <span>HIREFLOW / HR WORKSPACE</span>
          </header>

          <div id="content"></div>

          <footer class="footer">
            HIREFLOW · HR Recruitment Workspace
          </footer>
        </main>
      </div>
    `;
  }

  function bind() {
    document.getElementById("menu")
      ?.addEventListener("click", () => {
        document.getElementById("sidebar")
          .classList.toggle("open");
      });

    document.querySelectorAll("[data-doc]")
      .forEach(button => {
        button.onclick = () => Docs.open(button.dataset.doc);
      });

    document.querySelectorAll("[data-task]")
      .forEach(button => {
        button.onclick = () => Process.open(
          button.dataset.task,
          Number(button.dataset.index)
        );
      });

    CalendarTool.bind();
    KPI.bind();
    Applicants.bind();
    Onboarding.bind();
    Backup.bind();
  }

  function render() {
    const path = location.hash.slice(1).split("?")[0] || "/";
    const content = document.getElementById("content");

    content.innerHTML = routes[path]
      ? routes[path]()
      : "<h1>404</h1><a href='#/'>대시보드로 이동</a>";

    document.querySelectorAll(".sidebar [data-link]")
      .forEach(link => {
        link.classList.toggle(
          "active",
          link.getAttribute("href") === "#" + path
        );
      });

    bind();
  }

  function init() {
    shell();

    document.addEventListener("click", event => {
      if (event.target.closest("[data-close]")) {
        DB.close();
      }

      if (event.target.id === "modal") {
        DB.close();
      }

      const documentButton = event.target.closest("#modal-content [data-doc]");

      if (documentButton) {
        Docs.open(documentButton.dataset.doc);
      }
    });

    window.addEventListener("hashchange", render);

    if (!location.hash) {
      location.hash = "#/";
    } else {
      render();
    }
  }

  return {
    init,
    render
  };
})();

App.init();
