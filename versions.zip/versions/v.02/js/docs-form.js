
"use strict";

window.DocsForm = (() => {
  const templates = {
    request: {
      title: "채용 요청서",
      fields: [
        ["department", "요청 부서", "text"],
        ["position", "채용 직무", "text"],
        ["count", "채용 인원", "number"],
        ["reason", "채용 사유", "textarea"],
        ["duties", "주요 담당 업무", "textarea"],
        ["requirements", "필수 자격 요건", "textarea"],
        ["preferred", "우대 사항", "textarea"],
        ["salary", "연봉 및 처우", "text"],
        ["deadline", "희망 입사일", "date"],
        ["owner", "요청자", "text"]
      ]
    },

    jd: {
      title: "직무기술서",
      fields: [
        ["position", "직무명", "text"],
        ["department", "소속 부서", "text"],
        ["purpose", "직무 목적", "textarea"],
        ["duties", "주요 업무", "textarea"],
        ["requirements", "필수 역량", "textarea"],
        ["preferred", "우대 역량", "textarea"],
        ["skills", "필요 기술 및 도구", "textarea"],
        ["experience", "경력 요건", "text"],
        ["education", "학력 요건", "text"],
        ["salary", "처우", "text"]
      ]
    },

    interview: {
      title: "면접 평가표",
      fields: [
        ["candidate", "지원자 이름", "text"],
        ["position", "지원 직무", "text"],
        ["interviewer", "면접관", "text"],
        ["date", "면접 일자", "date"],
        ["expertise", "직무 전문성 (1~5)", "number"],
        ["problem", "문제 해결력 (1~5)", "number"],
        ["communication", "의사소통 (1~5)", "number"],
        ["collaboration", "협업 능력 (1~5)", "number"],
        ["growth", "성장 가능성 (1~5)", "number"],
        ["comment", "종합 평가 의견", "textarea"],
        ["result", "최종 의견", "text"]
      ]
    },

    offer: {
      title: "채용 제안서",
      fields: [
        ["candidate", "지원자 이름", "text"],
        ["position", "직무", "text"],
        ["department", "부서", "text"],
        ["salary", "제안 연봉", "text"],
        ["start", "입사 예정일", "date"],
        ["employment", "고용 형태", "text"],
        ["benefits", "복리후생", "textarea"],
        ["deadline", "수락 기한", "date"],
        ["contact", "담당자", "text"]
      ]
    },

    onboarding: {
      title: "온보딩 계획서",
      fields: [
        ["name", "입사자 이름", "text"],
        ["position", "직무", "text"],
        ["department", "부서", "text"],
        ["start", "입사일", "date"],
        ["mentor", "멘토", "text"],
        ["day30", "30일 목표", "textarea"],
        ["day60", "60일 목표", "textarea"],
        ["day90", "90일 목표", "textarea"],
        ["equipment", "지급 장비", "textarea"],
        ["training", "교육 계획", "textarea"]
      ]
    }
  };

  function esc(value) {
    return DB.esc(value ?? "");
  }

  function renderField(field) {
    const [key, label, type] = field;

    if (type === "textarea") {
      return `
        <label>
          ${label}
          <textarea name="${key}" rows="4"></textarea>
        </label>
      `;
    }

    const limits = type === "number"
      ? 'min="0" max="5" step="1"'
      : "";

    return `
      <label>
        ${label}
        <input
          name="${key}"
          type="${type}"
          ${limits}
          ${key === "count" ? 'min="1"' : ""}
          ${type === "number" ? 'value="3"' : ""}
        >
      </label>
    `;
  }

  function open(type, existing = {}) {
    const template = templates[type];

    if (!template) {
      alert("존재하지 않는 문서 양식입니다.");
      return;
    }

    DB.modal(`
      <h2>${template.title}</h2>

      <p class="muted">
        입력한 내용으로 문서를 생성할 수 있습니다.
      </p>

      <form id="document-form">
        <div class="form-grid">
          ${template.fields.map(field => {
            const [key, label, inputType] = field;
            const value = existing[key] ?? "";

            if (inputType === "textarea") {
              return `
                <label>
                  ${label}
                  <textarea
                    name="${key}"
                    rows="4"
                  >${esc(value)}</textarea>
                </label>
              `;
            }

            return `
              <label>
                ${label}
                <input
                  name="${key}"
                  type="${inputType}"
                  value="${esc(value)}"
                  ${inputType === "number"
                    ? 'min="1" max="5"'
                    : ""}
                  ${key === "count" ? 'min="1"' : ""}
                >
              </label>
            `;
          }).join("")}
        </div>

        <div class="section-header">
          <button class="btn" type="submit">
            문서 생성 및 다운로드
          </button>
          <button
            class="btn secondary"
            type="button"
            id="document-preview"
          >
            미리보기
          </button>
        </div>
      </form>
    `);

    const form = document.getElementById("document-form");

    function collect() {
      const data = {};

      new FormData(form).forEach((value, key) => {
        data[key] = value;
      });

      return data;
    }

    function makeHtml(data) {
      const rows = template.fields.map(([key, label]) => `
        <tr>
          <th>${esc(label)}</th>
          <td>${esc(data[key]).replace(/\n/g, "<br>")}</td>
        </tr>
      `).join("");

      return `
        <!DOCTYPE html>
        <html lang="ko">
        <head>
          <meta charset="UTF-8">
          <title>${template.title}</title>
          <style>
            body {
              font-family: Arial, sans-serif;
              padding: 35px;
              color: #26334a;
            }
            h1 {
              text-align: center;
              margin-bottom: 30px;
            }
            table {
              width: 100%;
              border-collapse: collapse;
            }
            th, td {
              border: 1px solid #dce1e9;
              padding: 12px;
              text-align: left;
              vertical-align: top;
            }
            th {
              width: 25%;
              background: #f2f5fa;
            }
            @media print {
              body { padding: 10px; }
            }
          </style>
        </head>
        <body>
          <h1>${template.title}</h1>
          <table>${rows}</table>
          <p>작성일: ${DB.today()}</p>
        </body>
        </html>
      `;
    }

    document.getElementById("document-preview")
      .onclick = () => {
        const html = makeHtml(collect());

        const blob = new Blob([html], {
          type: "text/html;charset=utf-8"
        });

        const url = URL.createObjectURL(blob);
        window.open(url, "_blank");
      };

    form.onsubmit = event => {
      event.preventDefault();

      const data = collect();

      const required = template.fields
        .filter(([key]) => [
          "position",
          "candidate",
          "name",
          "department"
        ].includes(key));

      if (required.some(([key]) => !data[key]?.trim())) {
        alert("필수 항목을 입력하세요.");
        return;
      }

      const html = makeHtml(data);

      DB.download(
        "HIREFLOW_" + type + "_" + DB.today() + ".html",
        html,
        "text/html"
      );

      DB.close();
    };
  }

  return {
    open,
    templates
  };
})();
