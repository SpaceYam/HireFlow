
"use strict";

window.Docs = (() => {
  function catalog() {
    return `
      <section class="page-header">
        <h1>HR 표준 문서 자료실</h1>
        <p>채용 업무에 필요한 표준 문서를 작성하고 다운로드하세요.</p>
      </section>

      <div class="document-grid">
        ${Object.entries(DOC_DATA).map(([id, doc]) => `
          <article class="document-card">
            <span class="tag">${DB.esc(doc.category)}</span>
            <h3>${DB.esc(doc.title)}</h3>
            <p>${DB.esc(doc.guide)}</p>
            <button class="btn" data-doc="${id}">
              문서 작성하기
            </button>
          </article>
        `).join("")}
      </div>

      <section class="card">
        <h2>채용 공고 게시 채널</h2>
        <p>직무와 지원자 특성에 맞는 채널을 선택하세요.</p>
        ${HF.channels.map(channel => `
          <div class="channel-row">
            <div>
              <strong>${DB.esc(channel.name)}</strong>
              <p>${DB.esc(channel.category)}</p>
            </div>
            <a href="${channel.url}" target="_blank" rel="noopener">
              사이트 방문 →
            </a>
          </div>
        `).join("")}
      </section>
    `;
  }

  function open(id) {
    const doc = DOC_DATA[id];

    if (!doc) return;

    const fields = Object.entries(doc.sections)
      .flatMap(([section, names]) =>
        names.map(name => ({ section, name }))
      );

    DB.modal(`
      <h2>${DB.esc(doc.title)} 작성</h2>
      <p class="muted">${DB.esc(doc.guide)}</p>

      <form id="document-form">
        ${Object.entries(doc.sections).map(([section, names]) => `
          <section class="form-section">
            <h3>${DB.esc(section)}</h3>

            <div class="form-grid">
              ${names.map((name, index) => `
                <label>
                  ${DB.esc(name)}

                  ${/일$/.test(name)
                    ? `<input type="date" name="field_${fields.findIndex(f => f.name === name)}">`
                    : /인원|점수|연봉|예산/.test(name)
                      ? `<input type="number" min="0" name="field_${fields.findIndex(f => f.name === name)}">`
                      : `<textarea name="field_${fields.findIndex(f => f.name === name)}" rows="2"></textarea>`
                  }
                </label>
              `).join("")}
            </div>
          </section>
        `).join("")}

        <button class="btn" type="submit">
          문서 미리보기
        </button>
      </form>
    `);

    document.getElementById("document-form").onsubmit = event => {
      event.preventDefault();

      const formData = new FormData(event.target);

      const rows = fields.map((field, index) => `
        <tr>
          <th>${DB.esc(field.name)}</th>
          <td>${DB.esc(formData.get("field_" + index) || "-").replace(/\n/g, "<br>")}</td>
        </tr>
      `).join("");

      const html = `
        <!DOCTYPE html>
        <html lang="ko">
        <head>
          <meta charset="UTF-8">
          <title>${DB.esc(doc.title)}</title>
          <style>
            body {
              font-family: Arial, sans-serif;
              padding: 40px;
              color: #26334a;
            }
            h1 {
              border-bottom: 3px solid #4263eb;
              padding-bottom: 15px;
            }
            table {
              width: 100%;
              border-collapse: collapse;
              margin-top: 25px;
            }
            th, td {
              border: 1px solid #ddd;
              padding: 12px;
              text-align: left;
            }
            th {
              width: 25%;
              background: #f1f4fa;
            }
          </style>
        </head>
        <body>
          <h1>${DB.esc(doc.title)}</h1>
          <p>HIREFLOW HR DOCUMENT</p>
          <table>${rows}</table>
        </body>
        </html>
      `;

      DB.modal(`
        <h2>문서 미리보기</h2>
        <div class="preview-frame">
          <iframe
            title="문서 미리보기"
            sandbox
            srcdoc="${DB.esc(html).replace(/"/g, "&quot;")}"
          ></iframe>
        </div>

        <button class="btn" id="download-document">
          HTML 다운로드
        </button>
      `);

      document.getElementById("download-document").onclick = () => {
        DB.download(doc.title + ".html", html);
      };
    };
  }

  return {
    catalog,
    open
  };
})();
