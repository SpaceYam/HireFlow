
"use strict";

window.CalendarTool = (() => {
  let current = new Date();

  function page() {
    const year = current.getFullYear();
    const month = current.getMonth();

    const firstDay = new Date(year, month, 1).getDay();
    const lastDate = new Date(year, month + 1, 0).getDate();

    const events = DB.get("calendar");

    let cells = "";

    for (let i = 0; i < firstDay; i++) {
      cells += "<div class='calendar-empty'></div>";
    }

    for (let day = 1; day <= lastDate; day++) {
      const date = [
        year,
        String(month + 1).padStart(2, "0"),
        String(day).padStart(2, "0")
      ].join("-");

      const dailyEvents = events.filter(
        event => event.date === date
      );

      cells += `
        <button
          class="day"
          data-date="${date}"
          type="button"
        >
          <b>${day}</b>

          ${dailyEvents.map(event => `
            <small>${DB.esc(event.title)}</small>
          `).join("")}
        </button>
      `;
    }

    return `
      <section class="page-header">
        <h1>채용 일정 캘린더</h1>
        <p>채용 단계별 주요 일정과 담당자를 관리합니다.</p>
      </section>

      <section class="card">
        <div class="section-header">
          <button class="btn secondary" id="calendar-prev">
            ← 이전
          </button>

          <h2>${year}년 ${month + 1}월</h2>

          <button class="btn secondary" id="calendar-next">
            다음 →
          </button>
        </div>

        <div class="calendar">
          ${["일", "월", "화", "수", "목", "금", "토"]
            .map(day => `<b>${day}</b>`).join("")}

          ${cells}
        </div>

        <button class="btn" id="calendar-add">
          + 일정 등록
        </button>
      </section>

      <section class="card">
        <h2>등록된 일정</h2>

        ${events.sort((a, b) => a.date.localeCompare(b.date))
          .map(event => `
            <div class="event-row">
              <div>
                <strong>${DB.esc(event.title)}</strong>
                <p>${DB.esc(event.date)} · ${DB.esc(event.type)}</p>
                <small>${DB.esc(event.owner || "")}</small>
              </div>

              <div>
                <button
                  class="btn secondary"
                  data-edit="${event.id}"
                >
                  수정
                </button>

                <button
                  class="btn danger"
                  data-delete="${event.id}"
                >
                  삭제
                </button>
              </div>
            </div>
          `).join("") || "<p>등록된 일정이 없습니다.</p>"}
      </section>
    `;
  }

  function form(id = null, date = "") {
    const list = DB.get("calendar");
    const old = list.find(item => item.id === id);

    DB.modal(`
      <h2>${old ? "일정 수정" : "일정 등록"}</h2>

      <form id="calendar-form">
        <label>
          일정명
          <input
            name="title"
            required
            value="${DB.esc(old?.title || "")}"
          >
        </label>

        <label>
          날짜
          <input
            name="date"
            type="date"
            required
            value="${old?.date || date || DB.today()}"
          >
        </label>

        <label>
          전형 구분
          <select name="type">
            ${[
              "채용 공고",
              "서류 검토",
              "면접",
              "역량 평가",
              "최종 발표",
              "입사"
            ].map(type => `
              <option ${old?.type === type ? "selected" : ""}>
                ${type}
              </option>
            `).join("")}
          </select>
        </label>

        <label>
          담당자
          <input
            name="owner"
            value="${DB.esc(old?.owner || "")}"
          >
        </label>

        <label>
          메모
          <textarea name="memo">${DB.esc(old?.memo || "")}</textarea>
        </label>

        <button class="btn" type="submit">저장</button>
      </form>
    `);

    document.getElementById("calendar-form").onsubmit = event => {
      event.preventDefault();

      const data = new FormData(event.target);

      const item = {
        id: old?.id || DB.id(),
        title: data.get("title"),
        date: data.get("date"),
        type: data.get("type"),
        owner: data.get("owner"),
        memo: data.get("memo")
      };

      const updated = old
        ? list.map(value => value.id === id ? item : value)
        : [...list, item];

      if (DB.set("calendar", updated)) {
        DB.close();
        App.render();
      }
    };
  }

  function bind() {
    document.getElementById("calendar-prev")
      ?.addEventListener("click", () => {
        current.setMonth(current.getMonth() - 1);
        App.render();
      });

    document.getElementById("calendar-next")
      ?.addEventListener("click", () => {
        current.setMonth(current.getMonth() + 1);
        App.render();
      });

    document.getElementById("calendar-add")
      ?.addEventListener("click", () => form());

    document.querySelectorAll("[data-date]")
      .forEach(button => {
        button.onclick = () => form(null, button.dataset.date);
      });

    document.querySelectorAll("[data-edit]")
      .forEach(button => {
        button.onclick = () => form(button.dataset.edit);
      });

    document.querySelectorAll("[data-delete]")
      .forEach(button => {
        button.onclick = () => {
          if (!confirm("일정을 삭제할까요?")) return;

          const updated = DB.get("calendar").filter(
            item => item.id !== button.dataset.delete
          );

          DB.set("calendar", updated);
          App.render();
        };
      });
  }

  return {
    page,
    bind
  };
})();
