
"use strict";

window.HF = {
  version: "2.0.0",

  steps: [
    {
      id: "planning",
      name: "채용 계획 수립",
      description: "인력 수요 분석 및 채용 승인"
    },
    {
      id: "posting",
      name: "채용 공고 및 모집",
      description: "직무기술서 작성 및 후보자 모집"
    },
    {
      id: "screening",
      name: "서류 검토",
      description: "지원서 검토 및 서류 평가"
    },
    {
      id: "interview",
      name: "면접 진행",
      description: "구조화 면접 및 역량 평가"
    },
    {
      id: "assessment",
      name: "역량 평가",
      description: "과제 및 직무 역량 검증"
    },
    {
      id: "decision",
      name: "최종 합격",
      description: "최종 의사결정 및 오퍼"
    },
    {
      id: "onboarding",
      name: "입사 및 온보딩",
      description: "신규 입사자 적응 및 성과 관리"
    }
  ],

  channels: [
    {
      name: "사람인",
      category: "종합 채용",
      url: "https://www.saramin.co.kr"
    },
    {
      name: "잡코리아",
      category: "종합 채용",
      url: "https://www.jobkorea.co.kr"
    },
    {
      name: "원티드",
      category: "IT 및 전문직",
      url: "https://www.wanted.co.kr"
    },
    {
      name: "LinkedIn",
      category: "전문직 및 글로벌",
      url: "https://www.linkedin.com"
    }
  ]
};

window.DB = {
  get(key, fallback = []) {
    try {
      const value = localStorage.getItem("hf_" + key);

      return value === null
        ? fallback
        : JSON.parse(value);
    } catch (error) {
      console.error("데이터 읽기 오류:", error);
      return fallback;
    }
  },

  set(key, value) {
    try {
      localStorage.setItem(
        "hf_" + key,
        JSON.stringify(value)
      );

      return true;
    } catch (error) {
      console.error("데이터 저장 오류:", error);
      alert("저장 공간이 부족하거나 브라우저 저장이 차단되었습니다.");
      return false;
    }
  },

  id() {
    return (
      Date.now().toString(36) +
      Math.random().toString(36).slice(2, 9)
    );
  },

  esc(value) {
    return String(value ?? "").replace(
      /[&<>"']/g,
      char => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
      })[char]
    );
  },

  download(filename, content, type = "text/html;charset=utf-8") {
    const blob = new Blob(
      ["\ufeff", content],
      { type }
    );

    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");

    link.href = url;
    link.download = filename;

    document.body.appendChild(link);
    link.click();
    link.remove();

    setTimeout(() => {
      URL.revokeObjectURL(url);
    }, 1000);
  },

  modal(content) {
    document.getElementById("modal-content").innerHTML = content;
    document.getElementById("modal").classList.remove("hidden");
  },

  close() {
    document.getElementById("modal").classList.add("hidden");
  },

  today() {
    const date = new Date();
    const offset = date.getTimezoneOffset();

    return new Date(date.getTime() - offset * 60000)
      .toISOString()
      .slice(0, 10);
  }
};
