
"use strict";

window.Applicants = (() => {
  const stages = [
    "지원",
    "서류검토",
    "면접",
    "최종평가",
    "합격",
    "불합격"
  ];

  const criteria = [
    "직무 전문성",
    "문제 해결력",
    "커뮤니케이션",
    "협업 역량",
    "성장 가능성"
  ];

  function page() {
    const applicants = DB.get("applicants");

    return `
      <section class="page-header">
        <h1>지원자 관리</h1>
        <p>지원자 정보와 채용 전형 진행 상황을 관리합니다.</p>
      </section>

      <section class="card">
        <div class="section-header">
          <h2>지원자 목록 (${applicants.length})</h2>
          <button class="btn" id="add-applicant">
            + 지원자 등록
          </button>
        </div>

        <div class="table-wrap">
          <table>
            <thead>
              <tr>
                <th>이름</th>
                <th>직무</th>
                <th>지원일</th>
                <th>전형 단계</th>
                <th>평가</th>
                <th>관리</th>
              </tr>
            </thead>

            <tbody>
              ${applicants.map(person => `
                <tr>
                  <td>${DB.esc(person.name)}</td>
                  <td>${DB.esc(person.job)}</td>
                  <td>${DB.esc(person.date)}</td>

                  <td>
                    <select data-stage="${person.id}">
                      ${stages.map(stage => `
                        <option
                          value="${stage}"
                          ${person.stage === stage ? "selected" : ""}
                        >
                          ${stage}
                        </option>
                      `).join("")}
                    </select>
                  </td>

                  <td>
                    <button
                      class="btn secondary"
                      data-evaluate="${person.id}"
                    >
                      평가
                    </button>
                  </td>

                  <td>
                    <button
                      class="btn danger"
                      data-remove="${person.id}"
                    >
                      삭제
                    </button>
                  </td>
                </tr>
              `).join("")}
            </tbody>
          </table>
        </div>
      </section>
    `;
  }

  function add() {
    DB.modal(`
      <h2>지원자 등록</h2>

      <form id="applicant-form">
        <div class="form-grid">
          <label>
            이름
            <input name="name" required>
          </label>

          <label>
            지원 직무
            <input name="job" required>
          </label>

          <label>
            이메일
            <input name="email" type="email">
          </label>

          <label>
            연락처
            <input name="phone" type="tel">
          </label>

          <label>
            지원일
            <input name="date" type="date" value="${DB.today()}">
          </label>
        </div>

        <button class="btn" type="submit">등록하기</button>
      </form>
    `);

    document.getElementById("applicant-form").onsubmit = event => {
      event.preventDefault();

      const form = new FormData(event.target);

      const person = {
        id: DB.id(),
        name: form.get("name"),
        job: form.get("job"),
        email: form.get("email"),
        phone: form.get("phone"),
        date: form.get("date"),
        stage: "지원"
      };

      const list = DB.get("applicants");
      list.push(person);

      if (DB.set("applicants", list)) {
        DB.close();
        App.render();
      }
    };
  }

  function evaluate(id) {
    const person = DB.get("applicants")
      .find(item => item.id === id);

    if (!person) return;

    const previous = DB.get("eval_" + id, {});

    DB.modal(`
      <h2>${DB.esc(person.name)} 면접 평가</h2>
      <p class="muted">
        각 항목을 1~5점으로 평가하고 근거를 기록하세요.
      </p>

      <form id="evaluation-form">
        ${criteria.map((item, index) => `
          <label>
            ${item}

            <select name="score${index}" required>
              ${[1, 2, 3, 4, 5].map(score => `
                <option
                  value="${score}"
                  ${previous["score" + index] === score ? "selected" : ""}
                >
                  ${score}점
                </option>
              `).join("")}
            </select>
          </label>
        `).join("")}

        <label>
          평가 근거
          <textarea name="memo">${DB.esc(previous.memo || "")}</textarea>
        </label>

        <button class="btn" type="submit">평가 저장</button>
      </form>
    `);

    document.getElementById("evaluation-form").onsubmit = event => {
      event.preventDefault();

      const form = new FormData(event.target);
      const result = {
        memo: form.get("memo"),
        updatedAt: DB.today()
      };

      let total = 0;

      criteria.forEach((item, index) => {
        const score = Number(form.get("score" + index));

        result["score" + index] = score;
        total += score;
      });

      result.average = Number((total / criteria.length).toFixed(2));

      if (DB.set("eval_" + id, result)) {
        DB.close();

        alert(
          "평가 저장 완료\n평균 점수: " +
          result.average + " / 5"
        );
      }
    };
  }

  function bind() {
    document.getElementById("add-applicant")
      ?.addEventListener("click", add);

    document.querySelectorAll("[data-stage]")
      .forEach(select => {
        select.onchange = () => {
          const list = DB.get("applicants");
          const person = list.find(
            item => item.id === select.dataset.stage
          );

          if (!person) return;

          person.stage = select.value;

          DB.set("applicants", list);
        };
      });

    document.querySelectorAll("[data-evaluate]")
      .forEach(button => {
        button.onclick = () => evaluate(button.dataset.evaluate);
      });

    document.querySelectorAll("[data-remove]")
      .forEach(button => {
        button.onclick = () => {
          if (!confirm("지원자 정보를 삭제할까요?")) return;

          const list = DB.get("applicants").filter(
            item => item.id !== button.dataset.remove
          );

          DB.set("applicants", list);
          App.render();
        };
      });
  }

  return {
    page,
    bind
  };
})();
