
"use strict";

window.Process = (() => {
  const tasks = {
    planning: [
      {
        title: "인력 수요 분석",
        description: "현재 인력과 사업 계획을 비교해 추가 인력의 필요성을 검토합니다.",
        document: "request",
        guide: [
          "현업 부서의 업무량과 인력 현황을 확인합니다.",
          "충원, 대체, 신규 사업 중 채용 목적을 구분합니다.",
          "채용 인원과 예산을 검토합니다."
        ]
      },
      {
        title: "채용 요청 승인",
        description: "현업 부서의 채용 요청을 HR과 승인권자가 검토합니다.",
        document: "request",
        guide: [
          "채용 요청서를 작성합니다.",
          "부서장의 승인을 받습니다.",
          "HR에서 직무와 예산을 검토합니다.",
          "최종 승인 결과를 기록합니다."
        ]
      },
      {
        title: "직무 분석",
        description: "직무 목적과 역할, 필수 역량을 구체화합니다.",
        document: "jd",
        guide: [
          "직무의 핵심 목적을 정의합니다.",
          "주요 업무를 3~7개로 구분합니다.",
          "필수 자격과 우대 자격을 분리합니다.",
          "성과 측정 기준을 정합니다."
        ]
      }
    ],

    posting: [
      {
        title: "채용 공고 작성",
        description: "지원자가 직무를 정확하게 이해할 수 있도록 공고를 작성합니다.",
        document: "posting",
        guide: [
          "직무기술서를 기반으로 공고를 작성합니다.",
          "자격 요건을 실제 업무와 연결합니다.",
          "근무 조건과 전형 절차를 명시합니다."
        ]
      },
      {
        title: "채용 채널 선정",
        description: "직무와 후보자 특성에 맞는 모집 채널을 선택합니다.",
        guide: [
          "일반직은 종합 채용 플랫폼을 검토합니다.",
          "전문직은 직무별 전문 플랫폼을 검토합니다.",
          "글로벌 인재는 LinkedIn 등을 활용합니다.",
          "채널별 지원자 수와 전환율을 비교합니다."
        ]
      }
    ],

    screening: [
      {
        title: "서류 검토 기준 수립",
        description: "직무 관련 역량과 경험을 중심으로 평가 기준을 정의합니다.",
        document: "interview",
        guide: [
          "필수 요건과 우대 요건을 구분합니다.",
          "평가 항목별 점수 기준을 정의합니다.",
          "평가자 간 기준을 사전에 공유합니다."
        ]
      },
      {
        title: "지원자 서류 평가",
        description: "사전에 정의한 기준에 따라 지원서를 검토합니다.",
        guide: [
          "직무 관련 경험을 확인합니다.",
          "실제 수행 업무와 성과를 확인합니다.",
          "평가 근거를 기록합니다."
        ]
      }
    ],

    interview: [
      {
        title: "면접 질문 설계",
        description: "직무 역량과 행동 사례를 확인할 공통 질문을 설계합니다.",
        document: "interview",
        guide: [
          "직무 핵심 역량을 선정합니다.",
          "역량별 행동 질문을 설계합니다.",
          "좋은 답변과 부족한 답변의 기준을 정의합니다."
        ]
      },
      {
        title: "면접 진행",
        description: "지원자에게 동일한 핵심 질문을 적용합니다.",
        document: "interview",
        guide: [
          "면접 시작 전 직무와 절차를 안내합니다.",
          "공통 질문과 추가 질문을 구분합니다.",
          "면접 종료 후 평가 근거를 기록합니다."
        ]
      }
    ],

    assessment: [
      {
        title: "과제 평가",
        description: "실제 직무와 관련된 과제로 수행 역량을 확인합니다.",
        document: "interview",
        guide: [
          "직무와 관련된 과제를 설계합니다.",
          "과제 수행 시간과 제출 기준을 안내합니다.",
          "사전에 정의한 평가 기준을 적용합니다."
        ]
      }
    ],

    decision: [
      {
        title: "최종 평가",
        description: "전형별 결과와 직무 역량을 종합합니다.",
        document: "final",
        guide: [
          "서류와 면접 결과를 종합합니다.",
          "평가 근거와 추천 의견을 기록합니다.",
          "채용 결정권자의 승인을 받습니다."
        ]
      },
      {
        title: "오퍼 및 입사 확정",
        description: "근로 조건을 안내하고 입사 의사를 확인합니다.",
        document: "final",
        guide: [
          "보상 조건을 내부 기준에 맞게 검토합니다.",
          "지원자에게 처우와 입사 조건을 안내합니다.",
          "입사 의사를 확인하고 결과를 기록합니다."
        ]
      }
    ],

    onboarding: [
      {
        title: "입사 준비",
        description: "입사 전 필요한 계정, 장비, 교육을 준비합니다.",
        document: "onboarding",
        guide: [
          "입사 서류와 계정 발급을 준비합니다.",
          "업무 장비와 근무 환경을 준비합니다.",
          "멘토와 교육 일정을 지정합니다."
        ]
      },
      {
        title: "30·60·90일 적응 관리",
        description: "신규 입사자의 조직 적응과 직무 수행을 지원합니다.",
        document: "onboarding",
        guide: [
          "30일: 조직과 업무 이해",
          "60일: 독립적인 업무 수행",
          "90일: 초기 성과 및 적응도 평가"
        ]
      }
    ]
  };

  function page(id) {
    const step = HF.steps.find(item => item.id === id);
    const list = tasks[id] || [];

    if (!step) return "<h1>페이지를 찾을 수 없습니다.</h1>";

    return `
      <section class="page-header">
        <span class="tag">RECRUITMENT PROCESS</span>
        <h1>${DB.esc(step.name)}</h1>
        <p>${DB.esc(step.description)}</p>
      </section>

      <section class="card">
        <h2>실무 체크리스트</h2>

        ${list.map((task, index) => `
          <article class="task-row">
            <div>
              <h3>${index + 1}. ${DB.esc(task.title)}</h3>
              <p>${DB.esc(task.description)}</p>
            </div>

            <button
              class="btn secondary"
              data-task="${id}"
              data-index="${index}"
            >
              상세 업무 보기 →
            </button>
          </article>
        `).join("")}
      </section>

      <section class="card">
        <h2>관련 업무 도구</h2>
        <a href="#/documents" class="btn">문서 자료실</a>
        <a href="#/calendar" class="btn secondary">채용 일정표</a>
      </section>
    `;
  }

  function open(id, index) {
    const task = tasks[id]?.[index];

    if (!task) return;

    DB.modal(`
      <span class="tag">WORK GUIDE</span>
      <h2>${DB.esc(task.title)}</h2>
      <p>${DB.esc(task.description)}</p>

      <h3>실행 방법</h3>

      <ol>
        ${task.guide.map(item => `
          <li>${DB.esc(item)}</li>
        `).join("")}
      </ol>

      ${task.document ? `
        <button
          class="btn"
          data-doc="${task.document}"
        >
          관련 표준 문서 작성하기
        </button>
      ` : ""}
    `);
  }

  return {
    page,
    open
  };
})();
