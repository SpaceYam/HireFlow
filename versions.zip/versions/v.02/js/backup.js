
"use strict";

window.Backup = (() => {
  function page() {
    return `
      <section class="page-header">
        <h1>데이터 관리</h1>
        <p>HR 업무 데이터를 안전하게 백업하고 복원합니다.</p>
      </section>

      <section class="card">
        <h2>데이터 내보내기</h2>
        <p>지원자, 일정, 평가, KPI 및 온보딩 데이터를 저장합니다.</p>
        <button class="btn" id="export-data">
          JSON 백업 다운로드
        </button>
      </section>

      <section class="card">
        <h2>데이터 복원</h2>
        <p>이전에 생성한 HIREFLOW 백업 파일을 선택하세요.</p>

        <input
          type="file"
          id="import-data"
          accept=".json,application/json"
        >

        <button class="btn" id="restore-data">
          백업 복원
        </button>
      </section>

      <section class="card">
        <h2>데이터 초기화</h2>
        <p>현재 브라우저에 저장된 HR 데이터를 모두 삭제합니다.</p>
        <button class="btn danger" id="reset-data">
          전체 초기화
        </button>
      </section>
    `;
  }

  function exportData() {
    const data = {};

    Object.keys(localStorage)
      .filter(key => key.startsWith("hf_"))
      .forEach(key => {
        data[key] = localStorage.getItem(key);
      });

    const backup = {
      application: "HIREFLOW",
      version: HF.version,
      exportedAt: new Date().toISOString(),
      data
    };

    DB.download(
      "hireflow-backup.json",
      JSON.stringify(backup, null, 2),
      "application/json"
    );
  }

  function restoreData() {
    const input = document.getElementById("import-data");
    const file = input.files[0];

    if (!file) {
      alert("백업 파일을 선택하세요.");
      return;
    }

    const reader = new FileReader();

    reader.onload = () => {
      try {
        const backup = JSON.parse(reader.result);

        if (
          backup.application !== "HIREFLOW" ||
          !backup.data ||
          typeof backup.data !== "object" ||
          Array.isArray(backup.data)
        ) {
          throw new Error("잘못된 백업 파일");
        }

        Object.entries(backup.data).forEach(([key, value]) => {
          if (
            !key.startsWith("hf_") ||
            typeof value !== "string"
          ) {
            throw new Error("잘못된 데이터");
          }

          JSON.parse(value);
        });

        if (!confirm("현재 데이터를 백업 데이터로 교체할까요?")) {
          return;
        }

        Object.keys(localStorage)
          .filter(key => key.startsWith("hf_"))
          .forEach(key => localStorage.removeItem(key));

        Object.entries(backup.data).forEach(([key, value]) => {
          localStorage.setItem(key, value);
        });

        alert("데이터 복원이 완료되었습니다.");
        App.render();
      } catch (error) {
        alert("올바른 HIREFLOW 백업 파일이 아닙니다.");
        console.error(error);
      }
    };

    reader.readAsText(file);
  }

  function resetData() {
    if (!confirm("모든 HR 데이터를 삭제할까요?")) {
      return;
    }

    if (!confirm("삭제한 데이터는 복구할 수 없습니다. 계속할까요?")) {
      return;
    }

    Object.keys(localStorage)
      .filter(key => key.startsWith("hf_"))
      .forEach(key => localStorage.removeItem(key));

    alert("데이터가 초기화되었습니다.");
    App.render();
  }

  function bind() {
    document.getElementById("export-data")
      ?.addEventListener("click", exportData);

    document.getElementById("restore-data")
      ?.addEventListener("click", restoreData);

    document.getElementById("reset-data")
      ?.addEventListener("click", resetData);
  }

  return {
    page,
    bind
  };
})();
