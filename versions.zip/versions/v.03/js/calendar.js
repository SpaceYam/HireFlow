
"use strict";

window.CalendarTool = (() => {
  let cursor = new Date();

  function page() {
    const y = cursor.getFullYear(), m = cursor.getMonth();
    const first = new Date(y,m,1).getDay();
    const last = new Date(y,m+1,0).getDate();
    const events = DB.get("calendar", []);

    let cells = "";
    for(let i=0;i<first;i++) cells += `<div class="calendar-blank"></div>`;

    for(let d=1;d<=last;d++) {
      const date = `${y}-${String(m+1).padStart(2,"0")}-${String(d).padStart(2,"0")}`;
      const items = events.filter(e=>e.date===date);
      cells += `
        <button class="calendar-day" data-date="${date}">
          <span>${d}</span>
          ${items.map(e=>`<small>${HF.esc(e.title)}</small>`).join("")}
        </button>`;
    }

    return `
      <div class="page-heading">
        <div><span class="eyebrow">SCHEDULE MANAGEMENT</span>
        <h1>채용 캘린더</h1>
        <p>채용 전형과 주요 업무 일정을 관리합니다.</p></div>
        <button class="button primary" id="add-event">일정 등록</button>
      </div>

      <section class="panel">
        <div class="calendar-head">
          <button class="button outline" id="prev-month">←</button>
          <h2>${y}년 ${m+1}월</h2>
          <button class="button outline" id="next-month">→</button>
        </div>
        <div class="calendar-grid">
          ${["일","월","화","수","목","금","토"].map(d=>`<b>${d}</b>`).join("")}
          ${cells}
        </div>
      </section>

      <section class="panel">
        <h2>전체 일정</h2>
        ${events.sort((a,b)=>a.date.localeCompare(b.date)).map(e=>`
          <div class="list-row">
            <div><strong>${HF.esc(e.title)}</strong>
            <p>${HF.esc(e.date)} · ${HF.esc(e.type)}</p></div>
            <div>
              <button class="text-button" data-edit="${e.id}">수정</button>
              <button class="text-button danger-text" data-delete="${e.id}">삭제</button>
            </div>
          </div>`).join("") || "<p>등록된 일정이 없습니다.</p>"}
      </section>`;
  }

  function form(date="", id="") {
    const list = DB.get("calendar", []);
    const old = list.find(e=>e.id===id);

    DB.modal(`
      <h2>${old?"일정 수정":"일정 등록"}</h2>
      <form id="event-form">
        <label>일정명<input name="title" required value="${HF.esc(old?.title)}"></label>
        <div class="form-grid">
          <label>날짜<input name="date" type="date" required value="${old?.date||date||HF.today()}"></label>
          <label>담당자<input name="owner" value="${HF.esc(old?.owner)}"></label>
        </div>
        <label>전형 단계
          <select name="type">
            ${HFData.steps.map(s=>`<option ${old?.type===s.name?"selected":""}>${s.name}</option>`).join("")}
          </select>
        </label>
        <label>메모<textarea name="memo">${HF.esc(old?.memo)}</textarea></label>
        <button class="button primary full">저장</button>
      </form>
    `);

    document.getElementById("event-form").onsubmit=e=>{
      e.preventDefault();
      const data=Object.fromEntries(new FormData(e.target));
      const item={...data,id:old?.id||HF.id()};
      const next=old?list.map(v=>v.id===id?item:v):[...list,item];
      if(DB.set("calendar",next)){DB.close();App.render();}
    };
  }

  function bind() {
    document.getElementById("prev-month")?.addEventListener("click",()=>{cursor.setMonth(cursor.getMonth()-1);App.render();});
    document.getElementById("next-month")?.addEventListener("click",()=>{cursor.setMonth(cursor.getMonth()+1);App.render();});
    document.getElementById("add-event")?.addEventListener("click",()=>form());

    document.querySelectorAll("[data-date]").forEach(b=>b.onclick=()=>form(b.dataset.date));
    document.querySelectorAll("[data-edit]").forEach(b=>b.onclick=()=>form("",b.dataset.edit));

    document.querySelectorAll("[data-delete]").forEach(b=>b.onclick=()=>{
      if(!confirm("일정을 삭제할까요?"))return;
      DB.set("calendar",DB.get("calendar",[]).filter(e=>e.id!==b.dataset.delete));
      App.render();
    });
  }

  return {page,bind};
})();
