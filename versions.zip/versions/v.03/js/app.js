
"use strict";

window.App = (() => {
  const routes = {
    "/": dashboard,
    "/documents": Docs.catalog,
    "/calendar": CalendarTool.page,
    "/applicants": Applicants.page,
    "/kpi": KPI.page,
    "/onboarding": Onboarding.page,
    "/trends": trends
  };

  HFData.steps.forEach(s=>{
    routes["/"+s.id]=()=>Guides.page(s.id);
  });

  function dashboard() {
    const applicants=DB.get("applicants",[]);
    const events=DB.get("calendar",[]);
    const active=applicants.filter(p=>!["합격","불합격"].includes(p.stage)).length;

    return `
      <div class="page-heading">
        <div><span class="eyebrow">HUMAN RESOURCES / WORKSPACE</span>
        <h1>HR 운영 현황</h1><p>채용 업무와 인재 확보 현황을 확인합니다.</p></div>
        <span class="count-label">${HF.today()}</span>
      </div>

      <div class="metric-grid">
        <div class="metric-card"><span>전체 지원자</span><strong>${applicants.length}</strong></div>
        <div class="metric-card"><span>진행 중 지원자</span><strong>${active}</strong></div>
        <div class="metric-card"><span>등록 일정</span><strong>${events.length}</strong></div>
        <div class="metric-card"><span>온보딩 인원</span><strong>${DB.get("onboarding",[]).length}</strong></div>
      </div>

      <section class="panel">
        <div class="section-title"><div><span class="eyebrow">WORKFLOW</span><h2>채용 프로세스</h2></div></div>
        <div class="workflow-list">
          ${HFData.steps.map((s,i)=>`
            <a class="workflow-row" href="#/${s.id}">
              <span class="workflow-number">${String(i+1).padStart(2,"0")}</span>
              <span class="workflow-info"><strong>${s.name}</strong><small>${s.desc}</small></span>
              <span class="workflow-arrow">→</span>
            </a>`).join("")}
        </div>
      </section>

      <section class="panel">
        <div class="section-title"><h2>주요 업무 도구</h2></div>
        <div class="tool-grid">
          ${[
            ["/documents","문서 자료실","표준 양식 및 문서 작성"],
            ["/calendar","채용 캘린더","전형별 일정 관리"],
            ["/applicants","지원자 관리","지원 현황 및 평가"],
            ["/kpi","채용 성과 분석","채용 데이터 측정"],
            ["/onboarding","온보딩 관리","입사자 적응 관리"],
            ["/trends","HR 트렌드","HR 운영 개선 방향"]
          ].map(([url,title,desc])=>`
            <a href="#${url}" class="tool-card"><strong>${title}</strong><p>${desc}</p></a>`).join("")}
        </div>
      </section>
    `;
  }

  function trends() {
    const items=[
      ["AI 채용 보조","공고 작성, 일정 조율, 반복 행정 업무 자동화. AI의 추천은 담당자 검토 후 활용."],
      ["스킬 기반 채용","학력과 경력 연수뿐 아니라 직무 과제와 실무 역량을 평가."],
      ["구조화 면접","공통 질문, 동일 평가 척도, 평가 근거 기록으로 면접 일관성 확보."],
      ["후보자 경험","지원 접수부터 결과 통보까지 일정과 진행 상태를 투명하게 안내."],
      ["채용 데이터 분석","직무·채널별 전환율, 채용 소요일, 오퍼 수락률을 비교."],
      ["공정한 평가","직무 관련 기준을 사전에 정하고 일관된 평가 절차 적용."]
    ];

    return `<div class="page-heading"><div><span class="eyebrow">HR INSIGHT</span>
      <h1>HR 트렌드</h1><p>주요 인재 확보 및 HR 운영 방향</p></div></div>
      <div class="trend-grid">${items.map(([a,b])=>`
        <article class="panel"><span class="eyebrow">HR PRACTICE</span><h2>${a}</h2><p>${b}</p></article>`).join("")}</div>`;
  }

  function shell() {
    const groups=[
      ["WORKSPACE",[["/","대시보드"]]],
      ["RECRUITMENT",HFData.steps.map(s=>["/"+s.id,s.name])],
      ["MANAGEMENT",[
        ["/documents","문서 자료실"],["/calendar","채용 캘린더"],
        ["/applicants","지원자 관리"],["/kpi","KPI 분석"],
        ["/onboarding","온보딩 관리"],["/trends","HR 트렌드"]
      ]]
    ];

    document.getElementById("app").innerHTML=`
      <aside class="sidebar" id="sidebar">
        <div class="brand">hireflow<span>.</span><small>PEOPLE OPERATIONS</small></div>
        ${groups.map(([title,links])=>`
          <div class="nav-group"><span>${title}</span>
          ${links.map(([url,name])=>`<a href="#${url}" data-nav="${url}">${name}</a>`).join("")}
          </div>`).join("")}
        <div class="sidebar-bottom">HR WORKSPACE<br>LOCAL VERSION 2.0</div>
      </aside>
      <main class="main-area">
        <header class="topbar">
          <button class="icon-button" id="toggle-menu">☰</button>
          <span>Human Resources / Operations</span>
        </header>
        <div class="content-area" id="content"></div>
        <footer>HIREFLOW · Internal HR Workspace</footer>
      </main>`;
  }

  function render() {
    const path=location.hash.slice(1).split("?")[0]||"/";
    const content=document.getElementById("content");
    content.innerHTML=(routes[path]||dashboard)();

    document.querySelectorAll("[data-nav]").forEach(a=>{
      a.classList.toggle("active",a.dataset.nav===path);
    });

    Docs.bind();
    Guides.bind();
    CalendarTool.bind();
    Applicants.bind();
    KPI.bind();
    Onboarding.bind();
  }

  function init() {
    shell();
    document.getElementById("toggle-menu").onclick=()=>{
      document.getElementById("sidebar").classList.toggle("mobile-open");
    };
    window.addEventListener("hashchange",render);
    if(!location.hash)location.hash="#/";
    else render();
  }

  return {init,render};
})();

App.init();
