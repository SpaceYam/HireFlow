
"use strict";

window.HF = {
  version: "2.0.0",
  today: () => new Date().toISOString().slice(0, 10),
  id: () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7),
  esc: value => String(value ?? "").replace(/[&<>"']/g, c =>
    ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" })[c]
  )
};

window.DB = {
  get(key, fallback = []) {
    try {
      return JSON.parse(localStorage.getItem("hf_" + key)) ?? fallback;
    } catch {
      return fallback;
    }
  },

  set(key, value) {
    try {
      localStorage.setItem("hf_" + key, JSON.stringify(value));
      return true;
    } catch {
      alert("저장 공간이 부족하거나 저장할 수 없습니다.");
      return false;
    }
  },

  download(name, content, type = "text/html;charset=utf-8") {
    const blob = new Blob(["\uFEFF", content], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = name;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  },

  modal(content, title = "업무 상세") {
    this.close();

    const modal = document.createElement("div");
    modal.id = "hf-modal";
    modal.className = "modal";
    modal.innerHTML = `
      <div class="modal-panel">
        <div class="modal-head">
          <strong>${HF.esc(title)}</strong>
          <button class="icon-button" data-close>×</button>
        </div>
        <div class="modal-body">${content}</div>
      </div>
    `;

    document.body.appendChild(modal);
    modal.addEventListener("click", e => {
      if (e.target === modal || e.target.closest("[data-close]")) {
        this.close();
      }
    });
  },

  close() {
    document.getElementById("hf-modal")?.remove();
  }
};
