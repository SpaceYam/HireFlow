
"use strict";

window.Applicants = (() => {
  const stages=["지원","서류검토","면접","최종평가","합격","불합격"];

  function page() {
    const list=DB.get("applicants",[]);
    return `
      <div class="page-heading">
        <div><span class="eyebrow">CANDIDATE MANAGEMENT</span>
        <h1>지원자 관리</h1><p>지원자별 전형 상태와 평가 기록을 관리합니다.</p></div>
        <button class="button primary" id="add-person">지원자 등록</button>
      </div>
      <div class="panel">
        <div class="filter-bar">
          <input id="person-search" placeholder="이름 또는 직무 검색">
          <select id="stage-filter"><option value="">전체 단계</option>
            ${stages.map(s=>`<option>${s}</option>`).join("")}
          </select>
        </div>
        <div class="table-wrap"><table>
          <thead><tr><th>이름</th><th>직무</th><th>지원일</th><th>전형</th><th>평가</th><th>관리</th></tr></thead>
          <tbody id="person-rows">
          ${list.map(p=>`
            <tr data-person-row data-name="${HF.esc(p.name+p.job)}" data-status="${p.stage}">
              <td>${HF.esc(p.name)}</td><td>${HF.esc(p.job)}</td><td>${HF.esc(p.date)}</td>
              <td><select data-stage="${p.id}">${stages.map(s=>`<option ${p.stage===s?"selected":""}>${s}</option>`).join("")}</select></td>
              <td><button class="text-button" data-eval="${p.id}">평가 기록</button></td>
              <td><button class="text-button danger-text" data-remove="${p.id}">삭제</button></td>
            </tr>`).join("")}
          </tbody>
        </table></div>
      </div>`;
  }

  function add() {
    DB.modal(`<h2>지원자 등록</h2><form id="person-form">
      <div class="form-grid">
        <label>이름<input name="name" required></label>
        <label>지원 직무<input name="job" required></label>
        <label>이메일<input name="email" type="email"></label>
        <label>연락처<input name="phone"></label>
        <label>지원일<input name="date" type="date" value="${HF.today()}"></label>
      </div><button class="button primary full">등록하기</button>
    </form>`);
    document.getElementById("person-form").onsubmit=e=>{
      e.preventDefault();
      const data=Object.fromEntries(new FormData(e.target));
      const list=DB.get("applicants",[]);
      list.push({...data,id:HF.id(),stage:"지원"});
      if(DB.set("applicants",list)){DB.close();App.render();}
    };
  }

  function evaluate(id) {
    const p=DB.get("applicants",[]).find(v=>v.id===id);
    if(!p)return;
    const old=DB.get("evaluation_"+id,{});
    DB.modal(`<h2>${HF.esc(p.name)} · 평가 기록</h2>
      <form id="eval-form">
        ${["전문성","문제 해결","의사소통","협업","성장 가능성"].map((s,i)=>`
          <label>${s}
            <select name="s${i}">
              ${[1,2,3,4,5].map(n=>`<option ${Number(old["s"+i])===n?"selected":""}>${n}</option>`).join("")}
            </select>
          </label>`).join("")}
        <label>평가 근거<textarea name="memo">${HF.esc(old.memo)}</textarea></label>
        <button class="button primary full">평가 저장</button>
      </form>`);
    document.getElementById("eval-form").onsubmit=e=>{
      e.preventDefault();
      const data=Object.fromEntries(new FormData(e.target));
      data.average=(["s0","s1","s2","s3","s4"].reduce((n,k)=>n+Number(data[k]),0)/5).toFixed(2);
      DB.set("evaluation_"+id,data);
      DB.close();
      alert("평가가 저장되었습니다.");
    };
  }

  function bind() {
    document.getElementById("add-person")?.addEventListener("click",add);
    document.querySelectorAll("[data-stage]").forEach(s=>s.onchange=()=>{
      const list=DB.get("applicants",[]), p=list.find(v=>v.id===s.dataset.stage);
      if(p){p.stage=s.value;DB.set("applicants",list);}
    });
    document.querySelectorAll("[data-eval]").forEach(b=>b.onclick=()=>evaluate(b.dataset.eval));
    document.querySelectorAll("[data-remove]").forEach(b=>b.onclick=()=>{
      if(confirm("지원자를 삭제할까요?")){
        DB.set("applicants",DB.get("applicants",[]).filter(p=>p.id!==b.dataset.remove));App.render();
      }
    });

    const filter=()=>{
      const q=document.getElementById("person-search").value.toLowerCase();
      const stage=document.getElementById("stage-filter").value;
      document.querySelectorAll("[data-person-row]").forEach(r=>{
        r.hidden=!r.dataset.name.toLowerCase().includes(q)||(stage&&r.dataset.status!==stage);
      });
    };
    document.getElementById("person-search").oninput=filter;
    document.getElementById("stage-filter").onchange=filter;
  }

  return {page,bind};
})();
