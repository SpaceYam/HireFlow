
"use strict";

window.Guides = (() => {
  function page(id) {
    const step = HFData.steps.find(s => s.id === id);
    if (!step) return "<h1>페이지를 찾을 수 없습니다.</h1>";

    const state = DB.get("tasks_" + id, []);
    const done = step.tasks.filter((_,i) => state.includes(i)).length;

    return `
      <div class="page-heading">
        <div>
          <span class="eyebrow">RECRUITMENT WORKFLOW</span>
          <h1>${HF.esc(step.name)}</h1>
          <p>${HF.esc(step.desc)}</p>
        </div>
        <span class="status-label">${done}/${step.tasks.length} 완료</span>
      </div>

      <div class="guide-overview">
        <div>
          <span>주관 담당</span>
          <strong>${HF.esc(step.owner)}</strong>
        </div>
        <div>
          <span>필수 산출물</span>
          <strong>${HF.esc(step.output)}</strong>
        </div>
        <div>
          <span>업무 진행률</span>
          <strong>${Math.round(done/step.tasks.length*100)}%</strong>
        </div>
      </div>

      <section class="panel">
        <div class="section-title">
          <div>
            <span class="eyebrow">TASK MANAGEMENT</span>
            <h2>실무 체크리스트</h2>
          </div>
          <span>${done} / ${step.tasks.length}</span>
        </div>
        <div class="progress-track">
          <div class="progress-fill" style="width:${done/step.tasks.length*100}%"></div>
        </div>
        ${step.tasks.map((task,i) => `
          <button class="task-item" data-guide="${id}" data-index="${i}">
            <span class="task-check">${state.includes(i) ? "✓" : ""}</span>
            <span class="task-name">${HF.esc(task)}</span>
            <span class="task-arrow">상세 →</span>
          </button>
        `).join("")}
      </section>

      <section class="panel">
        <div class="section-title">
          <div>
            <span class="eyebrow">DELIVERABLE</span>
            <h2>필수 산출물</h2>
          </div>
        </div>
        <div class="deliverable-row">
          <div>
            <strong>${HF.esc(step.output)}</strong>
            <p>표준 양식 및 작성 가이드를 확인하세요.</p>
          </div>
          <button class="button outline" data-output="${id}">양식 열기</button>
        </div>
      </section>
    `;
  }

  function open(id,index) {
    const step = HFData.steps.find(s => s.id === id);
    const task = step?.tasks[index];
    if (!task) return;

    const state = DB.get("tasks_" + id, []);
    const checked = state.includes(index);

    DB.modal(`
      <span class="eyebrow">${HF.esc(step.name)} · 업무 실행</span>
      <h2>${HF.esc(task)}</h2>

      <div class="guide-overview">
        <div><span>담당</span><strong>${HF.esc(step.owner)}</strong></div>
        <div><span>산출물</span><strong>${HF.esc(step.output)}</strong></div>
      </div>

      <h3>업무 수행 기록</h3>
      <label>실행 내용
        <textarea id="task-note" rows="5"
          placeholder="실제 수행한 업무와 확인 사항을 기록하세요.">${HF.esc(DB.get("note_" + id + "_" + index, ""))}</textarea>
      </label>

      <div class="guide-tip">
        <strong>실무 확인 사항</strong>
        <p>담당자, 완료 기준, 관련 증빙 자료를 확인한 뒤 업무를 완료하세요.</p>
      </div>

      <label class="check-control">
        <input type="checkbox" id="task-done" ${checked ? "checked" : ""}>
        해당 업무 완료
      </label>

      <button class="button primary full" id="save-task">저장하기</button>
    `, "업무 실행 상세");

    document.getElementById("save-task").onclick = () => {
      const notes = document.getElementById("task-note").value;
      const done = document.getElementById("task-done").checked;
      let current = DB.get("tasks_" + id, []);

      current = done
        ? [...new Set([...current,index])]
        : current.filter(v => v !== index);

      DB.set("tasks_" + id, current);
      DB.set("note_" + id + "_" + index, notes);
      DB.close();
      App.render();
    };
  }

  function bind() {
    document.querySelectorAll("[data-guide]").forEach(button => {
      button.onclick = () => open(
        button.dataset.guide,
        Number(button.dataset.index)
      );
    });

    document.querySelectorAll("[data-output]").forEach(button => {
      button.onclick = () => {
        const id = button.dataset.output;
        const map = {
          request:"request", planning:"jd", posting:"posting",
          screening:"screening", interview:"interview",
          offer:"offer", onboarding:"onboarding"
        };
        Docs.open(map[id] || "request");
      };
    });
  }

  return { page, open, bind };
})();
