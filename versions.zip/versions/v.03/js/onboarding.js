
"use strict";

window.Onboarding = (() => {
  function page() {
    const list=DB.get("onboarding",[]);
    return `
      <div class="page-heading">
        <div><span class="eyebrow">EMPLOYEE EXPERIENCE</span>
        <h1>온보딩 관리</h1><p>신규 입사자의 초기 적응과 성과를 관리합니다.</p></div>
        <button class="button primary" id="new-onboard">입사자 등록</button>
      </div>

      ${list.map(p=>{
        const done=["d30","d60","d90"].filter(k=>p[k]).length;
        return `
          <section class="panel">
            <div class="section-title">
              <div><h2>${HF.esc(p.name)}</h2>
              <p>${HF.esc(p.position)} · 입사 ${HF.esc(p.date)}</p></div>
              <span>${Math.round(done/3*100)}% 완료</span>
            </div>
            <div class="progress-track"><div class="progress-fill" style="width:${done/3*100}%"></div></div>
            <div class="onboard-grid">
              ${[["d30","30일 점검"],["d60","60일 점검"],["d90","90일 점검"]].map(([k,t])=>`
                <label class="check-control"><input type="checkbox" data-person="${p.id}" data-day="${k}" ${p[k]?"checked":""}>${t}</label>`).join("")}
            </div>
            <p>멘토: ${HF.esc(p.mentor||"-")}</p>
            <button class="text-button" data-detail="${p.id}">목표 상세 보기 →</button>
          </section>`;
      }).join("")||'<section class="panel">등록된 입사자가 없습니다.</section>'}
    `;
  }

  function add() {
    DB.modal(`<h2>입사자 등록</h2>
      <form id="onboard-form">
        <div class="form-grid">
          <label>이름<input name="name" required></label>
          <label>직무<input name="position" required></label>
          <label>입사일<input name="date" type="date" required></label>
          <label>멘토<input name="mentor"></label>
        </div>
        <label>30일 목표<textarea name="goal30"></textarea></label>
        <label>60일 목표<textarea name="goal60"></textarea></label>
        <label>90일 목표<textarea name="goal90"></textarea></label>
        <button class="button primary full">저장</button>
      </form>`);

    document.getElementById("onboard-form").onsubmit=e=>{
      e.preventDefault();
      const p=Object.fromEntries(new FormData(e.target));
      p.id=HF.id();p.d30=false;p.d60=false;p.d90=false;
      const list=DB.get("onboarding",[]);
      list.push(p);
      if(DB.set("onboarding",list)){DB.close();App.render();}
    };
  }

  function bind() {
    document.getElementById("new-onboard")?.addEventListener("click",add);

    document.querySelectorAll("[data-person]").forEach(c=>c.onchange=()=>{
      const list=DB.get("onboarding",[]);
      const p=list.find(v=>v.id===c.dataset.person);
      if(p){p[c.dataset.day]=c.checked;DB.set("onboarding",list);App.render();}
    });

    document.querySelectorAll("[data-detail]").forEach(b=>b.onclick=()=>{
      const p=DB.get("onboarding",[]).find(v=>v.id===b.dataset.detail);
      if(!p)return;
      DB.modal(`
        <h2>${HF.esc(p.name)} · 온보딩 목표</h2>
        ${[["30일",p.goal30],["60일",p.goal60],["90일",p.goal90]].map(([t,v])=>`
          <section class="guide-tip"><strong>${t} 목표</strong><p>${HF.esc(v||"미등록")}</p></section>`).join("")}
      `);
    });
  }

  return {page,bind};
})();
