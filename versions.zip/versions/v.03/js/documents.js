
"use strict";

window.Docs = (() => {
  const fields = {
    request: [
      ["department","요청 부서","text"],
      ["position","채용 직무","text"],
      ["count","채용 인원","number"],
      ["reason","채용 사유","textarea"],
      ["duties","주요 업무","textarea"],
      ["requirements","자격 요건","textarea"],
      ["budget","채용 예산","text"],
      ["deadline","희망 입사일","date"]
    ],
    jd: [
      ["department","소속 부서","text"],
      ["position","직무명","text"],
      ["purpose","직무 목적","textarea"],
      ["duties","주요 업무","textarea"],
      ["responsibility","핵심 책임","textarea"],
      ["requirements","필수 역량","textarea"],
      ["preferred","우대 사항","textarea"],
      ["performance","성과 기준","textarea"]
    ],
    schedule: [
      ["position","채용 직무","text"],
      ["owner","담당자","text"],
      ["start","채용 시작일","date"],
      ["posting","공고 게시일","date"],
      ["screening","서류 마감일","date"],
      ["interview","면접 예정일","date"],
      ["result","최종 발표일","date"],
      ["join","입사 예정일","date"]
    ],
    posting: [
      ["company","회사명","text"],
      ["position","채용 직무","text"],
      ["department","소속 부서","text"],
      ["intro","회사 및 팀 소개","textarea"],
      ["duties","주요 업무","textarea"],
      ["requirements","필수 요건","textarea"],
      ["preferred","우대 사항","textarea"],
      ["process","채용 절차","textarea"],
      ["contact","지원 문의","text"]
    ],
    screening: [
      ["candidate","지원자","text"],
      ["position","지원 직무","text"],
      ["experience","관련 경험","textarea"],
      ["expertise","직무 역량 점수","number"],
      ["fit","직무 적합도 점수","number"],
      ["comment","평가 의견","textarea"]
    ],
    interview: [
      ["candidate","지원자","text"],
      ["position","지원 직무","text"],
      ["interviewer","면접관","text"],
      ["date","면접일","date"],
      ["expertise","전문성 (1~5)","number"],
      ["problem","문제 해결 (1~5)","number"],
      ["communication","소통 능력 (1~5)","number"],
      ["collaboration","협업 능력 (1~5)","number"],
      ["comment","종합 의견","textarea"]
    ],
    offer: [
      ["candidate","지원자","text"],
      ["position","직무","text"],
      ["salary","제안 연봉","text"],
      ["employment","고용 형태","text"],
      ["start","입사 예정일","date"],
      ["deadline","수락 기한","date"],
      ["benefits","복리후생","textarea"]
    ],
    onboarding: [
      ["name","입사자","text"],
      ["position","직무","text"],
      ["mentor","멘토","text"],
      ["start","입사일","date"],
      ["day30","30일 목표","textarea"],
      ["day60","60일 목표","textarea"],
      ["day90","90일 목표","textarea"]
    ]
  };

  function catalog() {
    return `
      <div class="page-heading">
        <div>
          <span class="eyebrow">HR DOCUMENT CENTER</span>
          <h1>문서 자료실</h1>
          <p>채용 업무에 필요한 표준 양식을 작성하고 관리합니다.</p>
        </div>
        <span class="count-label">${HFData.docs.length}개 표준 양식</span>
      </div>

      <div class="filter-bar">
        <input id="doc-search" placeholder="문서명 또는 업무 검색">
        <select id="doc-category">
          <option value="">전체 단계</option>
          ${HFData.steps.map(s =>
            `<option>${HF.esc(s.name)}</option>`
          ).join("")}
        </select>
      </div>

      <div class="document-grid" id="doc-list">
        ${HFData.docs.map(item => card(item)).join("")}
      </div>
    `;
  }

  function card(item) {
    return `
      <article class="document-card"
        data-name="${HF.esc(item[1] + item[2] + item[3])}">
        <div class="doc-top">
          <span class="doc-type">${HF.esc(item[3])}</span>
          <span class="doc-symbol">DOC</span>
        </div>
        <h3>${HF.esc(item[1])}</h3>
        <p>${HF.esc(item[2])}</p>
        <button class="text-button" data-doc="${item[0]}">
          양식 작성하기 →
        </button>
      </article>
    `;
  }

  function open(type) {
    const template = HFData.docs.find(d => d[0] === type);
    if (!template || !fields[type]) return;

    const inputs = fields[type];

    DB.modal(`
      <div class="form-intro">
        <span class="eyebrow">DOCUMENT BUILDER</span>
        <h2>${template[1]}</h2>
        <p>${template[2]}</p>
      </div>
      <form id="doc-form">
        <div class="form-grid">
          ${inputs.map(([key,label,kind]) => `
            <label>${label}
              ${kind === "textarea"
                ? `<textarea name="${key}" rows="3" placeholder="${label} 입력"></textarea>`
                : `<input name="${key}" type="${kind}" ${kind === "number" ? 'min="0"' : ""} required>`
              }
            </label>
          `).join("")}
        </div>
        <div class="form-actions">
          <button type="button" class="button outline" id="doc-preview">미리보기</button>
          <button type="submit" class="button primary">문서 다운로드</button>
        </div>
      </form>
    `, template[1]);

    const form = document.getElementById("doc-form");
    const collect = () => Object.fromEntries(new FormData(form));

    function output() {
      const data = collect();
      const rows = inputs.map(([key,label]) => `
        <tr><th>${HF.esc(label)}</th>
        <td>${HF.esc(data[key]).replace(/\n/g,"<br>")}</td></tr>
      `).join("");

      return `<!DOCTYPE html>
      <html lang="ko"><meta charset="UTF-8">
      <title>${HF.esc(template[1])}</title>
      <style>
        body{font-family:Arial,sans-serif;margin:40px;color:#26352f}
        h1{text-align:center;margin-bottom:30px}
        table{width:100%;border-collapse:collapse}
        th,td{border:1px solid #ccc;padding:13px;text-align:left}
        th{background:#f1f3ef;width:25%}
      </style>
      <h1>${HF.esc(template[1])}</h1>
      <table>${rows}</table>
      <p>작성일: ${HF.today()}</p></html>`;
    }

    document.getElementById("doc-preview").onclick = () => {
      DB.download("preview_" + type + ".html", output());
    };

    form.onsubmit = e => {
      e.preventDefault();
      const data = collect();
      const saved = DB.get("documents", []);
      saved.push({ id:HF.id(), type, data, date:HF.today() });

      if (DB.set("documents", saved)) {
        DB.download("HIREFLOW_" + type + ".html", output());
        DB.close();
      }
    };
  }

  function bind() {
    document.querySelectorAll("[data-doc]").forEach(button => {
      button.onclick = () => open(button.dataset.doc);
    });

    const search = document.getElementById("doc-search");
    const category = document.getElementById("doc-category");

    function filter() {
      const q = search.value.toLowerCase();
      const c = category.value;

      document.querySelectorAll(".document-card").forEach(el => {
        const item = HFData.docs.find(d => d[1] + d[2] + d[3] === el.dataset.name);
        el.hidden = !(el.dataset.name.toLowerCase().includes(q) &&
          (!c || item?.[3] === c));
      });
    }

    search.oninput = filter;
    category.onchange = filter;
  }

  return { catalog, open, bind };
})();
