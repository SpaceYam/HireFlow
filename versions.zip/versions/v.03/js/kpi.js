
"use strict";

window.KPI = (() => {
  const fields=[
    ["지원자","applicants"],
    ["서류 합격자","passed"],
    ["면접 대상자","interviews"],
    ["최종 합격자","hired"],
    ["오퍼 발송","offers"],
    ["오퍼 수락","accepted"]
  ];

  const pct=(a,b)=>b?(a/b*100).toFixed(1)+"%":"-";

  function page() {
    const d=DB.get("kpi",{});
    const metrics=[
      ["서류 합격률",pct(d.passed||0,d.applicants||0)],
      ["면접 전환율",pct(d.interviews||0,d.passed||0)],
      ["최종 합격률",pct(d.hired||0,d.applicants||0)],
      ["오퍼 수락률",pct(d.accepted||0,d.offers||0)]
    ];

    return `
      <div class="page-heading"><div>
        <span class="eyebrow">RECRUITMENT ANALYTICS</span>
        <h1>채용 성과 분석</h1>
        <p>동일 채용 코호트의 전형별 전환율을 분석합니다.</p>
      </div></div>

      <section class="panel">
        <h2>채용 데이터 입력</h2>
        <div class="form-grid">
          ${fields.map(([label,key])=>`
            <label>${label}<input type="number" min="0" step="1"
              data-kpi="${key}" value="${d[key]??0}"></label>`).join("")}
          <label>채용 시작일<input type="date" data-kpi="start" value="${d.start||""}"></label>
          <label>입사일<input type="date" data-kpi="end" value="${d.end||""}"></label>
        </div>
        <button class="button primary" id="calc-kpi">지표 계산</button>
      </section>

      <div class="metric-grid" id="metrics">
        ${metrics.map(([label,value])=>`
          <div class="metric-card"><span>${label}</span><strong>${value}</strong></div>`).join("")}
      </div>

      <section class="panel">
        <h2>채용 소요일</h2>
        <div class="metric-card"><span>채용 시작일부터 입사일까지</span>
          <strong id="time-to-hire">-</strong></div>
        <p class="help-text">날짜 기준은 채용 시작일과 실제 입사일입니다.</p>
      </section>
    `;
  }

  function bind() {
    document.getElementById("calc-kpi")?.addEventListener("click",()=>{
      const d={};
      document.querySelectorAll("[data-kpi]").forEach(i=>{
        d[i.dataset.kpi]=i.type==="number"?Number(i.value):i.value;
      });

      const valid=fields.every(([,k])=>Number.isInteger(d[k])&&d[k]>=0);
      if(!valid){alert("0 이상의 정수를 입력하세요.");return;}

      if(d.passed>d.applicants||d.interviews>d.passed||
        d.hired>d.interviews||d.accepted>d.offers){
        alert("전형 단계별 인원수를 확인하세요.");return;
      }

      if(d.start&&d.end&&d.end<d.start){
        alert("입사일을 확인하세요.");return;
      }

      if(!DB.set("kpi",d))return;
      const values=[
        ["서류 합격률",pct(d.passed,d.applicants)],
        ["면접 전환율",pct(d.interviews,d.passed)],
        ["최종 합격률",pct(d.hired,d.applicants)],
        ["오퍼 수락률",pct(d.accepted,d.offers)]
      ];

      document.getElementById("metrics").innerHTML=values.map(([a,b])=>
        `<div class="metric-card"><span>${a}</span><strong>${b}</strong></div>`).join("");

      const days=d.start&&d.end
        ? Math.round((new Date(d.end+"T00:00:00")-new Date(d.start+"T00:00:00"))/86400000)
        : null;
      document.getElementById("time-to-hire").textContent=days===null?"-":days+"일";
    });
  }

  return {page,bind};
})();
