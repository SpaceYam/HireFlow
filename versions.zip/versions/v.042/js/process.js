
"use strict";

window.Process = (() => {
  const tasks = {
    planning:[
      ["인력 수요 분석","현재 인력과 사업 계획을 비교합니다.",["부서별 인력 현황 확인","업무량 분석","충원 사유 정의","채용 예산 확인"]],
      ["채용 요청 승인","채용 요청 및 승인 절차를 진행합니다.",["채용 요청서 작성","부서장 승인","HR 검토","최종 승인 기록"]],
      ["직무 분석","직무 목적과 핵심 역량을 정의합니다.",["직무 목적 정의","주요 업무 작성","필수 역량 정의","성과 기준 수립"]]
    ],
    posting:[
      ["채용 공고 작성","직무에 맞는 모집 공고를 작성합니다.",["직무기술서 확인","공고 제목 작성","자격 요건 작성","근무 조건 명시"]],
      ["채용 채널 선정","적합한 모집 채널을 선정합니다.",["모집 대상 분석","채널 선정","공고 게시","채널별 성과 확인"]]
    ],
    screening:[
      ["서류 검토 기준 수립","공정한 서류 평가 기준을 정의합니다.",["필수 요건 정의","평가 항목 설정","평가 척도 정의","평가자 기준 공유"]],
      ["지원자 서류 평가","사전 정의된 기준으로 평가합니다.",["지원서 확인","직무 경험 검토","성과 확인","평가 근거 기록"]]
    ],
    interview:[
      ["면접 질문 설계","직무 역량을 검증할 질문을 설계합니다.",["핵심 역량 선정","공통 질문 설계","평가 척도 작성","면접관 공유"]],
      ["면접 진행","일관된 면접 절차를 운영합니다.",["면접 일정 확인","지원자 안내","공통 질문 진행","평가 결과 기록"]]
    ],
    assessment:[
      ["직무 과제 평가","실제 업무와 연관된 과제를 평가합니다.",["과제 설계","제출 기준 안내","과제 수행","평가 결과 기록"]]
    ],
    decision:[
      ["최종 평가","전형별 결과를 종합합니다.",["전형별 결과 취합","평가 근거 검토","최종 의견 작성","채용 승인"]],
      ["오퍼 및 입사 확정","근로 조건을 안내하고 입사를 확정합니다.",["보상 조건 검토","오퍼 전달","입사 의사 확인","입사 일정 확정"]]
    ],
    onboarding:[
      ["입사 준비","입사 전 업무 환경을 준비합니다.",["입사 서류 준비","계정 발급","장비 준비","멘토 지정"]],
      ["30·60·90일 적응 관리","신규 입사자의 적응을 관리합니다.",["30일 조직 이해","60일 업무 수행","90일 성과 확인","적응도 피드백"]]
    ]
  };

  function page(id) {
    const step=HF.steps.find(s=>s.id===id);
    if(!step)return "<h1>페이지를 찾을 수 없습니다.</h1>";

    const list=tasks[id]||[];
    const progress=DB.get("tasks");
    const saved=progress[id]||{};

    return `
      <nav class="breadcrumb">
        <a href="#/">대시보드</a>
        <span>›</span>
        <span>채용 프로세스</span>
        <span>›</span>
        <strong>${DB.esc(step.name)}</strong>
      </nav>

      <section class="page-header">
        <span class="tag">RECRUITMENT PROCESS</span>
        <h1>${DB.esc(step.name)}</h1>
        <p>${DB.esc(step.description)}</p>
      </section>

      <section class="card">
        <div class="section-heading">
          <h2>업무 진행 현황</h2>
          <strong id="process-progress">${calc(id,list,saved)}%</strong>
        </div>
        <div class="progress process-progress">
          <span id="process-progress-bar" style="width:${calc(id,list,saved)}%"></span>
        </div>
      </section>

      <div class="task-grid">
        ${list.map(([title,desc,items],i)=>`
          <article class="task-card">
            <span class="task-number">TASK 0${i+1}</span>
            <h3>${DB.esc(title)}</h3>
            <p>${DB.esc(desc)}</p>

            <div class="task-checklist">
              ${items.map((item,j)=>{
                const key=i+"_"+j;
                return `
                  <label class="task-check">
                    <input type="checkbox" data-process-check="${key}"
                      ${saved[key]?"checked":""}>
                    <span>${DB.esc(item)}</span>
                  </label>
                `;
              }).join("")}
            </div>

            <button class="btn secondary small"
              data-process-doc="${i}">
              관련 양식 열기
            </button>
          </article>
        `).join("")}
      </div>

      <section class="card">
        <h2>관련 HR 업무 도구</h2>
        <a href="#/documents" class="btn">문서 자료실</a>
        <a href="#/calendar" class="btn secondary">채용 캘린더</a>
      </section>
    `;
  }

  function calc(id,list,saved) {
    const total=list.reduce((n,t)=>n+t[2].length,0);
    const done=Object.values(saved).filter(Boolean).length;
    return total?Math.round(done/total*100):0;
  }

  function bind() {
    document.querySelectorAll("[data-process-check]").forEach(input=>{
      input.onchange=()=>{
        const id=location.hash.slice(2);
        const saved=DB.get("tasks");
        saved[id]=saved[id]||{};
        saved[id][input.dataset.processCheck]=input.checked;
        DB.set("tasks",saved);

        const list=tasks[id]||[];
        const percent=calc(id,list,saved[id]);
        document.getElementById("process-progress").textContent=percent+"%";
        document.getElementById("process-progress-bar").style.width=percent+"%";
      };
    });

    document.querySelectorAll("[data-process-doc]").forEach(button=>{
      button.onclick=()=>{
        const id=location.hash.slice(2);
        const mapping={
          planning:"request",posting:"posting",
          screening:"interview",interview:"interview",
          assessment:"interview",decision:"final",
          onboarding:"onboarding"
        };
        Docs.open(mapping[id]);
      };
    });
  }

  return {page,bind};
})();
