
"use strict";

window.CalendarTool = (() => {
  let year=new Date().getFullYear();
  let month=new Date().getMonth();
  let selected=DB.today();

  const types={
    "서류 전형":"blue",
    "면접":"purple",
    "과제 평가":"orange",
    "최종 발표":"green",
    "입사":"teal",
    "기타":"gray"
  };

  function dateString(y,m,d) {
    return `${y}-${String(m+1).padStart(2,"0")}-${String(d).padStart(2,"0")}`;
  }

  function page() {
    const events=DB.get("calendar");
    const first=new Date(year,month,1);
    const start=new Date(year,month,1-first.getDay());
    const cells=[];

    for(let i=0;i<42;i++){
      const d=new Date(start);
      d.setDate(start.getDate()+i);
      const key=dateString(d.getFullYear(),d.getMonth(),d.getDate());
      const dayEvents=events.filter(e=>e.date===key);

      cells.push(`
        <div class="calendar-day
          ${d.getMonth()!==month?"other-month":""}
          ${key===DB.today()?"today":""}
          ${key===selected?"selected-day":""}"
          data-day="${key}">
          <button class="calendar-date">${d.getDate()}</button>
          <div class="calendar-events">
            ${dayEvents.slice(0,3).map(e=>`
              <button class="calendar-event event-${types[e.type]||"gray"}"
                data-event="${e.id}" title="${DB.esc(e.title)}">
                ${DB.esc(e.time||"")} ${DB.esc(e.title)}
              </button>
            `).join("")}
            ${dayEvents.length>3?`<span class="more-events">+${dayEvents.length-3}개</span>`:""}
          </div>
        </div>
      `);
    }

    return `
      <section class="page-header">
        <span class="tag">RECRUITMENT SCHEDULE</span>
        <h1>채용 캘린더</h1>
        <p>채용 전형과 면접 일정을 월간 달력으로 관리합니다.</p>
      </section>

      <section class="card calendar-card">
        <div class="calendar-toolbar">
          <div>
            <h2 id="calendar-month">${year}년 ${month+1}월</h2>
            <p>MONTHLY SCHEDULE</p>
          </div>
          <div class="calendar-controls">
            <button class="btn secondary" id="calendar-prev">←</button>
            <button class="btn secondary" id="calendar-today">오늘</button>
            <button class="btn secondary" id="calendar-next">→</button>
            <button class="btn" id="calendar-add">+ 일정 등록</button>
          </div>
        </div>

        <div class="calendar-legend">
          ${Object.entries(types).map(([name,color])=>`
            <span><i class="legend-${color}"></i>${name}</span>
          `).join("")}
        </div>

        <div class="calendar-grid">
          ${["일","월","화","수","목","금","토"].map(x=>`
            <div class="calendar-weekday">${x}</div>
          `).join("")}
          ${cells.join("")}
        </div>
      </section>

      <section class="card">
        <h2 id="selected-date-title">${selected} 일정</h2>
        <div id="selected-events">${eventList(selected,events)}</div>
      </section>
    `;
  }

  function eventList(date,events=DB.get("calendar")) {
    const items=events.filter(e=>e.date===date);
    if(!items.length)return '<div class="empty">선택한 날짜에 일정이 없습니다.</div>';

    return items.sort((a,b)=>(a.time||"").localeCompare(b.time||""))
      .map(e=>`
        <div class="calendar-list-item">
          <i class="event-dot dot-${types[e.type]||"gray"}"></i>
          <div class="event-info">
            <strong>${DB.esc(e.title)}</strong>
            <p>${DB.esc(e.type)} · ${DB.esc(e.person||"공통")}</p>
          </div>
          <strong>${DB.esc(e.time||"시간 미정")}</strong>
          <button class="btn danger small" data-delete-event="${e.id}">삭제</button>
        </div>
      `).join("");
  }

  function add() {
    DB.modal(`
      <h2>채용 일정 등록</h2>
      <form id="calendar-form">
        <div class="form-grid">
          <label class="field"><span>일정명</span><input name="title" required></label>
          <label class="field"><span>일정 유형</span>
            <select name="type">
              ${Object.keys(types).map(x=>`<option>${x}</option>`).join("")}
            </select>
          </label>
          <label class="field"><span>날짜</span><input name="date" type="date" value="${selected}" required></label>
          <label class="field"><span>시간</span><input name="time" type="time"></label>
          <label class="field"><span>지원자 또는 담당자</span><input name="person"></label>
        </div>
        <div class="form-actions"><button class="btn">일정 저장</button></div>
      </form>
    `);

    document.getElementById("calendar-form").onsubmit=e=>{
      e.preventDefault();
      const fd=new FormData(e.target);
      const events=DB.get("calendar");
      events.push({
        id:DB.uid(),
        title:fd.get("title"),
        type:fd.get("type"),
        date:fd.get("date"),
        time:fd.get("time"),
        person:fd.get("person")
      });
      DB.set("calendar",events);
      selected=fd.get("date");
      year=Number(selected.slice(0,4));
      month=Number(selected.slice(5,7))-1;
      DB.close();
      App.render();
    };
  }

  function bind() {
    document.getElementById("calendar-prev")?.addEventListener("click",()=>{
      month--;
      if(month<0){month=11;year--;}
      App.render();
    });

    document.getElementById("calendar-next")?.addEventListener("click",()=>{
      month++;
      if(month>11){month=0;year++;}
      App.render();
    });

    document.getElementById("calendar-today")?.addEventListener("click",()=>{
      const d=new Date();
      year=d.getFullYear();
      month=d.getMonth();
      selected=DB.today();
      App.render();
    });

    document.getElementById("calendar-add")?.addEventListener("click",add);

    document.querySelectorAll("[data-day]").forEach(el=>{
      el.onclick=e=>{
        if(e.target.closest("[data-event]"))return;
        selected=el.dataset.day;
        document.getElementById("selected-date-title").textContent=selected+" 일정";
        document.getElementById("selected-events").innerHTML=eventList(selected);
        document.querySelectorAll("[data-day]").forEach(x=>
          x.classList.toggle("selected-day",x.dataset.day===selected)
        );
        bindDelete();
      };
    });

    bindDelete();
  }

  function bindDelete() {
    document.querySelectorAll("[data-delete-event]").forEach(button=>{
      button.onclick=()=>{
        if(!DB.confirmDelete("이 일정을 삭제할까요?"))return;
        DB.set("calendar",DB.get("calendar").filter(e=>e.id!==button.dataset.deleteEvent));
        App.render();
      };
    });

    document.querySelectorAll("[data-event]").forEach(button=>{
      button.onclick=e=>{
        e.stopPropagation();
        const event=DB.get("calendar").find(x=>x.id===button.dataset.event);
        if(!event)return;
        DB.modal(`
          <h2>${DB.esc(event.title)}</h2>
          <div class="detail-list">
            <p><strong>날짜</strong>${event.date}</p>
            <p><strong>시간</strong>${DB.esc(event.time||"-")}</p>
            <p><strong>유형</strong>${DB.esc(event.type)}</p>
            <p><strong>대상</strong>${DB.esc(event.person||"-")}</p>
          </div>
        `);
      };
    });
  }

  return {page,bind};
})();
