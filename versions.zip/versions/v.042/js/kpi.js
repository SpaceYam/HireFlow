
"use strict";

window.KPI = (() => {
  function metrics(data) {
    const applicants=Number(data.applicants)||0;
    const documents=Number(data.documents)||0;
    const interviews=Number(data.interviews)||0;
    const offers=Number(data.offers)||0;
    const hires=Number(data.hires)||0;
    const days=Number(data.days)||0;

    return {
      documentRate:applicants?documents/applicants*100:0,
      interviewRate:documents?interviews/documents*100:0,
      offerRate:interviews?offers/interviews*100:0,
      acceptanceRate:offers?hires/offers*100:0,
      totalRate:applicants?hires/applicants*100:0,
      averageDays:days
    };
  }

  function page() {
    const people=DB.get("applicants");
    const events=DB.get("calendar");
    const hires=people.filter(p=>p.stage==="최종 합격").length;
    const active=people.length-hires-people.filter(p=>p.stage==="불합격").length;

    return `
      <section class="page-header">
        <span class="tag">RECRUITMENT ANALYTICS</span>
        <h1>KPI 분석</h1>
        <p>채용 성과를 수치로 확인하고 운영 효율을 분석합니다.</p>
      </section>

      <div class="stats-grid">
        ${[
          ["전체 지원자",people.length],
          ["진행 중 지원자",active],
          ["최종 합격",hires],
          ["채용 일정",events.length]
        ].map(([label,value])=>`
          <article class="card">
            <span class="stat-label">${label}</span>
            <div class="stat-value">${value}</div>
          </article>
        `).join("")}
      </div>

      <section class="card">
        <h2>채용 단계별 현황</h2>
        <div class="bar-chart">
          ${["서류 검토","면접 예정","최종 합격","불합격"].map((stage,i)=>{
            const count=people.filter(p=>p.stage===stage).length;
            const max=Math.max(people.length,1);
            return `
              <div class="bar-item">
                <span>${stage}</span>
                <div class="progress"><span style="width:${count/max*100}%"></span></div>
                <strong>${count}</strong>
              </div>
            `;
          }).join("")}
        </div>
      </section>

      <section class="card">
        <span class="tag">KPI SIMULATOR</span>
        <h2>채용 성과 시뮬레이션</h2>
        <p>예상 채용 데이터를 입력해 전환율과 최종 채용률을 계산합니다.</p>

        <form id="kpi-form">
          <div class="form-grid">
            ${[
              ["applicants","전체 지원자 수",100],
              ["documents","서류 통과자 수",50],
              ["interviews","면접 대상자 수",30],
              ["offers","오퍼 발송 수",10],
              ["hires","최종 입사자 수",8],
              ["days","평균 채용 소요일",35]
            ].map(([name,label,value])=>`
              <label class="field">
                <span>${label}</span>
                <input type="number" min="0" name="${name}" value="${value}" required>
              </label>
            `).join("")}
          </div>
          <div class="form-actions">
            <button type="reset" class="btn secondary">초기화</button>
            <button class="btn">시뮬레이션 실행</button>
          </div>
        </form>

        <div id="kpi-result" class="simulation-result">
          <div class="empty">숫자를 입력하고 시뮬레이션을 실행하세요.</div>
        </div>
      </section>
    `;
  }

  function bind() {
    const form=document.getElementById("kpi-form");
    if(!form)return;

    form.onsubmit=e=>{
      e.preventDefault();
      const fd=new FormData(form);
      const data=Object.fromEntries(fd.entries());

      const a=Number(data.applicants);
      const d=Number(data.documents);
      const i=Number(data.interviews);
      const o=Number(data.offers);
      const h=Number(data.hires);

      if(d>a||i>d||o>i||h>o){
        document.getElementById("kpi-result").innerHTML=`
          <div class="validation-error">
            입력 데이터의 순서를 확인하세요.<br>
            지원자 ≥ 서류 통과자 ≥ 면접 대상자 ≥ 오퍼 ≥ 입사자여야 합니다.
          </div>`;
        return;
      }

      const result=metrics(data);
      const items=[
        ["서류 통과율",result.documentRate],
        ["면접 전환율",result.interviewRate],
        ["오퍼 전환율",result.offerRate],
        ["오퍼 수락률",result.acceptanceRate],
        ["최종 채용률",result.totalRate]
      ];

      document.getElementById("kpi-result").innerHTML=`
        <h3>시뮬레이션 결과</h3>
        <div class="simulation-grid">
          ${items.map(([label,value])=>`
            <div class="simulation-metric">
              <span>${label}</span>
              <strong>${value.toFixed(1)}%</strong>
            </div>
          `).join("")}
          <div class="simulation-metric">
            <span>평균 채용 소요일</span>
            <strong>${result.averageDays}일</strong>
          </div>
        </div>
      `;
    };
  }

  return {page,bind};
})();
