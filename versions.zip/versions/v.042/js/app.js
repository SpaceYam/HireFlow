
"use strict";

window.App = (() => {
  const routes = {
    "/":dashboard,
    "/documents":()=>Docs.catalog(),
    "/calendar":()=>CalendarTool.page(),
    "/kpi":()=>KPI.page(),
    "/applicants":()=>Applicants.page(),
    "/onboarding":()=>Onboarding.page(),
    "/backup":()=>Backup.page(),
    "/notes":()=>Notes.page(),
    "/trends":trends
  };

  HF.steps.forEach(step=>{
    routes["/"+step.id]=()=>Process.page(step.id);
  });

  function dashboard() {
    const applicants=DB.get("applicants");
    const events=DB.get("calendar");
    const onboarding=DB.get("onboarding");
    const notes=DB.get("notes");
    const today=events.filter(e=>e.date===DB.today());

    return `
      <section class="page-header">
        <span class="tag">HIREFLOW WORKSPACE</span>
        <h1>안녕하세요, HR Manager.</h1>
        <p>오늘의 채용 현황과 인사 업무를 확인하세요.</p>
      </section>

      <div class="stats-grid">
        ${[
          ["전체 지원자",applicants.length],
          ["진행 중 지원자",applicants.filter(p=>!["최종 합격","불합격"].includes(p.stage)).length],
          ["전체 채용 일정",events.length],
          ["온보딩 대상자",onboarding.length]
        ].map(([label,value])=>`
          <article class="card">
            <span class="stat-label">${label}</span>
            <div class="stat-value">${value}</div>
          </article>
        `).join("")}
      </div>

      <div class="dashboard-grid">
        <section class="card">
          <div class="section-heading">
            <h2>오늘의 채용 일정</h2>
            <a href="#/calendar">전체 보기 →</a>
          </div>
          ${today.map(e=>`
            <div class="event-row">
              <strong>${DB.esc(e.title)}</strong>
              <span>${DB.esc(e.time||"")}</span>
            </div>
          `).join("")||'<div class="empty">오늘 예정된 일정이 없습니다.</div>'}
        </section>

        <section class="card">
          <div class="section-heading">
            <h2>개인 메모</h2>
            <a href="#/notes">전체 보기 →</a>
          </div>
          ${notes.slice(0,3).map(n=>`
            <div class="event-row">
              <strong>${DB.esc(n.title)}</strong>
              <span>${new Date(n.updatedAt).toLocaleDateString("ko-KR")}</span>
            </div>
          `).join("")||'<div class="empty">아직 메모가 없습니다.</div>'}
          <a href="#/notes" class="btn secondary">메모 작성하기</a>
        </section>
      </div>

      <section class="card">
        <div class="section-heading">
          <h2>채용 프로세스</h2>
          <a href="#/applicants">지원자 관리 →</a>
        </div>
        <div class="process-grid">
          ${HF.steps.map((s,i)=>`
            <a href="#/${s.id}" class="process-card">
              <span class="process-number">STEP 0${i+1}</span>
              <h3>${DB.esc(s.name)}</h3>
              <p>${DB.esc(s.description)}</p>
              <span class="card-arrow">업무 확인 →</span>
            </a>
          `).join("")}
        </div>
      </section>

      <section class="card">
        <h2>HR 업무 도구</h2>
        <div class="tool-grid">
          ${[
            ["documents","문서 자료실","표준 HR 문서"],
            ["calendar","채용 캘린더","월간 일정 관리"],
            ["kpi","KPI 분석","채용 성과 분석"],
            ["applicants","지원자 관리","인재 평가"],
            ["onboarding","온보딩 관리","신규 입사자 관리"],
            ["notes","개인 메모","텍스트 및 손그림 메모"],
            ["trends","HR 트렌드","HR 운영 인사이트"],
            ["backup","데이터 백업","데이터 관리"]
          ].map(([id,title,desc])=>`
            <a href="#/${id}" class="tool-card">
              <h3>${title}</h3>
              <p>${desc}</p>
              <span>열기 →</span>
            </a>
          `).join("")}
        </div>
      </section>
    `;
  }

  function trends() {
    const items=[
      ["AI 기반 채용 자동화","반복적인 채용 행정 업무를 자동화합니다.","최종 채용 판단은 담당자가 검토합니다."],
      ["스킬 기반 채용","직무 수행 역량을 중심으로 평가합니다.","직무 과제와 구조화 면접을 활용합니다."],
      ["후보자 경험 개선","지원자에게 일관된 채용 경험을 제공합니다.","단계별 안내와 결과 통보를 표준화합니다."],
      ["구조화 면접","공통 질문과 평가 척도를 적용합니다.","평가 기준을 면접관에게 사전 공유합니다."],
      ["채용 데이터 분석","채용 전환율과 소요일을 분석합니다.","직무별·채널별 성과를 비교합니다."],
      ["공정한 채용","직무 관련 평가 기준을 운영합니다.","평가 근거를 기록하고 불필요한 개인정보 활용을 제한합니다."]
    ];

    return `
      <section class="page-header">
        <span class="tag">HR INSIGHTS</span>
        <h1>HR 트렌드 분석</h1>
        <p>HR 업무에 적용할 주요 운영 방향입니다.</p>
      </section>
      <div class="trend-grid">
        ${items.map(([title,desc,action])=>`
          <article class="card">
            <h3>${title}</h3>
            <p>${desc}</p>
            <div class="guide-box">
              <strong>실무 적용</strong>
              <p>${action}</p>
            </div>
          </article>
        `).join("")}
      </div>
    `;
  }

  function shell() {
    const groups=[
      {label:"WORKSPACE",items:[["/","대시보드"]]},
      {label:"RECRUITMENT",items:HF.steps.map(s=>["/"+s.id,s.name])},
      {label:"HR TOOLS",items:[
        ["/documents","문서 자료실"],
        ["/calendar","채용 캘린더"],
        ["/kpi","KPI 분석"],
        ["/applicants","지원자 관리"],
        ["/onboarding","온보딩 관리"],
        ["/notes","개인 메모"],
        ["/trends","HR 트렌드"],
        ["/backup","데이터 백업"]
      ]}
    ];

    document.getElementById("app").innerHTML=`
      <div class="layout">
        <aside class="sidebar" id="sidebar">
          <a href="#/" class="logo">HIRE<span>FLOW</span></a>
          <div class="sidebar-caption">HUMAN RESOURCE PLATFORM</div>

          ${groups.map(group=>`
            <div class="nav-label">${group.label}</div>
            ${group.items.map(([path,label])=>`
              <a href="#${path}" class="nav-link" data-link>${label}</a>
            `).join("")}
          `).join("")}

          <div class="sidebar-bottom">
            <span class="status-dot"></span> Workspace Active
          </div>
        </aside>

        <main class="main">
          <header class="topbar">
            <button id="menu" class="icon-button">☰</button>
            <span>HIREFLOW / HR WORKSPACE</span>
            <span class="topbar-right">HR MANAGER</span>
          </header>
          <div id="content"></div>
          <footer class="footer">HIREFLOW · HR Recruitment Workspace</footer>
        </main>
      </div>
    `;
  }

  function bind() {
    document.getElementById("menu")?.addEventListener("click",()=>{
      document.getElementById("sidebar").classList.toggle("open");
    });

    document.querySelectorAll("[data-doc]").forEach(button=>{
      button.onclick=()=>Docs.open(button.dataset.doc);
    });

    Process.bind();
    CalendarTool.bind();
    KPI.bind();
    Applicants.bind();
    Onboarding.bind();
    Backup.bind();
    Notes.bind();
  }

  function render() {
    const path=location.hash.slice(1).split("?")[0]||"/";
    const content=document.getElementById("content");

    content.innerHTML=routes[path]
      ?routes[path]()
      :"<h1>페이지를 찾을 수 없습니다.</h1><a href='#/'>대시보드</a>";

    document.querySelectorAll("[data-link]").forEach(link=>{
      link.classList.toggle(
        "active",
        link.getAttribute("href")==="#"+path
      );
    });

    bind();
  }

  function init() {
    shell();

    document.addEventListener("click",e=>{
      if(e.target.closest("[data-close]"))DB.close();
      if(e.target.id==="modal")DB.close();
    });

    document.addEventListener("keydown",e=>{
      if(e.key==="Escape")DB.close();
    });

    window.addEventListener("hashchange",render);

    if(!location.hash)location.hash="#/";
    else render();
  }

  return {init,render};
})();

App.init();
