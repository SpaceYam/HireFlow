
"use strict";

window.Backup = (() => {
  function page() {
    const data=DB.getAll();
    const stats=Object.entries(data).map(([key,value])=>[
      key,
      Array.isArray(value)?value.length:typeof value==="object"?Object.keys(value).length:0
    ]);

    return `
      <section class="page-header">
        <span class="tag">DATA MANAGEMENT</span>
        <h1>데이터 백업</h1>
        <p>HIREFLOW 데이터를 내보내고 복원할 수 있습니다.</p>
      </section>

      <section class="card">
        <h2>데이터 현황</h2>
        <div class="stats-grid">
          ${stats.map(([key,count])=>`
            <article class="metric-card">
              <span>${DB.esc(key)}</span>
              <strong>${count}</strong>
            </article>
          `).join("")}
        </div>
      </section>

      <section class="card">
        <h2>백업 및 복원</h2>
        <p>백업 파일은 JSON 형식으로 저장됩니다.</p>
        <div class="form-actions">
          <button class="btn" id="backup-export">JSON 백업 다운로드</button>
          <label class="btn secondary">
            백업 파일 선택
            <input type="file" id="backup-file" accept=".json,application/json" hidden>
          </label>
        </div>
        <p class="muted">복원 시 현재 데이터가 교체됩니다. 복원 전에 백업을 권장합니다.</p>
      </section>
    `;
  }

  function bind() {
    document.getElementById("backup-export")?.addEventListener("click",()=>{
      DB.download(
        "hireflow-backup-"+DB.today()+".json",
        JSON.stringify(DB.getAll(),null,2),
        "application/json"
      );
    });

    document.getElementById("backup-file")?.addEventListener("change",async e=>{
      const file=e.target.files[0];
      if(!file)return;

      try{
        const data=JSON.parse(await file.text());
        const required=["applicants","calendar","onboarding","notes","tasks"];

        if(!data||typeof data!=="object"||
          !required.every(k=>k in data)){
          throw new Error("백업 파일 구조가 올바르지 않습니다.");
        }

        if(!DB.confirmDelete("현재 데이터를 백업 파일의 내용으로 교체할까요?"))return;

        DB.set("applicants",Array.isArray(data.applicants)?data.applicants:[]);
        DB.set("calendar",Array.isArray(data.calendar)?data.calendar:[]);
        DB.set("onboarding",Array.isArray(data.onboarding)?data.onboarding:[]);
        DB.set("notes",Array.isArray(data.notes)?data.notes:[]);
        DB.set("tasks",data.tasks||{});

        alert("데이터 복원이 완료되었습니다.");
        App.render();
      }catch(error){
        alert(error.message||"파일을 읽을 수 없습니다.");
      }
    });
  }

  return {page,bind};
})();
