
"use strict";

window.Applicants = (() => {
  const skills=[
    ["협업능력","teamwork"],
    ["전문지식","knowledge"],
    ["문제해결","problem"],
    ["의사소통","communication"],
    ["창의성","creativity"],
    ["책임감","responsibility"]
  ];

  function page() {
    const people=DB.get("applicants");

    return `
      <section class="page-header">
        <span class="tag">TALENT MANAGEMENT</span>
        <h1>지원자 관리</h1>
        <p>지원자 정보와 직무 역량을 통합 관리합니다.</p>
      </section>

      <div class="section-heading">
        <h2>지원자 목록 (${people.length})</h2>
        <button class="btn" id="add-applicant">+ 지원자 등록</button>
      </div>

      <section class="card">
        <div class="filter-bar">
          <input id="applicant-search" placeholder="이름 또는 직무 검색">
          <select id="applicant-filter">
            <option value="">전체 전형</option>
            ${["서류 검토","면접 예정","최종 합격","불합격"].map(x=>`
              <option>${x}</option>
            `).join("")}
          </select>
        </div>

        <div class="table-wrap">
          <table>
            <thead><tr>
              <th>지원자</th><th>지원 직무</th><th>전형 단계</th>
              <th>종합 역량</th><th>상세</th>
            </tr></thead>
            <tbody id="applicant-rows">${rows(people)}</tbody>
          </table>
        </div>
      </section>
    `;
  }

  function rows(people) {
    return people.map(p=>`
      <tr>
        <td><strong>${DB.esc(p.name)}</strong></td>
        <td>${DB.esc(p.position)}</td>
        <td><span class="status">${DB.esc(p.stage)}</span></td>
        <td>${average(p.skills)} / 100</td>
        <td><button class="btn secondary small" data-profile="${p.id}">상세 보기</button></td>
      </tr>
    `).join("")||'<tr><td colspan="5" class="empty">등록된 지원자가 없습니다.</td></tr>';
  }

  function average(s) {
    return Math.round(skills.reduce((n,[label,key])=>n+(Number(s?.[key])||0),0)/6);
  }

  function radar(values) {
    const center=150;
    const radius=112;
    const points=skills.map((_,i)=>{
      const angle=-Math.PI/2+i*Math.PI/3;
      const r=radius*(Number(values?.[skills[i][1]])||0)/100;
      return `${center+Math.cos(angle)*r},${center+Math.sin(angle)*r}`;
    }).join(" ");

    const rings=[20,40,60,80,100].map(level=>{
      const pts=skills.map((_,i)=>{
        const a=-Math.PI/2+i*Math.PI/3;
        const r=radius*level/100;
        return `${center+Math.cos(a)*r},${center+Math.sin(a)*r}`;
      }).join(" ");
      return `<polygon points="${pts}" fill="none" stroke="#e7ebf2"/>`;
    }).join("");

    const labels=skills.map((s,i)=>{
      const a=-Math.PI/2+i*Math.PI/3;
      const x=center+Math.cos(a)*130;
      const y=center+Math.sin(a)*130;
      return `<text x="${x}" y="${y}" text-anchor="middle" dominant-baseline="middle" font-size="10" fill="#667085">${s[0]}</text>`;
    }).join("");

    return `
      <svg viewBox="0 0 300 300" role="img" aria-label="지원자 역량 레이더 차트">
        ${rings}
        ${skills.map((_,i)=>{
          const a=-Math.PI/2+i*Math.PI/3;
          return `<line x1="150" y1="150" x2="${150+Math.cos(a)*radius}" y2="${150+Math.sin(a)*radius}" stroke="#e7ebf2"/>`;
        }).join("")}
        <polygon points="${points}" fill="rgba(71,121,232,.18)"
          stroke="#4779e8" stroke-width="2"/>
        ${labels}
      </svg>
    `;
  }

  function form(p={}) {
    DB.modal(`
      <span class="tag">TALENT PROFILE</span>
      <h2>${p.id?"지원자 정보 수정":"신규 지원자 등록"}</h2>

      <form id="applicant-form">
        <div class="form-grid">
          <label class="field"><span>이름</span>
            <input name="name" required value="${DB.esc(p.name||"")}">
          </label>
          <label class="field"><span>지원 직무</span>
            <input name="position" required value="${DB.esc(p.position||"")}">
          </label>
          <label class="field"><span>이메일</span>
            <input name="email" type="email" value="${DB.esc(p.email||"")}">
          </label>
          <label class="field"><span>전형 단계</span>
            <select name="stage">
              ${["서류 검토","면접 예정","최종 합격","불합격"].map(x=>`
                <option ${p.stage===x?"selected":""}>${x}</option>
              `).join("")}
            </select>
          </label>
        </div>

        <div class="form-section">
          <h3>직무 역량 능력치</h3>
          <p class="muted">각 항목을 0~100점으로 평가하세요.</p>
          <div class="skill-input-grid">
            ${skills.map(([label,key])=>`
              <label class="skill-input">
                <span>${label}</span>
                <div class="skill-control">
                  <input type="range" min="0" max="100" value="${p.skills?.[key]??50}" name="${key}">
                  <output>${p.skills?.[key]??50}</output>
                </div>
              </label>
            `).join("")}
          </div>
        </div>

        <label class="field">
          <span>평가 의견</span>
          <textarea name="memo" rows="3">${DB.esc(p.memo||"")}</textarea>
        </label>

        <div class="form-actions">
          <button class="btn" type="submit">저장하기</button>
        </div>
      </form>
    `);

    const formEl=document.getElementById("applicant-form");
    formEl.querySelectorAll('[type="range"]').forEach(input=>{
      input.oninput=()=>input.nextElementSibling.value=input.value;
    });

    formEl.onsubmit=e=>{
      e.preventDefault();
      const fd=new FormData(formEl);
      const people=DB.get("applicants");
      const item={
        id:p.id||DB.uid(),
        name:fd.get("name"),
        position:fd.get("position"),
        email:fd.get("email"),
        stage:fd.get("stage"),
        memo:fd.get("memo"),
        skills:Object.fromEntries(skills.map(([,key])=>[key,Number(fd.get(key))])),
        updatedAt:new Date().toISOString()
      };

      const index=people.findIndex(x=>x.id===item.id);
      if(index>=0)people[index]=item;
      else people.push(item);

      DB.set("applicants",people);
      DB.close();
      App.render();
    };
  }

  function profile(id) {
    const p=DB.get("applicants").find(x=>x.id===id);
    if(!p)return;

    DB.modal(`
      <div class="profile-header">
        <div>
          <span class="tag">TALENT PROFILE</span>
          <h2>${DB.esc(p.name)}</h2>
          <p>${DB.esc(p.position)} · ${DB.esc(p.stage)}</p>
        </div>
        <div class="profile-score">
          <strong>${average(p.skills)}</strong><span>AVERAGE</span>
        </div>
      </div>

      <div class="radar-card">${radar(p.skills)}</div>

      <div class="skill-detail-grid">
        ${skills.map(([label,key])=>`
          <div class="skill-detail">
            <span>${label}</span><strong>${p.skills?.[key]??0}</strong>
          </div>
        `).join("")}
      </div>

      <section class="form-section">
        <h3>평가 의견</h3>
        <p>${DB.esc(p.memo||"등록된 의견이 없습니다.")}</p>
      </section>

      <div class="form-actions">
        <button class="btn" id="edit-profile">수정</button>
        <button class="btn danger" id="delete-profile">삭제</button>
      </div>
    `);

    document.getElementById("edit-profile").onclick=()=>form(p);
    document.getElementById("delete-profile").onclick=()=>{
      if(!DB.confirmDelete())return;
      DB.set("applicants",DB.get("applicants").filter(x=>x.id!==id));
      DB.close();
      App.render();
    };
  }

  function bind() {
    document.getElementById("add-applicant")?.addEventListener("click",()=>form());

    const search=document.getElementById("applicant-search");
    const filter=document.getElementById("applicant-filter");

    function update() {
      const q=search.value.toLowerCase();
      const stage=filter.value;
      const people=DB.get("applicants").filter(p=>
        (p.name+" "+p.position).toLowerCase().includes(q)&&
        (!stage||p.stage===stage)
      );
      document.getElementById("applicant-rows").innerHTML=rows(people);
      bindProfiles();
    }

    search?.addEventListener("input",update);
    filter?.addEventListener("change",update);
    bindProfiles();
  }

  function bindProfiles() {
    document.querySelectorAll("[data-profile]").forEach(button=>{
      button.onclick=()=>profile(button.dataset.profile);
    });
  }

  return {page,bind,form,profile};
})();
