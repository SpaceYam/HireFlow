
"use strict";

window.HF = {
  steps: [
    {id:"planning",name:"채용 기획",description:"인력 수요 분석 및 채용 계획 수립"},
    {id:"posting",name:"채용 공고",description:"직무기술서 및 모집 채널 관리"},
    {id:"screening",name:"서류 전형",description:"지원서 검토 및 서류 평가"},
    {id:"interview",name:"면접 전형",description:"구조화 면접 및 역량 평가"},
    {id:"assessment",name:"역량 평가",description:"직무 과제 및 실무 능력 검증"},
    {id:"decision",name:"최종 결정",description:"최종 평가 및 입사 제안"},
    {id:"onboarding",name:"온보딩",description:"신규 입사자 적응 및 정착"}
  ],

  channels: [
    {name:"사람인",category:"종합 채용 플랫폼",url:"https://www.saramin.co.kr"},
    {name:"잡코리아",category:"종합 채용 플랫폼",url:"https://www.jobkorea.co.kr"},
    {name:"LinkedIn",category:"전문직 및 글로벌 인재",url:"https://www.linkedin.com"},
    {name:"원티드",category:"IT 및 전문직",url:"https://www.wanted.co.kr"}
  ]
};

window.DOC_DATA = {
  request:{
    title:"채용 요청서",
    category:"채용 기획",
    guide:"신규 인력 채용 요청",
    sections:{
      "기본 정보":["부서명","요청자","직무명","요청일"],
      "채용 조건":["채용 인원","고용 형태","희망 입사일","예산"],
      "상세 내용":["채용 사유","주요 업무","필수 자격"]
    }
  },
  jd:{
    title:"직무기술서",
    category:"직무 분석",
    guide:"직무와 자격 요건 정의",
    sections:{
      "직무 정보":["직무명","소속 부서","직무 목적"],
      "상세 내용":["주요 업무","필수 역량","우대 사항","성과 기준"]
    }
  },
  posting:{
    title:"채용 공고",
    category:"채용 모집",
    guide:"외부 게시용 채용 공고",
    sections:{
      "모집 정보":["회사명","직무명","채용 인원","근무 형태"],
      "지원 조건":["필수 자격","우대 사항","근무 지역"],
      "전형 정보":["접수 마감일","전형 절차","지원 방법"]
    }
  },
  interview:{
    title:"면접 평가표",
    category:"평가",
    guide:"구조화 면접 평가",
    sections:{
      "지원자 정보":["지원자명","면접일","면접관"],
      "평가 내용":["전문지식","문제해결","협업능력","의사소통"],
      "종합 의견":["강점","보완점","종합 평가"]
    }
  },
  final:{
    title:"최종 합격 보고서",
    category:"최종 결정",
    guide:"채용 최종 승인",
    sections:{
      "지원자 정보":["지원자명","직무명","최종 평가일"],
      "채용 조건":["제안 연봉","입사 예정일"],
      "최종 의견":["평가 결과","승인 의견"]
    }
  },
  onboarding:{
    title:"온보딩 계획서",
    category:"온보딩",
    guide:"신규 입사자 적응 관리",
    sections:{
      "입사 정보":["성명","부서","직무","입사일"],
      "적응 계획":["30일 목표","60일 목표","90일 목표"],
      "지원 담당":["멘토","담당 HR"]
    }
  }
};
