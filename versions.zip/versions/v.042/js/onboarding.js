
"use strict";

window.Onboarding = (() => {
  const checklist=[
    "근로계약서 작성",
    "입사 서류 제출",
    "이메일 계정 발급",
    "업무 장비 지급",
    "사내 시스템 권한 설정",
    "조직 및 부서 소개",
    "직무 교육 진행",
    "멘토 지정",
    "30일 피드백",
    "60일 피드백",
    "90일 평가"
  ];

  function page() {
    const list=DB.get("onboarding");

    return `
      <section class="page-header">
        <span class="tag">EMPLOYEE EXPERIENCE</span>
        <h1>온보딩 관리</h1>
        <p>신규 입사자의 입사 준비와 조직 적응을 관리합니다.</p>
      </section>

      <div class="section-heading">
        <h2>온보딩 대상자 (${list.length})</h2>
        <button class="btn" id="add-onboarding">+ 입사자 등록</button>
      </div>

      <div class="document-grid">
        ${list.map(p=>{
          const done=Object.values(p.checks||{}).filter(Boolean).length;
          return `
            <article class="document-card">
              <h3>${DB.esc(p.name)}</h3>
              <p>${DB.esc(p.position)} · ${DB.esc(p.date)}</p>
              <div class="progress"><span style="width:${done/checklist.length*100}%"></span></div>
              <p>${done}/${checklist.length} 업무 완료</p>
              <button class="btn secondary small" data-onboard="${p.id}">관리하기</button>
            </article>
          `;
        }).join("")||'<div class="card empty">등록된 입사자가 없습니다.</div>'}
      </div>
    `;
  }

  function form() {
    DB.modal(`
      <h2>신규 입사자 등록</h2>
      <form id="onboarding-form">
        <div class="form-grid">
          <label class="field"><span>이름</span><input name="name" required></label>
          <label class="field"><span>직무</span><input name="position" required></label>
          <label class="field"><span>입사일</span><input name="date" type="date" required></label>
          <label class="field"><span>멘토</span><input name="mentor"></label>
        </div>
        <div class="form-actions"><button class="btn">등록하기</button></div>
      </form>
    `);

    document.getElementById("onboarding-form").onsubmit=e=>{
      e.preventDefault();
      const fd=new FormData(e.target);
      const list=DB.get("onboarding");
      list.push({
        id:DB.uid(),
        name:fd.get("name"),
        position:fd.get("position"),
        date:fd.get("date"),
        mentor:fd.get("mentor"),
        checks:{}
      });
      DB.set("onboarding",list);
      DB.close();
      App.render();
    };
  }

  function detail(id) {
    const list=DB.get("onboarding");
    const p=list.find(x=>x.id===id);
    if(!p)return;

    DB.modal(`
      <h2>${DB.esc(p.name)} 온보딩</h2>
      <p>${DB.esc(p.position)} · 멘토 ${DB.esc(p.mentor||"-")}</p>
      <div class="check-grid">
        ${checklist.map((item,i)=>`
          <label class="check-card">
            <input type="checkbox" data-onboard-check="${i}"
              ${p.checks?.[i]?"checked":""}>
            ${DB.esc(item)}
          </label>
        `).join("")}
      </div>
      <div class="form-actions">
        <button class="btn danger" id="delete-onboarding">삭제</button>
      </div>
    `);

    document.querySelectorAll("[data-onboard-check]").forEach(input=>{
      input.onchange=()=>{
        p.checks=p.checks||{};
        p.checks[input.dataset.onboardCheck]=input.checked;
        DB.set("onboarding",list);
      };
    });

    document.getElementById("delete-onboarding").onclick=()=>{
      if(!DB.confirmDelete())return;
      DB.set("onboarding",list.filter(x=>x.id!==id));
      DB.close();
      App.render();
    };
  }

  function bind() {
    document.getElementById("add-onboarding")?.addEventListener("click",form);
    document.querySelectorAll("[data-onboard]").forEach(button=>{
      button.onclick=()=>detail(button.dataset.onboard);
    });
  }

  return {page,bind};
})();
