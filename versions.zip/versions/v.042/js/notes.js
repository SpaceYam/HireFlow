
"use strict";

window.Notes = (() => {
  let editingId=null;
  let canvas=null;
  let ctx=null;
  let drawing=false;
  let lastPoint=null;
  let mode="text";

  const DRAFT="hireflow_note_draft";

  function page() {
    const notes=DB.get("notes").sort((a,b)=>
      (b.updatedAt||"").localeCompare(a.updatedAt||"")
    );

    return `
      <section class="page-header">
        <span class="tag">PERSONAL WORKSPACE</span>
        <h1>개인 메모</h1>
        <p>업무 아이디어와 회의 기록, 개인적인 업무 노트를 관리하세요.</p>
      </section>

      <section class="notes-toolbar">
        <div>
          <input id="note-search" placeholder="메모 검색하기">
        </div>
        <button class="btn" id="new-note">+ 새 메모 작성</button>
      </section>

      <div class="notes-grid" id="notes-grid">
        ${cards(notes)}
      </div>
    `;
  }

  function cards(notes) {
    if(!notes.length)return `
      <div class="card empty">
        <div class="empty-icon">✎</div>
        <h3>아직 작성한 메모가 없습니다.</h3>
        <p>새 메모를 만들어 아이디어를 기록해 보세요.</p>
      </div>
    `;

    return notes.map(note=>`
      <article class="note-card">
        <div class="note-card-top">
          <span class="tag">${note.type==="drawing"?"DRAWING":"TEXT NOTE"}</span>
          <span>${new Date(note.updatedAt).toLocaleDateString("ko-KR")}</span>
        </div>
        <h3>${DB.esc(note.title||"제목 없는 메모")}</h3>
        <div class="note-preview">
          ${note.type==="drawing"
            ?'<span class="drawing-preview">✎ 손그림 메모</span>'
            :DB.esc((note.content||"").replace(/<[^>]*>/g," ").slice(0,130))}
        </div>
        <div class="note-card-bottom">
          <button class="btn secondary small" data-edit-note="${note.id}">열기</button>
          <button class="btn danger small" data-delete-note="${note.id}">삭제</button>
        </div>
      </article>
    `).join("");
  }

  function editor(note={}) {
    editingId=note.id||null;
    mode=note.type||"text";

    const draft=!note.id
      ?JSON.parse(localStorage.getItem(DRAFT)||"null")
      :null;

    const title=note.title??draft?.title??"";
    const content=note.content??draft?.content??"";

    DB.modal(`
      <div class="note-editor">
        <div class="note-editor-header">
          <div>
            <span class="tag">PERSONAL NOTES</span>
            <h2>${editingId?"메모 수정":"새 메모 작성"}</h2>
          </div>
          <span class="save-status" id="note-save-status">작성 중</span>
        </div>

        <input id="note-title" class="note-title-input"
          placeholder="메모 제목을 입력하세요"
          value="${DB.esc(title)}">

        <div class="note-mode-tabs">
          <button class="note-mode ${mode==="text"?"active":""}" data-mode="text">✎ 텍스트 작성</button>
          <button class="note-mode ${mode==="drawing"?"active":""}" data-mode="drawing">✏ 직접 그리기</button>
        </div>

        <div id="text-workspace" class="${mode==="text"?"":"hidden"}">
          <div class="wysiwyg-toolbar">
            <button type="button" data-command="bold"><b>B</b></button>
            <button type="button" data-command="italic"><i>I</i></button>
            <button type="button" data-command="underline"><u>U</u></button>
            <button type="button" data-command="strikeThrough"><s>S</s></button>

            <span class="toolbar-divider"></span>

            <button type="button" data-block="h2">제목</button>
            <button type="button" data-block="p">본문</button>
            <button type="button" data-command="insertUnorderedList">• 목록</button>
            <button type="button" data-command="insertOrderedList">1. 목록</button>
            <button type="button" data-command="formatBlock" data-value="blockquote">인용</button>

            <span class="toolbar-divider"></span>

            <label class="color-tool" title="글자색">
              A <input type="color" id="font-color" value="#202938">
            </label>
            <label class="color-tool" title="형광펜">
              ▰ <input type="color" id="highlight-color" value="#fff0a6">
            </label>
          </div>

          <div id="note-editor-content"
            class="wysiwyg-editor"
            contenteditable="true"
            spellcheck="true"
            data-placeholder="여기에 메모를 작성하세요...">${content}</div>
        </div>

        <div id="drawing-workspace" class="${mode==="drawing"?"":"hidden"}">
          <div class="drawing-toolbar">
            <label>펜 색상 <input type="color" id="pen-color" value="#4779e8"></label>
            <label>굵기 <input type="range" id="pen-size" min="1" max="20" value="4"></label>
            <button class="btn secondary small" id="eraser">지우개</button>
            <button class="btn secondary small" id="clear-canvas">전체 지우기</button>
          </div>
          <div class="drawing-board">
            <canvas id="note-canvas" width="1200" height="650"></canvas>
          </div>
          <p class="muted">마우스 또는 손가락으로 자유롭게 그릴 수 있습니다.</p>
        </div>

        <div class="note-editor-footer">
          <span>브라우저에 임시 저장됩니다.</span>
          <div>
            <button class="btn secondary" id="cancel-note">취소</button>
            <button class="btn" id="save-note">메모 저장</button>
          </div>
        </div>
      </div>
    `);

    setupEditor(content,note.drawing||null);
  }

  function setupEditor(content,drawingData) {
    const editorEl=document.getElementById("note-editor-content");

    document.querySelectorAll("[data-mode]").forEach(button=>{
      button.onclick=()=>{
        const selection=window.getSelection();
        const selectedText=selection?.toString()||"";
        if(selectedText) {
          // 선택 영역은 텍스트 편집 모드에서 유지하도록 한다.
        }
        mode=button.dataset.mode;
        document.querySelectorAll("[data-mode]").forEach(x=>
          x.classList.toggle("active",x===button)
        );
        document.getElementById("text-workspace").classList.toggle("hidden",mode!=="text");
        document.getElementById("drawing-workspace").classList.toggle("hidden",mode!=="drawing");

        if(mode==="drawing")setupCanvas(drawingData);
      };
    });

    document.querySelectorAll("[data-command]").forEach(button=>{
      button.onclick=()=>{
        editorEl.focus();
        document.execCommand(
          button.dataset.command,
          false,
          button.dataset.value||null
        );
      };
    });

    document.querySelectorAll("[data-block]").forEach(button=>{
      button.onclick=()=>{
        editorEl.focus();
        document.execCommand("formatBlock",false,button.dataset.block);
      };
    });

    document.getElementById("font-color").oninput=e=>{
      editorEl.focus();
      document.execCommand("foreColor",false,e.target.value);
    };

    document.getElementById("highlight-color").oninput=e=>{
      editorEl.focus();
      document.execCommand("hiliteColor",false,e.target.value);
    };

    let draftTimer;
    function saveDraft() {
      clearTimeout(draftTimer);
      draftTimer=setTimeout(()=>{
        if(!editingId) {
          localStorage.setItem(DRAFT,JSON.stringify({
            title:document.getElementById("note-title").value,
            content:editorEl.innerHTML
          }));
        }
        document.getElementById("note-save-status").textContent="임시 저장됨";
      },400);
    }

    document.getElementById("note-title").oninput=saveDraft;
    editorEl.oninput=saveDraft;

    document.getElementById("cancel-note").onclick=()=>DB.close();

    document.getElementById("save-note").onclick=save;

    if(mode==="drawing")setupCanvas(drawingData);
  }

  function setupCanvas(data) {
    canvas=document.getElementById("note-canvas");
    if(!canvas)return;

    ctx=canvas.getContext("2d");
    ctx.lineCap="round";
    ctx.lineJoin="round";
    ctx.strokeStyle=document.getElementById("pen-color").value;
    ctx.lineWidth=Number(document.getElementById("pen-size").value);

    if(data) {
      const img=new Image();
      img.onload=()=>ctx.drawImage(img,0,0,canvas.width,canvas.height);
      img.src=data;
    }

    function point(e) {
      const rect=canvas.getBoundingClientRect();
      return {
        x:(e.clientX-rect.left)*canvas.width/rect.width,
        y:(e.clientY-rect.top)*canvas.height/rect.height
      };
    }

    canvas.onpointerdown=e=>{
      e.preventDefault();
      drawing=true;
      lastPoint=point(e);
      canvas.setPointerCapture(e.pointerId);
    };

    canvas.onpointermove=e=>{
      if(!drawing)return;
      const p=point(e);
      ctx.beginPath();
      ctx.moveTo(lastPoint.x,lastPoint.y);
      ctx.lineTo(p.x,p.y);
      ctx.stroke();
      lastPoint=p;
    };

    canvas.onpointerup=()=>{
      drawing=false;
      lastPoint=null;
      localStorage.setItem("hireflow_drawing_draft",canvas.toDataURL());
    };

    canvas.onpointercancel=()=>drawing=false;

    document.getElementById("pen-color").oninput=e=>{
      ctx.globalCompositeOperation="source-over";
      ctx.strokeStyle=e.target.value;
    };

    document.getElementById("pen-size").oninput=e=>{
      ctx.lineWidth=Number(e.target.value);
    };

    document.getElementById("eraser").onclick=()=>{
      ctx.globalCompositeOperation="destination-out";
    };

    document.getElementById("clear-canvas").onclick=()=>{
      if(!confirm("그림을 모두 지울까요?"))return;
      ctx.clearRect(0,0,canvas.width,canvas.height);
      localStorage.removeItem("hireflow_drawing_draft");
    };
  }

  function save() {
    const title=document.getElementById("note-title").value.trim();
    if(!title) {
      alert("메모 제목을 입력하세요.");
      return;
    }

    const notes=DB.get("notes");
    const old=notes.find(n=>n.id===editingId);

    const item={
      id:editingId||DB.uid(),
      title,
      type:mode,
      content:mode==="text"
        ?document.getElementById("note-editor-content").innerHTML
        :"",
      drawing:mode==="drawing"&&canvas
        ?canvas.toDataURL("image/png")
        :old?.drawing||null,
      updatedAt:new Date().toISOString()
    };

    const index=notes.findIndex(n=>n.id===item.id);
    if(index>=0)notes[index]=item;
    else notes.unshift(item);

    DB.set("notes",notes);
    localStorage.removeItem(DRAFT);
    localStorage.removeItem("hireflow_drawing_draft");
    DB.close();
    App.render();
  }

  function edit(id) {
    const note=DB.get("notes").find(n=>n.id===id);
    if(note)editor(note);
  }

  function remove(id) {
    if(!DB.confirmDelete("이 메모를 삭제할까요?"))return;
    DB.set("notes",DB.get("notes").filter(n=>n.id!==id));
    App.render();
  }

  function bind() {
    document.getElementById("new-note")?.addEventListener("click",()=>editor());

    document.getElementById("note-search")?.addEventListener("input",e=>{
      const q=e.target.value.toLowerCase();
      const filtered=DB.get("notes").filter(n=>
        (n.title+" "+(n.content||"")).toLowerCase().includes(q)
      );
      document.getElementById("notes-grid").innerHTML=cards(filtered);
      bindCards();
    });

    bindCards();
  }

  function bindCards() {
    document.querySelectorAll("[data-edit-note]").forEach(button=>{
      button.onclick=()=>edit(button.dataset.editNote);
    });
    document.querySelectorAll("[data-delete-note]").forEach(button=>{
      button.onclick=()=>remove(button.dataset.deleteNote);
    });
  }

  return {page,bind,editor,edit,remove};
})();
