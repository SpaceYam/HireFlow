
"use strict";

window.DocsForm = {
  render(doc) {
    const fields = Object.entries(doc.sections)
      .flatMap(([section,names]) => names.map(name=>({section,name})));

    return `
      <form id="document-form">
        ${Object.entries(doc.sections).map(([section,names])=>`
          <section class="form-section">
            <h3>${DB.esc(section)}</h3>
            <div class="form-grid">
              ${names.map(name=>{
                const index=fields.findIndex(f=>f.name===name);
                const type=/일$/.test(name)?"date":
                  /인원|점수|연봉|예산/.test(name)?"number":"text";
                return `
                  <label class="field">
                    <span>${DB.esc(name)}</span>
                    ${/내용|업무|역량|의견|사유|목표|사항/.test(name)
                      ?`<textarea name="f${index}" rows="3"></textarea>`
                      :`<input type="${type}" name="f${index}">`}
                  </label>`;
              }).join("")}
            </div>
          </section>
        `).join("")}
        <div class="form-actions">
          <button type="submit" class="btn">미리보기</button>
        </div>
      </form>
    `;
  }
};
