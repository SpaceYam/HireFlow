
"use strict";

window.DB = (() => {
  const KEY = "hireflow_database_v3";

  const defaults = {
    applicants: [],
    calendar: [],
    onboarding: [],
    notes: [],
    tasks: {}
  };

  function getAll() {
    try {
      const data = JSON.parse(localStorage.getItem(KEY) || "{}");
      return {...defaults, ...data};
    } catch {
      return structuredClone(defaults);
    }
  }

  function saveAll(data) {
    localStorage.setItem(KEY, JSON.stringify(data));
  }

  function get(key) {
    return getAll()[key] || [];
  }

  function set(key, value) {
    const data = getAll();
    data[key] = value;
    saveAll(data);
  }

  function today() {
    const d = new Date();
    return [
      d.getFullYear(),
      String(d.getMonth()+1).padStart(2,"0"),
      String(d.getDate()).padStart(2,"0")
    ].join("-");
  }

  function uid() {
    return crypto.randomUUID
      ? crypto.randomUUID()
      : Date.now().toString(36)+Math.random().toString(36).slice(2);
  }

  function esc(value) {
    return String(value ?? "").replace(/[&<>"']/g, char => ({
      "&":"&amp;",
      "<":"&lt;",
      ">":"&gt;",
      '"':"&quot;",
      "'":"&#39;"
    })[char]);
  }

  function modal(html) {
    document.getElementById("modal-content").innerHTML = html;
    document.getElementById("modal").classList.remove("hidden");
  }

  function close() {
    document.getElementById("modal").classList.add("hidden");
    document.getElementById("modal-content").innerHTML = "";
  }

  function download(filename, content, type="text/html;charset=utf-8") {
    const blob = new Blob([content], {type});
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  function confirmDelete(message="삭제하시겠습니까?") {
    return window.confirm(message);
  }

  return {
    getAll,get,set,today,uid,esc,modal,close,download,confirmDelete
  };
})();
