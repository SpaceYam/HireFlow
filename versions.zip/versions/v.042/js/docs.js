
"use strict";

window.Docs = (() => {
  function catalog() {
    return `
      <section class="page-header">
        <span class="tag">DOCUMENT CENTER</span>
        <h1>HR 표준 문서 자료실</h1>
        <p>채용 업무에 필요한 표준 양식을 작성하고 관리합니다.</p>
      </section>

      <div class="document-grid">
        ${Object.entries(DOC_DATA).map(([id,doc])=>`
          <article class="document-card">
            <span class="tag">${DB.esc(doc.category)}</span>
            <h3>${DB.esc(doc.title)}</h3>
            <p>${DB.esc(doc.guide)}</p>
            <button class="btn" data-doc="${id}">양식 열기</button>
          </article>
        `).join("")}
      </div>

      <section class="card">
        <h2>채용 공고 게시 채널</h2>
        ${HF.channels.map(c=>`
          <div class="channel-row">
            <div>
              <strong>${DB.esc(c.name)}</strong>
              <p>${DB.esc(c.category)}</p>
            </div>
            <a href="${DB.esc(c.url)}" target="_blank" rel="noopener">방문 →</a>
          </div>
        `).join("")}
      </section>
    `;
  }

  function open(id) {
    const doc=DOC_DATA[id];
    if(!doc)return;

    const fields=Object.entries(doc.sections)
      .flatMap(([section,names])=>names.map(name=>({section,name})));

    DB.modal(`
      <span class="tag">HR DOCUMENT</span>
      <h2>${DB.esc(doc.title)}</h2>
      ${DocsForm.render(doc)}
    `);

    document.getElementById("document-form").onsubmit=e=>{
      e.preventDefault();
      const fd=new FormData(e.target);
      const rows=fields.map((f,i)=>`
        <tr>
          <th>${DB.esc(f.name)}</th>
          <td>${DB.esc(fd.get("f"+i)||"-")}</td>
        </tr>
      `).join("");

      const html=`<!DOCTYPE html><html lang="ko"><meta charset="UTF-8">
        <title>${DB.esc(doc.title)}</title>
        <style>
          body{font-family:Arial,sans-serif;padding:40px;color:#26334a}
          h1{border-bottom:3px solid #4779e8;padding-bottom:15px}
          table{width:100%;border-collapse:collapse}
          th,td{border:1px solid #ddd;padding:12px;text-align:left}
          th{background:#f1f4fa;width:25%}
        </style>
        <h1>${DB.esc(doc.title)}</h1><p>HIREFLOW HR DOCUMENT</p>
        <table>${rows}</table></html>`;

      DB.modal(`
        <h2>문서 미리보기</h2>
        <div class="preview-frame">
          <iframe sandbox title="문서 미리보기"
            srcdoc="${DB.esc(html).replace(/"/g,"&quot;")}"></iframe>
        </div>
        <button class="btn" id="download-document">HTML 다운로드</button>
        <button class="btn secondary" id="back-document">수정하기</button>
      `);

      document.getElementById("download-document").onclick=()=>{
        DB.download(doc.title+".html",html);
      };
      document.getElementById("back-document").onclick=()=>open(id);
    };
  }

  return {catalog,open};
})();
