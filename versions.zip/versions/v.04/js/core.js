"use strict";

window.HF = {
  steps: [
    { id:"planning", name:"채용 계획", description:"인력 수요 분석 및 채용 계획 수립" },
    { id:"posting", name:"채용 공고", description:"직무 분석 및 채용 공고 게시" },
    { id:"screening", name:"서류 심사", description:"지원자 서류 검토 및 평가" },
    { id:"interview", name:"면접 전형", description:"직무 역량 및 조직 적합성 평가" },
    { id:"assessment", name:"역량 평가", description:"실무 과제 및 직무 역량 검증" },
    { id:"decision", name:"최종 결정", description:"최종 평가 및 입사 제안" },
    { id:"onboarding", name:"온보딩", description:"신규 입사자 적응 및 관리" }
  ],

  channels: [
    { name:"사람인", category:"종합 채용", url:"https://www.saramin.co.kr" },
    { name:"잡코리아", category:"종합 채용", url:"https://www.jobkorea.co.kr" },
    { name:"원티드", category:"IT 및 전문직", url:"https://www.wanted.co.kr" },
    { name:"LinkedIn", category:"글로벌 채용", url:"https://www.linkedin.com" }
  ]
};

window.DB = (() => {
  const KEY = "hireflow_database_v1";

  const defaults = {
    applicants: [],
    calendar: [],
    onboarding: [],
    documents: [],
    settings: { version: 1 }
  };

  let data;

  function load() {
    try {
      const saved = JSON.parse(localStorage.getItem(KEY));
      data = { ...defaults, ...(saved || {}) };
    } catch {
      data = structuredClone(defaults);
    }
  }

  function save() {
    localStorage.setItem(KEY, JSON.stringify(data));
  }

  function get(key) {
    return data[key] || [];
  }

  function set(key, value) {
    data[key] = value;
    save();
  }

  function today() {
    return new Date().toLocaleDateString("sv-SE");
  }

  function uid() {
    return crypto.randomUUID
      ? crypto.randomUUID()
      : Date.now().toString(36) + Math.random().toString(36).slice(2);
  }

  function esc(value) {
    return String(value ?? "").replace(/[&<>"']/g, char => ({
      "&":"&amp;",
      "<":"&lt;",
      ">":"&gt;",
      '"':"&quot;",
      "'":"&#39;"
    })[char]);
  }

  function modal(html) {
    document.getElementById("modal-content").innerHTML = html;
    document.getElementById("modal").classList.remove("hidden");
  }

  function close() {
    document.getElementById("modal").classList.add("hidden");
    document.getElementById("modal-content").innerHTML = "";
  }

  function download(filename, content, type = "text/html;charset=utf-8") {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");

    a.href = url;
    a.download = filename;
    a.click();

    URL.revokeObjectURL(url);
  }

  function average(values) {
    return values.length
      ? Math.round(values.reduce((a, b) => a + Number(b || 0), 0) / values.length)
      : 0;
  }

  load();

  return {
    get, set, save, today, uid, esc,
    modal, close, download, average
  };
})();