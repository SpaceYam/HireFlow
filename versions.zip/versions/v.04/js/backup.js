"use strict";

window.Backup = (() => {
  function page() {
    return `
      <section class="page-header">
        <span class="tag">DATA MANAGEMENT</span>
        <h1>데이터 백업</h1>
        <p>HIREFLOW 데이터를 JSON 파일로 내보내고 복원합니다.</p>
      </section>

      <section class="card">
        <h2>데이터 내보내기</h2>
        <p>지원자, 일정, 온보딩, 문서 데이터를 백업합니다.</p>
        <button class="btn" id="export-data">JSON 백업 다운로드</button>
      </section>

      <section class="card">
        <h2>데이터 복원</h2>
        <p>이전에 저장한 HIREFLOW JSON 파일을 불러옵니다.</p>
        <label class="field">
          <span>백업 파일 선택</span>
          <input type="file" id="import-data" accept=".json,application/json">
        </label>
        <button class="btn secondary" id="import-button">데이터 복원</button>
        <p class="muted">복원하면 기존 데이터가 백업 파일의 데이터로 대체됩니다.</p>
      </section>
    `;
  }

  function bind() {
    document.getElementById("export-data")?.addEventListener("click", () => {
      const backup = {
        version:1,
        exportedAt:new Date().toISOString(),
        applicants:DB.get("applicants"),
        calendar:DB.get("calendar"),
        onboarding:DB.get("onboarding"),
        documents:DB.get("documents")
      };

      DB.download(
        `hireflow-backup-${DB.today()}.json`,
        JSON.stringify(backup,null,2),
        "application/json;charset=utf-8"
      );
    });

    document.getElementById("import-button")?.addEventListener("click", async () => {
      const file = document.getElementById("import-data").files[0];
      if (!file) return alert("백업 파일을 선택하세요.");

      try {
        const parsed = JSON.parse(await file.text());

        const keys = ["applicants","calendar","onboarding","documents"];

        if (!parsed || !keys.every(key => Array.isArray(parsed[key]))) {
          throw new Error("올바르지 않은 백업 파일입니다.");
        }

        if (!confirm("기존 데이터를 백업 파일의 데이터로 교체할까요?")) return;

        keys.forEach(key => DB.set(key, parsed[key]));
        alert("데이터가 복원되었습니다.");
        App.render();
      } catch (error) {
        alert(error.message || "복원에 실패했습니다.");
      }
    });
  }

  return { page, bind };
})();