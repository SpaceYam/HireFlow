"use strict";

window.DocsForm = (() => {
  function render(doc, values = {}) {
    let index = 0;

    return `
      <form id="document-form">
        <div class="form-intro">
          <span class="tag">HR STANDARD FORM</span>
          <h2>${DB.esc(doc.title)}</h2>
          <p>${DB.esc(doc.guide)}</p>
        </div>

        ${Object.entries(doc.sections).map(([section, fields]) => `
          <section class="form-section">
            <h3>${DB.esc(section)}</h3>
            <div class="form-grid">
              ${fields.map(field => {
                const id = `field_${index++}`;
                const value = values[field] || "";

                return `
                  <label class="field">
                    <span>${DB.esc(field)}</span>
                    ${
                      /일$/.test(field)
                        ? `<input type="date" name="${id}" value="${DB.esc(value)}">`
                        : /인원|점수|연봉|예산/.test(field)
                          ? `<input type="number" min="0" name="${id}" value="${DB.esc(value)}">`
                          : `<textarea name="${id}" rows="3">${DB.esc(value)}</textarea>`
                    }
                  </label>
                `;
              }).join("")}
            </div>
          </section>
        `).join("")}

        <div class="form-actions">
          <button type="button" class="btn secondary" data-close>취소</button>
          <button type="submit" class="btn">미리보기</button>
        </div>
      </form>
    `;
  }

  return { render };
})();