"use strict";

window.App = (() => {
  const routes = {
    "/":dashboard,
    "/documents":() => Docs.catalog(),
    "/calendar":() => CalendarTool.page(),
    "/kpi":() => KPI.page(),
    "/applicants":() => Applicants.page(),
    "/onboarding":() => Onboarding.page(),
    "/backup":() => Backup.page(),
    "/trends":trends
  };

  HF.steps.forEach(step => {
    routes["/" + step.id] = () => Process.page(step.id);
  });

  function dashboard() {
    const people = DB.get("applicants");
    const events = DB.get("calendar");
    const onboarding = DB.get("onboarding");
    const todayEvents = events.filter(e => e.date === DB.today());

    return `
      <section class="page-header dashboard-header">
        <span class="tag">HIREFLOW WORKSPACE</span>
        <h1>안녕하세요, HR Manager.</h1>
        <p>오늘의 채용 현황과 인사 업무를 확인하세요.</p>
      </section>

      <div class="stats-grid">
        <article class="card">
          <span class="stat-label">전체 지원자</span>
          <div class="stat-value">${people.length}</div>
          <span class="stat-sub">누적 등록 인원</span>
        </article>
        <article class="card">
          <span class="stat-label">진행 중 지원자</span>
          <div class="stat-value">${people.filter(p => !["최종 합격","불합격"].includes(p.stage)).length}</div>
          <span class="stat-sub">현재 채용 진행 인원</span>
        </article>
        <article class="card">
          <span class="stat-label">채용 일정</span>
          <div class="stat-value">${events.length}</div>
          <span class="stat-sub">전체 등록 일정</span>
        </article>
        <article class="card">
          <span class="stat-label">온보딩 대상자</span>
          <div class="stat-value">${onboarding.length}</div>
          <span class="stat-sub">신규 입사자</span>
        </article>
      </div>

      <div class="dashboard-grid">
        <section class="card">
          <div class="section-heading">
            <h2>오늘의 채용 일정</h2>
            <a href="#/calendar">전체 일정 →</a>
          </div>
          ${todayEvents.map(e => `
            <div class="event-row">
              <div>
                <strong>${DB.esc(e.title)}</strong>
                <p>${DB.esc(e.type)} · ${DB.esc(e.person || "공통")}</p>
              </div>
              <span>${DB.esc(e.time || "")}</span>
            </div>
          `).join("") || `<div class="empty">오늘 예정된 일정이 없습니다.</div>`}
        </section>

        <section class="card">
          <h2>빠른 업무</h2>
          <div class="quick-links">
            <a href="#/applicants">+ 지원자 등록</a>
            <a href="#/calendar">+ 채용 일정 등록</a>
            <a href="#/documents">+ 표준 문서 작성</a>
            <a href="#/onboarding">+ 입사자 등록</a>
          </div>
        </section>
      </div>

      <section class="card">
        <div class="section-heading">
          <div>
            <span class="tag">RECRUITMENT PIPELINE</span>
            <h2>채용 프로세스</h2>
          </div>
          <a href="#/applicants">지원자 관리 →</a>
        </div>

        <div class="process-grid">
          ${HF.steps.map((step,i) => `
            <a class="process-card" href="#/${step.id}">
              <span class="process-number">STEP 0${i+1}</span>
              <h3>${DB.esc(step.name)}</h3>
              <p>${DB.esc(step.description)}</p>
              <span class="card-arrow">업무 확인 →</span>
            </a>
          `).join("")}
        </div>
      </section>

      <section class="card">
        <div class="section-heading">
          <h2>HR 업무 도구</h2>
        </div>
        <div class="tool-grid">
          ${[
            ["documents","문서 자료실","표준 HR 문서"],
            ["calendar","채용 캘린더","일정 및 면접 관리"],
            ["kpi","KPI 분석","채용 성과 분석"],
            ["applicants","지원자 관리","인재 평가 및 관리"],
            ["onboarding","온보딩 관리","신규 입사자 관리"],
            ["trends","HR 트렌드","HR 운영 인사이트"],
            ["backup","데이터 백업","데이터 관리"]
          ].map(item => `
            <a class="tool-card" href="#/${item[0]}">
              <h3>${item[1]}</h3>
              <p>${item[2]}</p>
              <span>열기 →</span>
            </a>
          `).join("")}
        </div>
      </section>
    `;
  }

  function trends() {
    const items = [
      ["AI 기반 채용 자동화","공고 작성, 일정 조율 등 반복적인 HR 업무를 보조합니다.","AI를 활용하되 최종 채용 결정은 담당자가 검토합니다."],
      ["스킬 기반 채용","학력과 연차보다 실제 직무 역량을 중심으로 평가합니다.","직무 과제와 구조화 면접으로 역량을 검증합니다."],
      ["후보자 경험 개선","지원부터 결과 통보까지 일관된 경험을 제공합니다.","전형별 안내와 결과 통보 기준을 표준화합니다."],
      ["구조화 면접","공통 질문과 평가 척도로 면접의 일관성을 높입니다.","면접관별 평가 기준을 사전에 공유합니다."],
      ["채용 데이터 분석","채용 전환율과 소요 시간 등 데이터를 분석합니다.","직무별·채널별 성과를 비교합니다."],
      ["공정한 채용","직무 관련 기준을 활용해 객관적인 평가를 지향합니다.","불필요한 개인정보 활용을 제한합니다."]
    ];

    return `
      <section class="page-header">
        <span class="tag">HR INSIGHTS</span>
        <h1>HR 트렌드</h1>
        <p>2026년 HR 업무에 적용할 주요 운영 방향입니다.</p>
      </section>
      <div class="trend-grid">
        ${items.map(item => `
          <article class="card">
            <h3>${item[0]}</h3>
            <p>${item[1]}</p>
            <div class="guide-box">
              <strong>실무 적용</strong>
              <p>${item[2]}</p>
            </div>
          </article>
        `).join("")}
      </div>
    `;
  }

  function shell() {
    const groups = [
      {label:"WORKSPACE",items:[["/","대시보드"]]},
      {label:"RECRUITMENT",items:HF.steps.map(s => ["/"+s.id,s.name])},
      {label:"HR TOOLS",items:[
        ["/documents","문서 자료실"],
        ["/calendar","채용 캘린더"],
        ["/kpi","KPI 분석"],
        ["/applicants","지원자 관리"],
        ["/onboarding","온보딩 관리"],
        ["/trends","HR 트렌드"],
        ["/backup","데이터 백업"]
      ]}
    ];

    document.getElementById("app").innerHTML = `
      <div class="layout">
        <aside class="sidebar" id="sidebar">
          <a href="#/" class="logo">HIRE<span>FLOW</span></a>
          <div class="sidebar-caption">HUMAN RESOURCE PLATFORM</div>

          ${groups.map(group => `
            <div class="nav-label">${group.label}</div>
            ${group.items.map(([path,label]) => `
              <a href="#${path}" class="nav-link" data-link>${label}</a>
            `).join("")}
          `).join("")}

          <div class="sidebar-bottom">
            <span class="status-dot"></span> Workspace Active
          </div>
        </aside>

        <main class="main">
          <header class="topbar">
            <button id="menu" class="icon-button" aria-label="메뉴">☰</button>
            <span>HIREFLOW / HR WORKSPACE</span>
            <span class="topbar-right">HR MANAGER</span>
          </header>
          <div id="content"></div>
          <footer class="footer">HIREFLOW · HR Recruitment Workspace</footer>
        </main>
      </div>
    `;
  }

  function bind() {
    document.getElementById("menu")?.addEventListener("click", () => {
      document.getElementById("sidebar").classList.toggle("open");
    });

    document.querySelectorAll("[data-doc]").forEach(button => {
      button.onclick = () => Docs.open(button.dataset.doc);
    });

    document.querySelectorAll("[data-task]").forEach(button => {
      button.onclick = () => Process.open(
        button.dataset.task,
        Number(button.dataset.index)
      );
    });

    CalendarTool.bind();
    KPI.bind();
    Applicants.bind();
    Onboarding.bind();
    Backup.bind();
  }

  function render() {
    const path = location.hash.slice(1).split("?")[0] || "/";
    const content = document.getElementById("content");

    content.innerHTML = routes[path]
      ? routes[path]()
      : "<h1>페이지를 찾을 수 없습니다.</h1>";

    document.querySelectorAll("[data-link]").forEach(link => {
      link.classList.toggle(
        "active",
        link.getAttribute("href") === "#" + path
      );
    });

    bind();
  }

  function init() {
    shell();

    document.addEventListener("click", event => {
      if (event.target.closest("[data-close]") || event.target.id === "modal") {
        DB.close();
      }
    });

    window.addEventListener("hashchange", render);

    if (!location.hash) location.hash = "#/";
    else render();
  }

  return { init, render };
})();

App.init();