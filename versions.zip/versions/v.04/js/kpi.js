"use strict";

window.KPI = (() => {
  function page() {
    const people = DB.get("applicants");
    const events = DB.get("calendar");
    const hired = people.filter(p => p.stage === "최종 합격").length;
    const rejected = people.filter(p => p.stage === "불합격").length;
    const decided = hired + rejected;

    const conversion = people.length
      ? Math.round(hired / people.length * 100)
      : 0;

    const averageScore = DB.average(
      people.map(p => DB.average(Object.values(p.skills || {})))
    );

    const stageCounts = HF.steps.map(step => ({
      name:step.name,
      count:people.filter(p => {
        const stageMap = {
          screening:"서류 심사",
          interview:"면접 예정",
          assessment:"면접 완료",
          decision:"최종 합격",
          onboarding:"최종 합격"
        };
        return p.stage === stageMap[step.id];
      }).length
    }));

    return `
      <section class="page-header">
        <span class="tag">RECRUITMENT ANALYTICS</span>
        <h1>채용 KPI 분석</h1>
        <p>지원자 데이터 기반 채용 성과를 확인합니다.</p>
      </section>

      <div class="stats-grid">
        <article class="card"><span class="stat-label">전체 지원자</span><div class="stat-value">${people.length}</div></article>
        <article class="card"><span class="stat-label">최종 합격</span><div class="stat-value">${hired}</div></article>
        <article class="card"><span class="stat-label">합격 전환율</span><div class="stat-value">${conversion}%</div></article>
        <article class="card"><span class="stat-label">평균 역량 점수</span><div class="stat-value">${averageScore}</div></article>
      </div>

      <section class="card">
        <h2>전형별 지원자 현황</h2>
        <div class="bar-chart">
          ${stageCounts.map(item => `
            <div class="bar-item">
              <span>${DB.esc(item.name)}</span>
              <div class="progress"><span style="width:${people.length ? item.count / people.length * 100 : 0}%"></span></div>
              <strong>${item.count}</strong>
            </div>
          `).join("")}
        </div>
      </section>

      <section class="card">
        <h2>채용 운영 지표</h2>
        <div class="stats-grid">
          <article class="metric-card">
            <span>최종 결정 인원</span>
            <strong>${decided}</strong>
          </article>
          <article class="metric-card">
            <span>전체 채용 일정</span>
            <strong>${events.length}</strong>
          </article>
          <article class="metric-card">
            <span>불합격 인원</span>
            <strong>${rejected}</strong>
          </article>
        </div>
        <p class="muted">합격 전환율은 전체 등록 지원자 대비 최종 합격자 비율입니다.</p>
      </section>
    `;
  }

  function bind() {}

  return { page, bind };
})();