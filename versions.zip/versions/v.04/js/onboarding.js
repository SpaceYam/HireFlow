"use strict";

window.Onboarding = (() => {
  function page() {
    const list = DB.get("onboarding");

    return `
      <section class="page-header">
        <span class="tag">EMPLOYEE EXPERIENCE</span>
        <h1>온보딩 관리</h1>
        <p>신규 입사자의 입사 준비와 초기 적응을 관리합니다.</p>
      </section>

      <section class="card">
        <div class="section-heading">
          <h2>입사자 목록</h2>
          <button class="btn" id="add-onboarding">+ 입사자 등록</button>
        </div>

        <div class="table-wrap">
          <table>
            <thead>
              <tr><th>이름</th><th>부서</th><th>입사일</th><th>진행률</th><th>관리</th></tr>
            </thead>
            <tbody>
              ${list.map(p => {
                const total = Object.values(p.tasks || {}).filter(Boolean).length;
                const percent = Math.round(total / 6 * 100);

                return `
                  <tr>
                    <td>${DB.esc(p.name)}</td>
                    <td>${DB.esc(p.department)}</td>
                    <td>${DB.esc(p.date)}</td>
                    <td>
                      <div class="progress">
                        <span style="width:${percent}%"></span>
                      </div>
                      ${percent}%
                    </td>
                    <td><button class="btn small secondary" data-onboard="${p.id}">관리</button></td>
                  </tr>
                `;
              }).join("") || `<tr><td colspan="5" class="empty">등록된 입사자가 없습니다.</td></tr>`}
            </tbody>
          </table>
        </div>
      </section>
    `;
  }

  function openForm(person = null) {
    DB.modal(`
      <h2>${person ? "온보딩 관리" : "입사자 등록"}</h2>
      <form id="onboarding-form">
        <div class="form-grid">
          <label class="field"><span>이름</span><input name="name" required value="${DB.esc(person?.name || "")}"></label>
          <label class="field"><span>부서</span><input name="department" required value="${DB.esc(person?.department || "")}"></label>
          <label class="field"><span>직무</span><input name="position" value="${DB.esc(person?.position || "")}"></label>
          <label class="field"><span>입사일</span><input type="date" name="date" value="${DB.esc(person?.date || DB.today())}"></label>
          <label class="field"><span>멘토</span><input name="mentor" value="${DB.esc(person?.mentor || "")}"></label>
        </div>

        <h3>온보딩 체크리스트</h3>
        <div class="check-grid">
          ${["근로계약서 작성","계정 및 권한 발급","업무 장비 지급","조직 및 업무 안내","30일 목표 설정","60·90일 평가 계획"].map((t,i) => `
            <label class="check-card">
              <input type="checkbox" name="task${i}" ${person?.tasks?.["task"+i] ? "checked" : ""}>
              <span>${t}</span>
            </label>
          `).join("")}
        </div>

        <button class="btn">저장하기</button>
      </form>
    `);

    document.getElementById("onboarding-form").onsubmit = event => {
      event.preventDefault();
      const fd = new FormData(event.target);
      const list = DB.get("onboarding");

      const result = {
        id: person?.id || DB.uid(),
        name: fd.get("name"),
        department: fd.get("department"),
        position: fd.get("position"),
        date: fd.get("date"),
        mentor: fd.get("mentor"),
        tasks: Object.fromEntries(
          Array.from({length:6},(_,i) => [`task${i}`,fd.get(`task${i}`) === "on"])
        )
      };

      DB.set("onboarding", person
        ? list.map(p => p.id === person.id ? result : p)
        : [...list,result]);

      DB.close();
      App.render();
    };
  }

  function bind() {
    document.getElementById("add-onboarding")?.addEventListener("click", () => openForm());

    document.querySelectorAll("[data-onboard]").forEach(button => {
      button.onclick = () => {
        const person = DB.get("onboarding").find(p => p.id === button.dataset.onboard);
        if (person) openForm(person);
      };
    });
  }

  return { page, bind };
})();