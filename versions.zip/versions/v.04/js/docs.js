"use strict";

window.Docs = (() => {
  function catalog() {
    return `
      <section class="page-header">
        <span class="tag">HR DOCUMENT CENTER</span>
        <h1>문서 자료실</h1>
        <p>인사 및 채용 업무에 필요한 표준 문서를 관리합니다.</p>
      </section>

      <div class="document-grid">
        ${Object.entries(DOC_DATA).map(([id, doc]) => `
          <article class="card document-card">
            <span class="tag">${DB.esc(doc.category)}</span>
            <h3>${DB.esc(doc.title)}</h3>
            <p>${DB.esc(doc.guide)}</p>
            <button class="btn" data-doc="${id}">양식 열기</button>
          </article>
        `).join("")}
      </div>

      <section class="card">
        <h2>채용 플랫폼</h2>
        <div class="channel-grid">
          ${HF.channels.map(channel => `
            <a class="channel-card" href="${DB.esc(channel.url)}"
               target="_blank" rel="noopener noreferrer">
              <strong>${DB.esc(channel.name)}</strong>
              <span>${DB.esc(channel.category)}</span>
              <span>사이트 방문 →</span>
            </a>
          `).join("")}
        </div>
      </section>
    `;
  }

  function open(id) {
    const doc = DOC_DATA[id];
    if (!doc) return;

    DB.modal(DocsForm.render(doc));

    document.getElementById("document-form").onsubmit = event => {
      event.preventDefault();

      const fields = Object.values(doc.sections).flat();
      const form = new FormData(event.target);
      const values = {};

      fields.forEach((field, index) => {
        values[field] = form.get(`field_${index}`) || "";
      });

      const rows = fields.map(field => `
        <tr>
          <th>${DB.esc(field)}</th>
          <td>${DB.esc(values[field]).replace(/\n/g, "<br>")}</td>
        </tr>
      `).join("");

      const html = `
        <!DOCTYPE html>
        <html lang="ko">
        <head>
          <meta charset="UTF-8">
          <title>${DB.esc(doc.title)}</title>
          <style>
            body{font-family:Arial,sans-serif;padding:40px;color:#222}
            h1{border-bottom:3px solid #4779e8;padding-bottom:15px}
            table{width:100%;border-collapse:collapse;margin-top:25px}
            th,td{border:1px solid #ddd;padding:13px;text-align:left}
            th{background:#f5f6f8;width:25%}
          </style>
        </head>
        <body>
          <h1>${DB.esc(doc.title)}</h1>
          <p>HIREFLOW · HR STANDARD DOCUMENT</p>
          <table>${rows}</table>
        </body>
        </html>
      `;

      DB.modal(`
        <h2>문서 미리보기</h2>
        <div class="preview-frame">
          <iframe title="문서 미리보기" sandbox
            srcdoc="${DB.esc(html).replace(/"/g, "&quot;")}"></iframe>
        </div>
        <div class="form-actions">
          <button class="btn secondary" data-back>다시 작성</button>
          <button class="btn" id="download-document">HTML 다운로드</button>
        </div>
      `);

      document.getElementById("download-document").onclick = () => {
        DB.download(`${doc.title}.html`, html);
      };

      document.querySelector("[data-back]").onclick = () => open(id);
    };
  }

  return { catalog, open };
})();