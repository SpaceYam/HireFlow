"use strict";

window.Process = (() => {
  const tasks = {
    planning: [
      ["인력 수요 분석","현재 인력 및 추가 채용 필요 인원을 분석합니다.",["현재 인원","필요 인원","충원 사유","예상 예산"]],
      ["채용 요청 승인","부서별 채용 요청을 검토하고 승인합니다.",["요청 부서","요청 직무","요청 인원","승인 담당자"]],
      ["직무 분석","직무 목적과 핵심 역량을 정의합니다.",["직무 목적","주요 업무","필수 역량","우대 역량"]]
    ],
    posting: [
      ["채용 공고 작성","직무와 지원 조건을 정리합니다.",["공고 제목","담당 업무","자격 요건","우대 사항"]],
      ["채용 채널 선정","지원자 특성에 맞는 채용 채널을 선정합니다.",["선정 채널","예상 지원자","게시일","마감일"]]
    ],
    screening: [
      ["서류 검토 기준 수립","평가 항목과 점수 기준을 정의합니다.",["평가 항목","평가 기준","배점","평가 담당자"]],
      ["지원자 서류 평가","직무 역량과 경력을 평가합니다.",["지원자명","직무 관련 경험","전문지식 점수","평가 의견"]]
    ],
    interview: [
      ["면접 질문 설계","역량별 공통 질문을 구성합니다.",["평가 역량","면접 질문","평가 기준","배점"]],
      ["면접 진행","지원자의 역량을 구조화하여 평가합니다.",["지원자명","면접관","면접 일자","종합 의견"]]
    ],
    assessment: [
      ["실무 과제 설계","실제 직무를 반영한 과제를 구성합니다.",["과제명","수행 시간","제출 방법","평가 기준"]],
      ["과제 평가","사전 정의된 기준에 따라 결과를 평가합니다.",["지원자명","과제 점수","평가 근거","개선 의견"]]
    ],
    decision: [
      ["최종 평가","전형별 평가 결과를 종합합니다.",["지원자명","서류 점수","면접 점수","최종 점수"]],
      ["오퍼 및 입사 확정","입사 조건을 협의하고 확정합니다.",["제안 연봉","입사 예정일","고용 형태","오퍼 결과"]]
    ],
    onboarding: [
      ["입사 준비","입사에 필요한 환경을 준비합니다.",["계정 발급","장비 지급","계약서 작성","멘토 지정"]],
      ["30·60·90일 적응 관리","기간별 목표 및 적응 상태를 점검합니다.",["30일 목표","60일 목표","90일 목표","최종 피드백"]]
    ]
  };

  function page(id) {
    const step = HF.steps.find(s => s.id === id);
    if (!step) return "<h1>페이지를 찾을 수 없습니다.</h1>";

    const list = tasks[id] || [];

    return `
      <section class="page-header">
        <span class="tag">RECRUITMENT PROCESS</span>
        <h1>${DB.esc(step.name)}</h1>
        <p>${DB.esc(step.description)}</p>
      </section>

      <div class="process-overview">
        ${HF.steps.map((s, i) => `
          <a href="#/${s.id}" class="step-item ${s.id === id ? "selected" : ""}">
            <span>${String(i + 1).padStart(2, "0")}</span>
            <strong>${DB.esc(s.name)}</strong>
          </a>
        `).join("")}
      </div>

      <section class="card">
        <div class="section-heading">
          <div>
            <span class="tag">TASK MANAGEMENT</span>
            <h2>실무 업무 체크리스트</h2>
          </div>
          <span class="muted">${list.length}개 업무</span>
        </div>

        <div class="task-grid">
          ${list.map((task, i) => `
            <article class="task-card">
              <div class="task-number">TASK 0${i + 1}</div>
              <h3>${DB.esc(task[0])}</h3>
              <p>${DB.esc(task[1])}</p>
              <div class="task-fields">
                ${task[2].map(field => `
                  <span>${DB.esc(field)}</span>
                `).join("")}
              </div>
              <button class="btn secondary" data-task="${id}" data-index="${i}">
                업무 양식 열기 →
              </button>
            </article>
          `).join("")}
        </div>
      </section>
    `;
  }

  function open(id, index) {
    const task = tasks[id]?.[index];
    if (!task) return;

    const key = `task_${id}_${index}`;
    const saved = JSON.parse(localStorage.getItem(key) || "{}");

    DB.modal(`
      <span class="tag">HR WORK FORM</span>
      <h2>${DB.esc(task[0])}</h2>
      <p class="muted">${DB.esc(task[1])}</p>

      <form id="task-form">
        <div class="form-grid">
          ${task[2].map((field, i) => `
            <label class="field">
              <span>${DB.esc(field)}</span>
              ${/일$/.test(field)
                ? `<input type="date" name="f${i}" value="${DB.esc(saved["f" + i] || "")}">`
                : /인원|점수|예산|연봉/.test(field)
                  ? `<input type="number" name="f${i}" min="0" value="${DB.esc(saved["f" + i] || "")}">`
                  : `<textarea name="f${i}" rows="3">${DB.esc(saved["f" + i] || "")}</textarea>`
              }
            </label>
          `).join("")}
        </div>
        <button class="btn" type="submit">업무 내용 저장</button>
      </form>
    `);

    document.getElementById("task-form").onsubmit = event => {
      event.preventDefault();
      const values = Object.fromEntries(new FormData(event.target));
      localStorage.setItem(key, JSON.stringify(values));
      DB.close();
      alert("업무 내용이 저장되었습니다.");
    };
  }

  return { page, open };
})();