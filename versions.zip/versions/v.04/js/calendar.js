"use strict";

window.CalendarTool = (() => {
  function page() {
    const events = DB.get("calendar").sort((a,b) => a.date.localeCompare(b.date));

    return `
      <section class="page-header">
        <span class="tag">SCHEDULE MANAGEMENT</span>
        <h1>채용 캘린더</h1>
        <p>면접, 평가, 채용 관련 일정을 관리합니다.</p>
      </section>

      <section class="card">
        <div class="section-heading">
          <h2>전체 일정</h2>
          <button class="btn" id="add-event">+ 일정 등록</button>
        </div>

        <div class="event-list">
          ${events.map(e => `
            <article class="event-row">
              <div class="event-date">
                <strong>${DB.esc(e.date)}</strong>
                <span>${DB.esc(e.time || "")}</span>
              </div>
              <div class="event-info">
                <strong>${DB.esc(e.title)}</strong>
                <span>${DB.esc(e.type)} · ${DB.esc(e.person || "공통 일정")}</span>
              </div>
              <button class="btn small secondary" data-delete-event="${e.id}">삭제</button>
            </article>
          `).join("") || `<p class="empty">등록된 일정이 없습니다.</p>`}
        </div>
      </section>
    `;
  }

  function add() {
    DB.modal(`
      <h2>채용 일정 등록</h2>
      <form id="event-form">
        <div class="form-grid">
          <label class="field"><span>일정명</span><input name="title" required></label>
          <label class="field"><span>일정 유형</span>
            <select name="type">
              <option>면접</option><option>서류 심사</option>
              <option>과제 평가</option><option>최종 발표</option><option>기타</option>
            </select>
          </label>
          <label class="field"><span>날짜</span><input type="date" name="date" required value="${DB.today()}"></label>
          <label class="field"><span>시간</span><input type="time" name="time"></label>
          <label class="field"><span>지원자</span><input name="person"></label>
        </div>
        <button class="btn">일정 저장</button>
      </form>
    `);

    document.getElementById("event-form").onsubmit = event => {
      event.preventDefault();
      const fd = new FormData(event.target);
      DB.set("calendar", [...DB.get("calendar"), {
        id:DB.uid(),
        title:fd.get("title"),
        type:fd.get("type"),
        date:fd.get("date"),
        time:fd.get("time"),
        person:fd.get("person")
      }]);
      DB.close();
      App.render();
    };
  }

  function bind() {
    document.getElementById("add-event")?.addEventListener("click", add);

    document.querySelectorAll("[data-delete-event]").forEach(button => {
      button.onclick = () => {
        DB.set("calendar", DB.get("calendar").filter(e => e.id !== button.dataset.deleteEvent));
        App.render();
      };
    });
  }

  return { page, bind };
})();