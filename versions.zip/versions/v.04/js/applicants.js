"use strict";

window.Applicants = (() => {
  const skills = [
    "전문지식",
    "협업능력",
    "문제해결",
    "커뮤니케이션",
    "업무추진력",
    "조직적응력"
  ];

  const stages = [
    "서류 접수",
    "서류 심사",
    "면접 예정",
    "면접 완료",
    "최종 합격",
    "불합격"
  ];

  function chart(person, size = 280) {
    const center = size / 2;
    const radius = size * 0.34;
    const count = skills.length;
    const angle = i => -Math.PI / 2 + i * 2 * Math.PI / count;

    function point(i, value) {
      const a = angle(i);
      const r = radius * value / 100;
      return [
        center + r * Math.cos(a),
        center + r * Math.sin(a)
      ];
    }

    const polygon = skills.map((_, i) =>
      point(i, person.skills?.[skills[i]] || 0).join(",")
    ).join(" ");

    const rings = [20, 40, 60, 80, 100].map(value => `
      <polygon points="${skills.map((_, i) =>
        point(i, value).join(",")
      ).join(" ")}"
        fill="none" stroke="#e5e7eb" stroke-width="1"/>
    `).join("");

    const axes = skills.map((skill, i) => {
      const p = point(i, 100);
      const label = point(i, 125);
      return `
        <line x1="${center}" y1="${center}" x2="${p[0]}" y2="${p[1]}"
          stroke="#e5e7eb"/>
        <text x="${label[0]}" y="${label[1]}"
          text-anchor="middle" dominant-baseline="middle"
          font-size="10" fill="#667085">${DB.esc(skill)}</text>
      `;
    }).join("");

    return `
      <svg viewBox="0 0 ${size} ${size}" width="100%" role="img"
        aria-label="지원자 역량 레이더 차트">
        ${rings}
        ${axes}
        <polygon points="${polygon}"
          fill="#4779e8" fill-opacity=".20"
          stroke="#4779e8" stroke-width="2.5"/>
        ${skills.map((skill, i) => {
          const p = point(i, person.skills?.[skill] || 0);
          return `<circle cx="${p[0]}" cy="${p[1]}" r="4" fill="#4779e8"/>`;
        }).join("")}
      </svg>
    `;
  }

  function page() {
    const people = DB.get("applicants");

    return `
      <section class="page-header">
        <span class="tag">TALENT MANAGEMENT</span>
        <h1>지원자 관리</h1>
        <p>지원자 정보와 직무 역량 및 평가 현황을 통합 관리합니다.</p>
      </section>

      <div class="stats-grid">
        ${[
          ["전체 지원자",people.length],
          ["서류 심사",people.filter(p => p.stage === "서류 심사").length],
          ["면접 진행",people.filter(p => ["면접 예정","면접 완료"].includes(p.stage)).length],
          ["최종 합격",people.filter(p => p.stage === "최종 합격").length]
        ].map(item => `
          <article class="card">
            <span class="stat-label">${item[0]}</span>
            <div class="stat-value">${item[1]}</div>
          </article>
        `).join("")}
      </div>

      <section class="card">
        <div class="section-heading">
          <h2>지원자 목록</h2>
          <button class="btn" id="add-applicant">+ 지원자 등록</button>
        </div>

        <div class="table-wrap">
          <table>
            <thead>
              <tr>
                <th>이름</th>
                <th>지원 직무</th>
                <th>지원일</th>
                <th>종합 역량</th>
                <th>전형 단계</th>
                <th>관리</th>
              </tr>
            </thead>
            <tbody>
              ${people.map(p => `
                <tr>
                  <td><strong>${DB.esc(p.name)}</strong></td>
                  <td>${DB.esc(p.position)}</td>
                  <td>${DB.esc(p.date)}</td>
                  <td><strong>${DB.average(Object.values(p.skills || {}))}</strong> / 100</td>
                  <td><span class="status">${DB.esc(p.stage)}</span></td>
                  <td>
                    <button class="btn small secondary" data-view="${p.id}">상세</button>
                  </td>
                </tr>
              `).join("") || `
                <tr><td colspan="6" class="empty">등록된 지원자가 없습니다.</td></tr>
              `}
            </tbody>
          </table>
        </div>
      </section>
    `;
  }

  function openForm(person = null) {
    const editing = !!person;

    DB.modal(`
      <span class="tag">CANDIDATE PROFILE</span>
      <h2>${editing ? "지원자 정보 수정" : "신규 지원자 등록"}</h2>

      <form id="applicant-form">
        <div class="form-section">
          <h3>기본 정보</h3>
          <div class="form-grid">
            <label class="field">
              <span>이름</span>
              <input name="name" required value="${DB.esc(person?.name || "")}">
            </label>
            <label class="field">
              <span>지원 직무</span>
              <input name="position" required value="${DB.esc(person?.position || "")}">
            </label>
            <label class="field">
              <span>이메일</span>
              <input type="email" name="email" value="${DB.esc(person?.email || "")}">
            </label>
            <label class="field">
              <span>전화번호</span>
              <input name="phone" value="${DB.esc(person?.phone || "")}">
            </label>
            <label class="field">
              <span>지원일</span>
              <input type="date" name="date" value="${DB.esc(person?.date || DB.today())}">
            </label>
            <label class="field">
              <span>전형 단계</span>
              <select name="stage">
                ${stages.map(stage => `
                  <option ${person?.stage === stage ? "selected" : ""}>
                    ${stage}
                  </option>
                `).join("")}
              </select>
            </label>
          </div>
        </div>

        <div class="form-section">
          <h3>직무 역량 능력치</h3>
          <p class="muted">각 역량을 0~100점으로 평가하세요.</p>

          <div class="skill-input-grid">
            ${skills.map(skill => `
              <label class="skill-input">
                <span>${skill}</span>
                <div class="skill-control">
                  <input type="range" name="skill_${skill}"
                    min="0" max="100" step="1"
                    value="${person?.skills?.[skill] ?? 50}">
                  <output>${person?.skills?.[skill] ?? 50}</output>
                </div>
              </label>
            `).join("")}
          </div>
        </div>

        <div class="form-section">
          <h3>평가 정보</h3>
          <div class="form-grid">
            <label class="field">
              <span>평가자</span>
              <input name="evaluator" value="${DB.esc(person?.evaluator || "")}">
            </label>
            <label class="field">
              <span>평가 근거</span>
              <textarea name="reason" rows="3">${DB.esc(person?.reason || "")}</textarea>
            </label>
          </div>
        </div>

        <button type="submit" class="btn">저장하기</button>
      </form>
    `);

    const form = document.getElementById("applicant-form");

    form.querySelectorAll('input[type="range"]').forEach(input => {
      input.addEventListener("input", () => {
        input.nextElementSibling.value = input.value;
      });
    });

    form.onsubmit = event => {
      event.preventDefault();

      const fd = new FormData(form);
      const skillsData = {};

      skills.forEach(skill => {
        skillsData[skill] = Number(fd.get(`skill_${skill}`));
      });

      const people = DB.get("applicants");

      const result = {
        id: person?.id || DB.uid(),
        name: fd.get("name").trim(),
        position: fd.get("position").trim(),
        email: fd.get("email"),
        phone: fd.get("phone"),
        date: fd.get("date"),
        stage: fd.get("stage"),
        skills: skillsData,
        evaluator: fd.get("evaluator"),
        reason: fd.get("reason"),
        updatedAt: new Date().toISOString()
      };

      if (editing) {
        DB.set("applicants", people.map(p => p.id === person.id ? result : p));
      } else {
        DB.set("applicants", [...people, result]);
      }

      DB.close();
      App.render();
    };
  }

  function detail(id) {
    const person = DB.get("applicants").find(p => p.id === id);
    if (!person) return;

    const score = DB.average(Object.values(person.skills || {}));

    DB.modal(`
      <span class="tag">TALENT PROFILE</span>
      <div class="profile-header">
        <div>
          <h2>${DB.esc(person.name)}</h2>
          <p class="muted">${DB.esc(person.position)}</p>
          <span class="status">${DB.esc(person.stage)}</span>
        </div>
        <div class="profile-score">
          <strong>${score}</strong>
          <span>종합 역량</span>
        </div>
      </div>

      <div class="radar-card">
        <h3>역량 분석</h3>
        ${chart(person)}
      </div>

      <div class="skill-detail-grid">
        ${skills.map(skill => `
          <div class="skill-detail">
            <span>${skill}</span>
            <strong>${person.skills?.[skill] ?? 0}</strong>
          </div>
        `).join("")}
      </div>

      <div class="form-section">
        <h3>평가 정보</h3>
        <p>평가자: ${DB.esc(person.evaluator || "-")}</p>
        <p>${DB.esc(person.reason || "평가 근거 없음")}</p>
      </div>

      <div class="form-actions">
        <button class="btn secondary" id="edit-person">수정</button>
        <button class="btn danger" id="delete-person">삭제</button>
      </div>
    `);

    document.getElementById("edit-person").onclick = () => openForm(person);

    document.getElementById("delete-person").onclick = () => {
      if (!confirm("이 지원자를 삭제할까요?")) return;

      DB.set("applicants", DB.get("applicants").filter(p => p.id !== id));
      DB.close();
      App.render();
    };
  }

  function bind() {
    document.getElementById("add-applicant")
      ?.addEventListener("click", () => openForm());

    document.querySelectorAll("[data-view]").forEach(button => {
      button.onclick = () => detail(button.dataset.view);
    });
  }

  return { page, bind, openForm, detail, chart };
})();