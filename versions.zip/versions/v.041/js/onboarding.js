
"use strict";

window.Onboarding = (() => {
  const items=[
    "근로계약서 작성",
    "개인정보 및 입사 서류 제출",
    "사내 계정 발급",
    "업무 장비 지급",
    "이메일 및 협업 도구 설정",
    "조직 및 부서 소개",
    "직무 교육 진행",
    "멘토 지정",
    "30일 피드백",
    "60일 피드백",
    "90일 평가"
  ];

  function page() {
    const people=DB.get("onboarding");

    return `
      <section class="page-header">
        <span class="tag">EMPLOYEE EXPERIENCE</span>
        <h1>온보딩 관리</h1>
        <p>신규 입사자의 입사 준비와 조직 적응을 관리합니다.</p>
      </section>

      <div class="stats-grid">
        <article class="card">
          <span class="stat-label">전체 입사자</span>
          <div class="stat-value">${people.length}</div>
        </article>
        <article class="card">
          <span class="stat-label">완료</span>
          <div class="stat-value">${people.filter(p=>progress(p)===100).length}</div>
        </article>
        <article class="card">
          <span class="stat-label">진행 중</span>
          <div class="stat-value">${people.filter(p=>progress(p)<100).length}</div>
        </article>
        <article class="card">
          <span class="stat-label">평균 진행률</span>
          <div class="stat-value">${DB.average(people.map(progress))}%</div>
        </article>
      </div>

      <section class="card">
        <div class="section-heading">
          <h2>입사자 목록</h2>
          <button class="btn" id="onboarding-add">+ 입사자 등록</button>
        </div>

        <div class="table-wrap">
          <table>
            <thead>
              <tr>
                <th>이름</th>
                <th>부서</th>
                <th>직무</th>
                <th>입사일</th>
                <th>진행률</th>
                <th>관리</th>
              </tr>
            </thead>
            <tbody>
              ${people.map(p=>`
                <tr>
                  <td><strong>${DB.esc(p.name)}</strong></td>
                  <td>${DB.esc(p.department)}</td>
                  <td>${DB.esc(p.position)}</td>
                  <td>${DB.esc(p.date)}</td>
                  <td>
                    ${progress(p)}%
                    <div class="progress">
                      <span style="width:${progress(p)}%"></span>
                    </div>
                  </td>
                  <td>
                    <button class="btn small secondary" data-onboard="${p.id}">체크리스트</button>
                    <button class="btn small danger" data-onboard-delete="${p.id}">삭제</button>
                  </td>
                </tr>
              `).join("")}
            </tbody>
          </table>
        </div>
        ${people.length===0?'<div class="empty">등록된 입사자가 없습니다.</div>':""}
      </section>
    `;
  }

  function progress(p) {
    return Math.round(items.filter((_,i)=>p.checks?.[i]).length/items.length*100);
  }

  function form() {
    DB.modal(`
      <span class="tag">NEW EMPLOYEE</span>
      <h2>신규 입사자 등록</h2>

      <form id="onboarding-form">
        <div class="form-grid">
          <label class="field">
            <span>이름</span>
            <input name="name" required>
          </label>
          <label class="field">
            <span>부서</span>
            <input name="department" required>
          </label>
          <label class="field">
            <span>직무</span>
            <input name="position" required>
          </label>
          <label class="field">
            <span>입사일</span>
            <input name="date" type="date" required>
          </label>
          <label class="field">
            <span>멘토</span>
            <input name="mentor">
          </label>
        </div>
        <div class="form-actions">
          <button type="button" class="btn secondary" data-close>취소</button>
          <button class="btn">등록하기</button>
        </div>
      </form>
    `);

    document.getElementById("onboarding-form").onsubmit=e=>{
      e.preventDefault();
      const fd=new FormData(e.target);
      DB.set("onboarding",[
        ...DB.get("onboarding"),
        {
          id:DB.uid(),
          name:fd.get("name").trim(),
          department:fd.get("department").trim(),
          position:fd.get("position").trim(),
          date:fd.get("date"),
          mentor:fd.get("mentor").trim(),
          checks:{}
        }
      ]);
      DB.close();
      App.render();
    };
  }

  function detail(id) {
    const p=DB.get("onboarding").find(x=>x.id===id);
    if(!p)return;

    DB.modal(`
      <span class="tag">ONBOARDING CHECKLIST</span>
      <h2>${DB.esc(p.name)} · 입사 적응 관리</h2>
      <p>${DB.esc(p.department)} / ${DB.esc(p.position)}</p>
      <p>입사일 ${DB.esc(p.date)} · 멘토 ${DB.esc(p.mentor||"-")}</p>

      <div class="progress">
        <span style="width:${progress(p)}%"></span>
      </div>
      <p><strong>${progress(p)}% 완료</strong></p>

      <div class="check-grid">
        ${items.map((item,i)=>`
          <label class="check-card">
            <input type="checkbox" data-onboard-check="${i}"
              ${p.checks?.[i]?"checked":""}>
            ${item}
          </label>
        `).join("")}
      </div>

      <div class="form-actions">
        <button class="btn secondary" data-close>닫기</button>
      </div>
    `);

    document.querySelectorAll("[data-onboard-check]").forEach(input=>{
      input.onchange=()=>{
        const people=DB.get("onboarding");
        const index=people.findIndex(x=>x.id===id);
        if(index<0)return;

        people[index].checks={
          ...people[index].checks,
          [input.dataset.onboardCheck]:input.checked
        };

        DB.set("onboarding",people);
        detail(id);
      };
    });
  }

  function bind() {
    document.getElementById("onboarding-add")?.addEventListener("click",form);

    document.querySelectorAll("[data-onboard]").forEach(button=>{
      button.onclick=()=>detail(button.dataset.onboard);
    });

    document.querySelectorAll("[data-onboard-delete]").forEach(button=>{
      button.onclick=()=>{
        if(!confirm("입사자 정보를 삭제할까요?"))return;
        DB.set("onboarding",DB.get("onboarding").filter(p=>p.id!==button.dataset.onboardDelete));
        App.render();
      };
    });
  }

  return {page,bind};
})();
