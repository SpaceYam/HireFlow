
"use strict";

window.Backup = (() => {
  function page() {
    return `
      <section class="page-header">
        <span class="tag">DATA MANAGEMENT</span>
        <h1>데이터 백업</h1>
        <p>HIREFLOW에 저장된 데이터를 안전하게 관리하세요.</p>
      </section>

      <div class="document-grid">
        <section class="card">
          <h3>데이터 내보내기</h3>
          <p>지원자, 일정, 온보딩 데이터를 JSON 파일로 저장합니다.</p>
          <button class="btn" id="backup-export">백업 다운로드</button>
        </section>

        <section class="card">
          <h3>데이터 복원</h3>
          <p>기존 백업 파일을 불러와 데이터를 복원합니다.</p>
          <label class="btn secondary" for="backup-file">백업 파일 선택</label>
          <input type="file" id="backup-file" accept=".json,application/json" hidden>
        </section>

        <section class="card">
          <h3>전체 데이터 초기화</h3>
          <p>저장된 모든 데이터를 삭제합니다. 초기화 전 백업을 권장합니다.</p>
          <button class="btn danger" id="backup-reset">데이터 초기화</button>
        </section>
      </div>

      <section class="card">
        <h2>저장 현황</h2>
        <div class="stats-grid">
          <div class="metric-card">
            <span>지원자</span>
            <strong>${DB.get("applicants").length}명</strong>
          </div>
          <div class="metric-card">
            <span>일정</span>
            <strong>${DB.get("calendar").length}건</strong>
          </div>
          <div class="metric-card">
            <span>온보딩</span>
            <strong>${DB.get("onboarding").length}명</strong>
          </div>
        </div>
      </section>
    `;
  }

  function bind() {
    document.getElementById("backup-export")?.addEventListener("click",()=>{
      const payload={
        version:2,
        exportedAt:new Date().toISOString(),
        applicants:DB.get("applicants"),
        calendar:DB.get("calendar"),
        onboarding:DB.get("onboarding")
      };

      DB.download(
        "hireflow-backup-"+DB.today()+".json",
        JSON.stringify(payload,null,2),
        "application/json"
      );
    });

    document.getElementById("backup-file")?.addEventListener("change",async e=>{
      const file=e.target.files[0];
      if(!file)return;

      try{
        if(file.size>10*1024*1024)throw new Error("파일 크기가 10MB를 초과합니다.");

        const parsed=JSON.parse(await file.text());

        if(
          !parsed ||
          !Array.isArray(parsed.applicants) ||
          !Array.isArray(parsed.calendar) ||
          !Array.isArray(parsed.onboarding)
        ){
          throw new Error("HIREFLOW 백업 파일 형식이 아닙니다.");
        }

        if(!confirm("현재 데이터를 백업 파일의 데이터로 교체할까요?"))return;

        DB.set("applicants",parsed.applicants);
        DB.set("calendar",parsed.calendar);
        DB.set("onboarding",parsed.onboarding);

        alert("데이터 복원이 완료되었습니다.");
        App.render();
      }catch(error){
        alert("복원 실패: "+error.message);
      }finally{
        e.target.value="";
      }
    });

    document.getElementById("backup-reset")?.addEventListener("click",()=>{
      if(!confirm("모든 데이터를 삭제할까요?"))return;
      if(!confirm("삭제된 데이터는 복구할 수 없습니다. 계속할까요?"))return;

      DB.reset();
      App.render();
    });
  }

  return {page,bind};
})();
