
"use strict";

window.DocsForm = (() => {
  function render(doc,values={}) {
    return `
      <div class="form-intro">
        <span class="tag">HR STANDARD FORM</span>
        <h2>${DB.esc(doc.title)}</h2>
        <p>${DB.esc(doc.guide)}</p>
      </div>

      <form id="standard-document-form">
        ${Object.entries(doc.sections).map(([section,fields]) => `
          <section class="form-section">
            <h3>${DB.esc(section)}</h3>
            <div class="form-grid">
              ${fields.map((name,index) => {
                const key = section+"_"+index;
                const isDate = /일$/.test(name);
                const isNumber = /인원|점수|연봉|예산/.test(name);
                const type = isDate ? "date" : isNumber ? "number" : "text";

                return `
                  <label class="field">
                    <span>${DB.esc(name)}</span>
                    ${/의견|사유|업무|사항|역량|목표|강점|보완/.test(name)
                      ? `<textarea name="${DB.esc(key)}" rows="3">${DB.esc(values[key] || "")}</textarea>`
                      : `<input type="${type}" name="${DB.esc(key)}" value="${DB.esc(values[key] || "")}" ${isNumber?'min="0"':''}>`
                    }
                  </label>
                `;
              }).join("")}
            </div>
          </section>
        `).join("")}

        <div class="form-actions">
          <button type="button" class="btn secondary" data-close>취소</button>
          <button type="submit" class="btn">문서 미리보기</button>
        </div>
      </form>
    `;
  }

  function preview(doc,form) {
    const values = [...new FormData(form).entries()];

    const rows = Object.entries(doc.sections).map(([section,fields]) => `
      <tr class="print-section">
        <th colspan="2">${DB.esc(section)}</th>
      </tr>
      ${fields.map((name,index) => {
        const key = section+"_"+index;
        const value = form.elements.namedItem(key)?.value || "-";

        return `
          <tr>
            <th>${DB.esc(name)}</th>
            <td>${DB.esc(value)}</td>
          </tr>
        `;
      }).join("")}
    `).join("");

    const html = `
      <!DOCTYPE html>
      <html lang="ko">
      <head>
        <meta charset="UTF-8">
        <title>${DB.esc(doc.title)}</title>
        <style>
          body{font-family:Arial,sans-serif;padding:35px;color:#26334a}
          h1{border-bottom:3px solid #4779e8;padding-bottom:15px}
          table{width:100%;border-collapse:collapse;margin-top:25px}
          th,td{border:1px solid #ddd;padding:12px;text-align:left}
          th{width:25%;background:#f5f7fa}
          .print-section th{background:#eaf0ff;color:#315fbd}
          @media print{body{padding:10px}}
        </style>
      </head>
      <body>
        <h1>${DB.esc(doc.title)}</h1>
        <p>HIREFLOW HR DOCUMENT</p>
        <table>${rows}</table>
        <script>window.onload=()=>{};<\/script>
      </body>
      </html>
    `;

    DB.modal(`
      <span class="tag">DOCUMENT PREVIEW</span>
      <h2>${DB.esc(doc.title)}</h2>
      <div class="preview-frame">
        <iframe title="문서 미리보기" sandbox srcdoc="${DB.esc(html)}"></iframe>
      </div>
      <div class="form-actions">
        <button class="btn secondary" id="preview-back">다시 작성</button>
        <button class="btn" id="preview-download">HTML 다운로드</button>
      </div>
    `);

    document.getElementById("preview-download").onclick = () => {
      DB.download(doc.title+".html",html);
    };

    document.getElementById("preview-back").onclick = () => {
      window.Docs.open(doc.id, Object.fromEntries(values));
    };
  }

  return {render,preview};
})();
