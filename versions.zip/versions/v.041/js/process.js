
"use strict";

window.Process = (() => {
  const tasks = {
    planning: [
      {
        title:"인력 수요 분석",
        description:"조직의 인력 현황과 추가 채용 필요성을 확인합니다.",
        fields:["현재 인원","필요 인원","부족 인원","충원 목적","예산 검토"],
        document:"request"
      },
      {
        title:"채용 요청 승인",
        description:"채용 요청을 작성하고 승인 절차를 진행합니다.",
        fields:["요청 부서","요청자","직무명","요청 인원","승인 상태"],
        document:"request"
      },
      {
        title:"직무 분석",
        description:"직무 목적과 필수 역량을 구체화합니다.",
        fields:["직무 목적","주요 업무","필수 역량","우대 역량","성과 지표"],
        document:"jd"
      }
    ],
    posting:[
      {
        title:"채용 공고 작성",
        description:"직무기술서를 기반으로 채용 공고를 작성합니다.",
        fields:["직무 소개","주요 업무","자격 요건","근무 조건","접수 기간"],
        document:"posting"
      },
      {
        title:"모집 채널 선정",
        description:"직무에 적합한 후보자 모집 채널을 선택합니다.",
        fields:["채널명","모집 대상","게시일","지원자 수","성과"],
        document:"posting"
      }
    ],
    screening:[
      {
        title:"서류 검토 기준 수립",
        description:"직무 관련 평가 항목과 배점을 설정합니다.",
        fields:["필수 자격","전문지식","관련 경험","직무 적합성","평가 기준"],
        document:"interview"
      },
      {
        title:"지원자 서류 평가",
        description:"사전 정의된 기준에 따라 지원서를 검토합니다.",
        fields:["경력 검토","직무 경험","기술 역량","평가 의견","검토 결과"],
        document:"interview"
      }
    ],
    interview:[
      {
        title:"면접 질문 설계",
        description:"역량별 공통 질문과 평가 기준을 설계합니다.",
        fields:["전문지식 질문","협업 질문","문제해결 질문","평가 척도"],
        document:"interview"
      },
      {
        title:"면접 진행",
        description:"지원자에게 공통 질문을 적용하고 평가합니다.",
        fields:["면접관","면접일","전문지식","협업능력","종합 의견"],
        document:"interview"
      }
    ],
    assessment:[
      {
        title:"직무 과제 평가",
        description:"실제 직무와 관련된 과제를 평가합니다.",
        fields:["과제명","제출 기한","평가 기준","수행 점수","평가 의견"],
        document:"interview"
      }
    ],
    decision:[
      {
        title:"최종 평가",
        description:"전형별 평가 결과를 종합합니다.",
        fields:["서류 결과","면접 결과","과제 결과","종합 의견","최종 결정"],
        document:"final"
      },
      {
        title:"오퍼 및 입사 확정",
        description:"처우 조건과 입사 일정을 확정합니다.",
        fields:["제안 연봉","직급","입사 예정일","오퍼 수락 여부"],
        document:"final"
      }
    ],
    onboarding:[
      {
        title:"입사 전 준비",
        description:"계정, 장비, 서류 및 근무 환경을 준비합니다.",
        fields:["계정 발급","장비 준비","입사 서류","담당 멘토","입사일"],
        document:"onboarding"
      },
      {
        title:"30·60·90일 적응 관리",
        description:"신규 입사자의 업무 적응과 초기 성과를 점검합니다.",
        fields:["30일 평가","60일 평가","90일 평가","멘토 피드백"],
        document:"onboarding"
      }
    ]
  };

  const KEY = "hireflow_process_checks";

  function completed() {
    try {
      return JSON.parse(localStorage.getItem(KEY) || "{}");
    } catch {
      return {};
    }
  }

  function page(id) {
    const step = HF.steps.find(s=>s.id===id);
    const list = tasks[id] || [];
    const checks = completed();

    if (!step) return "<h1>페이지를 찾을 수 없습니다.</h1>";

    const done = list.filter((task,i)=>checks[id+"_"+i]).length;

    return `
      <section class="page-header">
        <span class="tag">RECRUITMENT PROCESS</span>
        <h1>${DB.esc(step.name)}</h1>
        <p>${DB.esc(step.description)}</p>
      </section>

      <section class="card">
        <div class="section-heading">
          <h2>업무 진행 현황</h2>
          <strong>${done}/${list.length} 완료</strong>
        </div>
        <div class="progress">
          <span style="width:${list.length ? done/list.length*100 : 0}%"></span>
        </div>
      </section>

      <div class="task-grid">
        ${list.map((task,i)=>`
          <article class="task-card">
            <span class="task-number">TASK 0${i+1}</span>
            <h3>${DB.esc(task.title)}</h3>
            <p>${DB.esc(task.description)}</p>

            <div class="task-fields">
              ${task.fields.map(f=>`<span>${DB.esc(f)}</span>`).join("")}
            </div>

            <label class="task-check">
              <input type="checkbox" data-check="${id}_${i}"
                ${checks[id+"_"+i]?"checked":""}>
              업무 완료
            </label>

            <button class="btn secondary"
              data-task="${id}" data-index="${i}">
              업무 양식 열기
            </button>
          </article>
        `).join("")}
      </div>

      <section class="card">
        <h2>관련 HR 도구</h2>
        <a class="btn" href="#/documents">표준 문서 자료실</a>
        <a class="btn secondary" href="#/calendar">채용 캘린더</a>
      </section>
    `;
  }

  function bind() {
    document.querySelectorAll("[data-check]").forEach(input=>{
      input.onchange = () => {
        const checks = completed();
        checks[input.dataset.check] = input.checked;
        localStorage.setItem(KEY,JSON.stringify(checks));
        App.render();
      };
    });
  }

  function open(id,index) {
    const task = tasks[id]?.[index];
    if (!task) return;

    DB.modal(`
      <span class="tag">HR WORKFLOW FORM</span>
      <h2>${DB.esc(task.title)}</h2>
      <p>${DB.esc(task.description)}</p>

      <form id="task-form">
        <div class="form-grid">
          ${task.fields.map((field,i)=>`
            <label class="field">
              <span>${DB.esc(field)}</span>
              ${/일$/.test(field)
                ? `<input type="date" name="f${i}">`
                : /인원|점수|연봉/.test(field)
                  ? `<input type="number" min="0" name="f${i}">`
                  : /의견|목적|기준|역량|업무/.test(field)
                    ? `<textarea name="f${i}" rows="3"></textarea>`
                    : `<input name="f${i}">`
              }
            </label>
          `).join("")}
        </div>

        <div class="form-actions">
          <button type="button" class="btn secondary" data-close>닫기</button>
          <button class="btn">작성 완료</button>
        </div>
      </form>

      ${task.document ? `
        <div class="form-actions">
          <button class="btn secondary" id="task-doc">관련 표준 양식 열기</button>
        </div>
      `:""}
    `);

    document.getElementById("task-form").onsubmit = e=>{
      e.preventDefault();
      const checks = completed();
      checks[id+"_"+index] = true;
      localStorage.setItem(KEY,JSON.stringify(checks));
      DB.close();
      App.render();
    };

    document.getElementById("task-doc")?.addEventListener("click",()=>{
      Docs.open(task.document);
    });
  }

  return {page,open,bind};
})();
