
"use strict";

window.CalendarTool = (() => {
  let current = new Date();
  let selected = DB.today();

  const types = [
    "서류 마감",
    "면접",
    "과제 평가",
    "최종 발표",
    "입사",
    "기타"
  ];

  function dateString(y,m,d) {
    return `${y}-${String(m+1).padStart(2,"0")}-${String(d).padStart(2,"0")}`;
  }

  function page() {
    const year=current.getFullYear();
    const month=current.getMonth();
    const first=new Date(year,month,1);
    const start=first.getDay();
    const days=new Date(year,month+1,0).getDate();
    const previousDays=new Date(year,month,0).getDate();
    const events=DB.get("calendar");

    const cells=[];

    for(let i=0;i<42;i++){
      let date;
      let other=false;

      if(i<start){
        date=previousDays-start+i+1;
        other=true;
      }else if(i>=start+days){
        date=i-(start+days)+1;
        other=true;
      }else{
        date=i-start+1;
      }

      const cellDate=other
        ? i<start
          ? dateString(year,month-1,date)
          : dateString(year,month+1,date)
        : dateString(year,month,date);

      const dayEvents=events.filter(e=>e.date===cellDate);

      cells.push(`
        <div class="calendar-day ${other?"other-month":""}
          ${cellDate===DB.today()?"today":""}
          ${cellDate===selected?"selected-day":""}"
          data-date="${cellDate}">

          <button class="calendar-date">${date}</button>

          <div class="calendar-events">
            ${dayEvents.slice(0,3).map(e=>`
              <button class="calendar-event event-${typeClass(e.type)}"
                data-event="${e.id}" title="${DB.esc(e.title)}">
                ${DB.esc(e.time||"")} ${DB.esc(e.title)}
              </button>
            `).join("")}
            ${dayEvents.length>3?`<span class="more-events">+${dayEvents.length-3}개</span>`:""}
          </div>
        </div>
      `);
    }

    const selectedEvents=events.filter(e=>e.date===selected);

    return `
      <section class="page-header">
        <span class="tag">RECRUITMENT SCHEDULE</span>
        <h1>채용 캘린더</h1>
        <p>면접, 서류 마감, 과제 평가 및 입사 일정을 한눈에 관리하세요.</p>
      </section>

      <section class="card calendar-card">
        <div class="calendar-toolbar">
          <div>
            <h2>${year}년 ${month+1}월</h2>
            <p>MONTHLY SCHEDULE</p>
          </div>
          <div class="calendar-controls">
            <button class="btn secondary" id="calendar-today">오늘</button>
            <button class="btn secondary" id="calendar-prev">‹</button>
            <button class="btn secondary" id="calendar-next">›</button>
            <button class="btn" id="calendar-add">+ 일정 등록</button>
          </div>
        </div>

        <div class="calendar-legend">
          ${types.map(t=>`
            <span><i class="legend-${typeClass(t)}"></i>${t}</span>
          `).join("")}
        </div>

        <div class="calendar-grid">
          ${["일","월","화","수","목","금","토"].map(d=>`
            <div class="calendar-weekday">${d}</div>
          `).join("")}
          ${cells.join("")}
        </div>
      </section>

      <section class="card">
        <div class="section-heading">
          <div>
            <h2>${DB.esc(selected)} 일정</h2>
            <p>선택한 날짜의 채용 일정</p>
          </div>
          <button class="btn secondary" id="selected-add">+ 일정 추가</button>
        </div>

        ${selectedEvents.length?selectedEvents.map(e=>`
          <div class="calendar-list-item">
            <span class="event-dot dot-${typeClass(e.type)}"></span>
            <div class="event-info">
              <strong>${DB.esc(e.title)}</strong>
              <p>${DB.esc(e.type)} · ${DB.esc(e.person||"공통")} · ${DB.esc(e.location||"")}</p>
            </div>
            <strong>${DB.esc(e.time||"시간 미정")}</strong>
            <button class="btn small secondary" data-event="${e.id}">상세</button>
          </div>
        `).join(""):'<div class="empty">선택한 날짜에 등록된 일정이 없습니다.</div>'}
      </section>
    `;
  }

  function typeClass(type) {
    return ({
      "서류 마감":"blue",
      "면접":"purple",
      "과제 평가":"orange",
      "최종 발표":"green",
      "입사":"teal",
      "기타":"gray"
    })[type]||"gray";
  }

  function bind() {
    document.getElementById("calendar-prev")?.addEventListener("click",()=>{
      current.setMonth(current.getMonth()-1);
      App.render();
    });

    document.getElementById("calendar-next")?.addEventListener("click",()=>{
      current.setMonth(current.getMonth()+1);
      App.render();
    });

    document.getElementById("calendar-today")?.addEventListener("click",()=>{
      current=new Date();
      selected=DB.today();
      App.render();
    });

    document.querySelectorAll("[data-date]").forEach(cell=>{
      cell.addEventListener("click",e=>{
        if(e.target.closest("[data-event]"))return;
        selected=cell.dataset.date;
        App.render();
      });
    });

    document.getElementById("calendar-add")?.addEventListener("click",()=>form());
    document.getElementById("selected-add")?.addEventListener("click",()=>form({date:selected}));

    document.querySelectorAll("[data-event]").forEach(button=>{
      button.addEventListener("click",e=>{
        e.stopPropagation();
        detail(button.dataset.event);
      });
    });
  }

  function form(eventData={}) {
    const editing=!!eventData.id;
    const people=DB.get("applicants");

    DB.modal(`
      <span class="tag">SCHEDULE MANAGEMENT</span>
      <h2>${editing?"일정 수정":"새 채용 일정 등록"}</h2>

      <form id="calendar-form">
        <div class="form-grid">
          <label class="field">
            <span>일정명</span>
            <input name="title" value="${DB.esc(eventData.title||"")}" required>
          </label>

          <label class="field">
            <span>일정 유형</span>
            <select name="type">
              ${types.map(t=>`
                <option ${eventData.type===t?"selected":""}>${t}</option>
              `).join("")}
            </select>
          </label>

          <label class="field">
            <span>날짜</span>
            <input type="date" name="date" value="${eventData.date||selected}" required>
          </label>

          <label class="field">
            <span>시간</span>
            <input type="time" name="time" value="${eventData.time||"10:00"}">
          </label>

          <label class="field">
            <span>관련 지원자</span>
            <select name="person">
              <option value="">공통 일정</option>
              ${people.map(p=>`
                <option value="${DB.esc(p.name)}"
                  ${eventData.person===p.name?"selected":""}>
                  ${DB.esc(p.name)}
                </option>
              `).join("")}
            </select>
          </label>

          <label class="field">
            <span>장소 또는 링크</span>
            <input name="location" value="${DB.esc(eventData.location||"")}">
          </label>
        </div>

        <label class="field">
          <span>메모</span>
          <textarea name="memo">${DB.esc(eventData.memo||"")}</textarea>
        </label>

        <div class="form-actions">
          <button type="button" class="btn secondary" data-close>취소</button>
          <button class="btn">저장</button>
        </div>
      </form>
    `);

    document.getElementById("calendar-form").onsubmit=e=>{
      e.preventDefault();
      const fd=new FormData(e.target);
      const events=DB.get("calendar");

      const record={
        ...eventData,
        id:eventData.id||DB.uid(),
        title:fd.get("title").trim(),
        type:fd.get("type"),
        date:fd.get("date"),
        time:fd.get("time"),
        person:fd.get("person"),
        location:fd.get("location").trim(),
        memo:fd.get("memo").trim()
      };

      const duplicate=events.find(x=>
        x.id!==record.id &&
        x.date===record.date &&
        x.time===record.time &&
        x.person===record.person &&
        record.person
      );

      if(duplicate && !confirm("같은 지원자의 동일 시간 일정이 있습니다. 저장할까요?"))return;

      DB.set("calendar",editing
        ?events.map(x=>x.id===record.id?record:x)
        :[...events,record]
      );

      selected=record.date;
      current=new Date(record.date+"T12:00:00");
      DB.close();
      App.render();
    };
  }

  function detail(id) {
    const e=DB.get("calendar").find(x=>x.id===id);
    if(!e)return;

    DB.modal(`
      <span class="tag">SCHEDULE DETAIL</span>
      <h2>${DB.esc(e.title)}</h2>
      <div class="detail-list">
        <p><strong>유형</strong>${DB.esc(e.type)}</p>
        <p><strong>날짜</strong>${DB.esc(e.date)}</p>
        <p><strong>시간</strong>${DB.esc(e.time||"미정")}</p>
        <p><strong>지원자</strong>${DB.esc(e.person||"공통")}</p>
        <p><strong>장소</strong>${DB.esc(e.location||"-")}</p>
        <p><strong>메모</strong>${DB.esc(e.memo||"-")}</p>
      </div>
      <div class="form-actions">
        <button class="btn secondary" data-close>닫기</button>
        <button class="btn secondary" id="event-edit">수정</button>
        <button class="btn danger" id="event-delete">삭제</button>
      </div>
    `);

    document.getElementById("event-edit").onclick=()=>form(e);

    document.getElementById("event-delete").onclick=()=>{
      if(!confirm("이 일정을 삭제할까요?"))return;
      DB.set("calendar",DB.get("calendar").filter(x=>x.id!==id));
      DB.close();
      App.render();
    };
  }

  return {page,bind,form};
})();
