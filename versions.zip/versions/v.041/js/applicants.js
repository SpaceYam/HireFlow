
"use strict";

window.Applicants = (() => {
  const skills = HF.skills;

  function page() {
    const people = DB.get("applicants");

    return `
      <section class="page-header">
        <span class="tag">TALENT MANAGEMENT</span>
        <h1>지원자 관리</h1>
        <p>지원자 정보와 직무 역량을 통합 관리합니다.</p>
      </section>

      <section class="stats-grid">
        ${[
          ["전체 지원자",people.length],
          ["서류 검토",people.filter(p=>p.stage==="서류 검토").length],
          ["면접 진행",people.filter(p=>p.stage.includes("면접")).length],
          ["최종 합격",people.filter(p=>p.stage==="최종 합격").length]
        ].map(([label,value])=>`
          <article class="card">
            <span class="stat-label">${label}</span>
            <div class="stat-value">${value}</div>
          </article>
        `).join("")}
      </section>

      <section class="card">
        <div class="section-heading">
          <h2>지원자 목록</h2>
          <button class="btn" id="add-applicant">+ 지원자 등록</button>
        </div>

        <div class="filter-bar">
          <input id="applicant-search" placeholder="이름 또는 지원 직무 검색">
          <select id="applicant-filter">
            <option value="">전체 전형</option>
            ${HF.stages.map(s=>`<option>${s}</option>`).join("")}
          </select>
        </div>

        <div class="table-wrap">
          <table>
            <thead>
              <tr>
                <th>지원자</th>
                <th>지원 직무</th>
                <th>전형 단계</th>
                <th>역량 종합 점수</th>
                <th>등록일</th>
                <th>관리</th>
              </tr>
            </thead>
            <tbody id="applicant-rows">
              ${rows(people)}
            </tbody>
          </table>
        </div>
        ${people.length===0?'<div class="empty">등록된 지원자가 없습니다.</div>':""}
      </section>
    `;
  }

  function rows(people) {
    return people.map(p=>`
      <tr>
        <td>
          <strong>${DB.esc(p.name)}</strong>
          <br><span class="muted">${DB.esc(p.email)}</span>
        </td>
        <td>${DB.esc(p.position)}</td>
        <td><span class="status">${DB.esc(p.stage)}</span></td>
        <td>
          <strong>${score(p)}점</strong>
          <div class="progress">
            <span style="width:${score(p)}%"></span>
          </div>
        </td>
        <td>${DB.esc(p.created || "-")}</td>
        <td>
          <button class="btn small secondary" data-profile="${p.id}">상세</button>
          <button class="btn small secondary" data-edit="${p.id}">수정</button>
          <button class="btn small danger" data-delete="${p.id}">삭제</button>
        </td>
      </tr>
    `).join("");
  }

  function score(person) {
    return DB.average(skills.map(s=>DB.number(person.skills?.[s])));
  }

  function radar(person) {
    const values = skills.map(s=>Math.max(0,Math.min(100,DB.number(person.skills?.[s]))));
    const center = 180;
    const radius = 115;

    function point(value,index,multiplier=1) {
      const angle = -Math.PI/2 + index*2*Math.PI/6;
      const r = radius*(value/100)*multiplier;
      return [
        center+Math.cos(angle)*r,
        center+Math.sin(angle)*r
      ];
    }

    function polygon(multiplier) {
      return skills.map((_,i)=>point(100,i,multiplier).join(",")).join(" ");
    }

    const dataPoints = values.map((v,i)=>point(v,i).join(",")).join(" ");

    return `
      <div class="radar-card">
        <svg viewBox="0 0 360 360" role="img" aria-label="지원자 역량 레이더 차트">
          ${[.25,.5,.75,1].map(n=>`
            <polygon points="${polygon(n)}"
              fill="none" stroke="#e7ebf2" stroke-width="1"/>
          `).join("")}

          ${skills.map((s,i)=>{
            const p=point(100,i);
            return `
              <line x1="${center}" y1="${center}"
                x2="${p[0]}" y2="${p[1]}"
                stroke="#e7ebf2"/>
            `;
          }).join("")}

          <polygon points="${dataPoints}"
            fill="rgba(71,121,232,.18)"
            stroke="#4779e8"
            stroke-width="3"
            stroke-linejoin="round"/>

          ${values.map((v,i)=>{
            const p=point(v,i);
            return `<circle cx="${p[0]}" cy="${p[1]}" r="4" fill="#4779e8"/>`;
          }).join("")}

          ${skills.map((s,i)=>{
            const p=point(100,i,1.22);
            return `
              <text x="${p[0]}" y="${p[1]}"
                text-anchor="middle"
                dominant-baseline="middle"
                font-size="11" fill="#667085">${DB.esc(s)}</text>
            `;
          }).join("")}
        </svg>
      </div>
    `;
  }

  function form(person={}) {
    const editing=!!person.id;

    DB.modal(`
      <span class="tag">TALENT PROFILE</span>
      <h2>${editing?"지원자 정보 수정":"신규 지원자 등록"}</h2>
      <p class="muted">기본 정보와 직무 관련 역량을 입력하세요.</p>

      <form id="applicant-form">
        <section class="form-section">
          <h3>기본 정보</h3>
          <div class="form-grid">
            ${[
              ["name","이름",person.name,"text"],
              ["email","이메일",person.email,"email"],
              ["phone","연락처",person.phone,"tel"],
              ["position","지원 직무",person.position,"text"]
            ].map(([name,label,value,type])=>`
              <label class="field">
                <span>${label}</span>
                <input name="${name}" type="${type}"
                  value="${DB.esc(value||"")}" required>
              </label>
            `).join("")}

            <label class="field">
              <span>전형 단계</span>
              <select name="stage">
                ${HF.stages.map(s=>`
                  <option ${person.stage===s?"selected":""}>${s}</option>
                `).join("")}
              </select>
            </label>
          </div>
        </section>

        <section class="form-section">
          <h3>직무 역량 능력치</h3>
          <p class="muted">평가 근거에 따라 각 역량을 0~100점으로 입력하세요.</p>

          <div class="skill-input-grid">
            ${skills.map((s,i)=>`
              <div class="skill-input">
                <span>${s}</span>
                <div class="skill-control">
                  <input type="range" min="0" max="100"
                    name="skill_${i}"
                    value="${DB.number(person.skills?.[s] ?? 50)}"
                    data-skill-range>
                  <output>${DB.number(person.skills?.[s] ?? 50)}</output>
                </div>
              </div>
            `).join("")}
          </div>
        </section>

        <label class="field">
          <span>평가 종합 의견</span>
          <textarea name="memo" rows="3">${DB.esc(person.memo||"")}</textarea>
        </label>

        <div class="form-actions">
          <button type="button" class="btn secondary" data-close>취소</button>
          <button class="btn">저장하기</button>
        </div>
      </form>
    `);

    document.querySelectorAll("[data-skill-range]").forEach(input=>{
      input.oninput=()=>{
        input.nextElementSibling.value=input.value;
      };
    });

    document.getElementById("applicant-form").onsubmit=e=>{
      e.preventDefault();

      const fd=new FormData(e.target);
      const current=DB.get("applicants");
      const values={};

      skills.forEach((s,i)=>{
        values[s]=DB.number(fd.get("skill_"+i));
      });

      const record={
        id:person.id||DB.uid(),
        name:fd.get("name").trim(),
        email:fd.get("email").trim(),
        phone:fd.get("phone").trim(),
        position:fd.get("position").trim(),
        stage:fd.get("stage"),
        skills:values,
        memo:fd.get("memo").trim(),
        created:person.created||DB.today()
      };

      const updated=editing
        ? current.map(p=>p.id===person.id?record:p)
        : [...current,record];

      DB.set("applicants",updated);
      DB.close();
      App.render();
    };
  }

  function profile(id) {
    const p=DB.get("applicants").find(x=>x.id===id);
    if(!p)return;

    DB.modal(`
      <span class="tag">CANDIDATE PROFILE</span>
      <div class="profile-header">
        <div>
          <h2>${DB.esc(p.name)}</h2>
          <p>${DB.esc(p.position)} · ${DB.esc(p.stage)}</p>
          <p>${DB.esc(p.email)} · ${DB.esc(p.phone)}</p>
        </div>
        <div class="profile-score">
          <strong>${score(p)}</strong>
          <span>OVERALL</span>
        </div>
      </div>

      <h3>직무 역량 분석</h3>
      ${radar(p)}

      <div class="skill-detail-grid">
        ${skills.map(s=>`
          <div class="skill-detail">
            <span>${s}</span>
            <strong>${DB.number(p.skills?.[s])}/100</strong>
          </div>
        `).join("")}
      </div>

      <section class="form-section">
        <h3>평가 의견</h3>
        <p>${DB.esc(p.memo||"등록된 평가 의견이 없습니다.")}</p>
      </section>

      <div class="form-actions">
        <button class="btn secondary" data-close>닫기</button>
        <button class="btn" id="profile-edit">정보 수정</button>
      </div>
    `);

    document.getElementById("profile-edit").onclick=()=>form(p);
  }

  function bind() {
    document.getElementById("add-applicant")?.addEventListener("click",()=>form());

    document.getElementById("applicant-rows")?.addEventListener("click",e=>{
      const profileButton=e.target.closest("[data-profile]");
      const editButton=e.target.closest("[data-edit]");
      const deleteButton=e.target.closest("[data-delete]");

      if(profileButton) profile(profileButton.dataset.profile);

      if(editButton){
        const p=DB.get("applicants").find(x=>x.id===editButton.dataset.edit);
        if(p)form(p);
      }

      if(deleteButton){
        if(confirm("이 지원자를 삭제할까요?")){
          DB.set("applicants",DB.get("applicants").filter(p=>p.id!==deleteButton.dataset.delete));
          App.render();
        }
      }
    });

    const filter=()=>{
      const keyword=document.getElementById("applicant-search")?.value.toLowerCase()||"";
      const stage=document.getElementById("applicant-filter")?.value||"";

      const filtered=DB.get("applicants").filter(p=>
        (p.name+" "+p.position).toLowerCase().includes(keyword) &&
        (!stage||p.stage===stage)
      );

      document.getElementById("applicant-rows").innerHTML=rows(filtered);
    };

    document.getElementById("applicant-search")?.addEventListener("input",filter);
    document.getElementById("applicant-filter")?.addEventListener("change",filter);
  }

  return {page,bind,form,profile,radar};
})();