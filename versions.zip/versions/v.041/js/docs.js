
"use strict";

window.Docs = (() => {
  function catalog() {
    return `
      <section class="page-header">
        <span class="tag">HR DOCUMENT CENTER</span>
        <h1>HR 표준 문서 자료실</h1>
        <p>채용 실무에 필요한 표준 문서를 작성하고 관리하세요.</p>
      </section>

      <div class="document-grid">
        ${Object.entries(DOC_DATA).map(([id,doc]) => `
          <article class="card document-card">
            <span class="tag">${DB.esc(doc.category)}</span>
            <h3>${DB.esc(doc.title)}</h3>
            <p>${DB.esc(doc.guide)}</p>
            <button class="btn" data-doc="${id}">양식 열기</button>
          </article>
        `).join("")}
      </div>

      <section class="card">
        <h2>채용 공고 게시 채널</h2>
        <div class="channel-grid">
          ${HF.channels.map(channel => `
            <a href="${DB.esc(channel.url)}"
              target="_blank" rel="noopener"
              class="channel-card">
              <strong>${DB.esc(channel.name)}</strong>
              <span>${DB.esc(channel.category)}</span>
              <span>사이트 방문 →</span>
            </a>
          `).join("")}
        </div>
      </section>
    `;
  }

  function open(id,previous={}) {
    const doc = DOC_DATA[id];
    if (!doc) return;

    doc.id = id;

    DB.modal(DocsForm.render(doc,previous));

    document.getElementById("standard-document-form").onsubmit = event => {
      event.preventDefault();
      DocsForm.preview(doc,event.target);
    };
  }

  return {catalog,open};
})();
