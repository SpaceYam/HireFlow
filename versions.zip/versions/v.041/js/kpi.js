
"use strict";

window.KPI = (() => {
  function calculate() {
    const people=DB.get("applicants");
    const calendar=DB.get("calendar");

    const total=people.length;
    const passed=people.filter(p=>p.stage==="최종 합격").length;
    const failed=people.filter(p=>p.stage==="불합격").length;
    const active=total-passed-failed;

    const interviews=calendar.filter(e=>e.type==="면접").length;

    return {
      total,
      passed,
      failed,
      active,
      interviews,
      passRate:total?Math.round(passed/total*100):0,
      failRate:total?Math.round(failed/total*100):0
    };
  }

  function page() {
    const k=calculate();

    return `
      <section class="page-header">
        <span class="tag">HR PERFORMANCE ANALYTICS</span>
        <h1>KPI 분석</h1>
        <p>채용 성과를 수치로 확인하고 개선 방향을 도출하세요.</p>
      </section>

      <div class="stats-grid">
        ${[
          ["전체 지원자",k.total,"명"],
          ["최종 합격",k.passed,"명"],
          ["합격 전환율",k.passRate,"%"],
          ["등록된 면접",k.interviews,"건"]
        ].map(([label,value,unit])=>`
          <article class="card metric-card">
            <span>${label}</span>
            <strong>${value}${unit}</strong>
          </article>
        `).join("")}
      </div>

      <section class="card">
        <h2>채용 전형 현황</h2>

        ${HF.stages.map(stage=>{
          const count=DB.get("applicants").filter(p=>p.stage===stage).length;
          const width=k.total?count/k.total*100:0;

          return `
            <div class="bar-item">
              <span>${stage}</span>
              <div class="progress">
                <span style="width:${width}%"></span>
              </div>
              <strong>${count}</strong>
            </div>
          `;
        }).join("")}
      </section>

      <section class="card">
        <h2>채용 성과 요약</h2>
        <div class="dashboard-grid">
          <div class="metric-card">
            <span>진행 중 인원</span>
            <strong>${k.active}명</strong>
          </div>
          <div class="metric-card">
            <span>불합격 인원</span>
            <strong>${k.failed}명</strong>
          </div>
        </div>
      </section>

      <section class="card">
        <span class="tag">WHAT-IF ANALYSIS</span>
        <h2>채용 KPI 시뮬레이터</h2>
        <p>가상의 채용 수치를 입력하고 채용 효율과 예상 성과를 계산하세요.</p>

        <form id="kpi-simulator">
          <div class="form-grid">
            <label class="field">
              <span>예상 전체 지원자 수</span>
              <input type="number" name="total" min="1" value="100" required>
            </label>

            <label class="field">
              <span>서류 통과 인원</span>
              <input type="number" name="screened" min="0" value="40" required>
            </label>

            <label class="field">
              <span>면접 통과 인원</span>
              <input type="number" name="interviewed" min="0" value="20" required>
            </label>

            <label class="field">
              <span>최종 합격 인원</span>
              <input type="number" name="hired" min="0" value="10" required>
            </label>

            <label class="field">
              <span>전체 채용 소요일</span>
              <input type="number" name="days" min="1" value="30" required>
            </label>

            <label class="field">
              <span>오퍼 발송 인원</span>
              <input type="number" name="offers" min="0" value="12" required>
            </label>

            <label class="field">
              <span>오퍼 수락 인원</span>
              <input type="number" name="accepted" min="0" value="10" required>
            </label>

            <label class="field">
              <span>채용 목표 인원</span>
              <input type="number" name="target" min="1" value="12" required>
            </label>
          </div>

          <div class="form-actions">
            <button type="reset" class="btn secondary">초기화</button>
            <button class="btn">KPI 계산하기</button>
          </div>
        </form>

        <div id="kpi-result" class="simulation-result">
          <div class="empty">수치를 입력하고 계산하기를 눌러주세요.</div>
        </div>
      </section>
    `;
  }

  function bind() {
    const form=document.getElementById("kpi-simulator");
    if(!form)return;

    form.addEventListener("submit",e=>{
      e.preventDefault();

      const fd=new FormData(form);

      const total=Number(fd.get("total"));
      const screened=Number(fd.get("screened"));
      const interviewed=Number(fd.get("interviewed"));
      const hired=Number(fd.get("hired"));
      const days=Number(fd.get("days"));
      const offers=Number(fd.get("offers"));
      const accepted=Number(fd.get("accepted"));
      const target=Number(fd.get("target"));

      const result=document.getElementById("kpi-result");

      if(
        !Number.isInteger(total)||total<1||
        !Number.isInteger(days)||days<1||
        !Number.isInteger(target)||target<1||
        [screened,interviewed,hired,offers,accepted].some(v=>!Number.isInteger(v)||v<0)||
        screened>total||
        interviewed>screened||
        hired>interviewed||
        accepted>offers||
        hired>offers
      ){
        result.innerHTML=`
          <div class="validation-error">
            입력값을 확인해주세요. 인원은 음수가 될 수 없으며 각 전형 인원은 이전 단계보다 클 수 없습니다.
          </div>
        `;
        return;
      }

      const metrics=[
        ["서류 통과율",screened/total*100],
        ["면접 통과율",screened?interviewed/screened*100:0],
        ["최종 전환율",total?hired/total*100:0],
        ["오퍼 수락률",offers?accepted/offers*100:0],
        ["채용 목표 달성률",accepted/target*100]
      ];

      result.innerHTML=`
        <h3>시뮬레이션 결과</h3>
        <div class="simulation-grid">
          ${metrics.map(([label,value])=>`
            <article class="simulation-metric">
              <span>${label}</span>
              <strong>${value.toFixed(1)}%</strong>
              <div class="progress">
                <span style="width:${Math.min(100,value)}%"></span>
              </div>
            </article>
          `).join("")}
          <article class="simulation-metric">
            <span>평균 채용 소요일</span>
            <strong>${days}일</strong>
          </article>
          <article class="simulation-metric">
            <span>목표 대비 미충원</span>
            <strong>${Math.max(0,target-accepted)}명</strong>
          </article>
        </div>

        <div class="guide-box">
          <strong>HR 분석 의견</strong>
          <p>
            ${accepted>=target
              ?"현재 입력 기준으로 채용 목표를 달성했습니다."
              :`목표 인원까지 ${target-accepted}명의 추가 충원이 필요합니다.`}
            ${offers===0?" 오퍼 발송 계획을 수립하세요.":""}
            ${offers>0&&accepted/offers<.7?" 오퍼 수락률 개선을 위한 처우 및 후보자 경험 검토가 필요합니다.":""}
            ${total>0&&screened/total<.2?" 서류 통과율이 낮으므로 모집 채널과 자격 요건을 점검해보세요.":""}
          </p>
        </div>
      `;
    });

    form.addEventListener("reset",()=>{
      setTimeout(()=>{
        document.getElementById("kpi-result").innerHTML=
          '<div class="empty">수치를 입력하고 계산하기를 눌러주세요.</div>';
      },0);
    });
  }

  return {page,bind,calculate};
})();
