
"use strict";

window.HF = {
  steps: [
    {id:"planning",name:"채용 기획",description:"인력 수요 분석 및 채용 계획 수립"},
    {id:"posting",name:"채용 공고",description:"채용 공고 작성 및 모집 채널 운영"},
    {id:"screening",name:"서류 전형",description:"지원서 검토 및 직무 역량 평가"},
    {id:"interview",name:"면접 전형",description:"구조화 면접 및 평가 진행"},
    {id:"assessment",name:"역량 평가",description:"직무 과제 및 실무 능력 검증"},
    {id:"decision",name:"최종 결정",description:"최종 합격 결정 및 오퍼 발송"},
    {id:"onboarding",name:"온보딩",description:"신규 입사자 적응 및 조직 정착"}
  ],

  channels: [
    {name:"사람인",category:"종합 채용",url:"https://www.saramin.co.kr"},
    {name:"잡코리아",category:"종합 채용",url:"https://www.jobkorea.co.kr"},
    {name:"원티드",category:"IT 및 전문직",url:"https://www.wanted.co.kr"},
    {name:"LinkedIn",category:"글로벌 채용",url:"https://www.linkedin.com"}
  ],

  skills: [
    "전문지식",
    "협업능력",
    "문제해결",
    "의사소통",
    "업무추진력",
    "창의성"
  ],

  stages: [
    "서류 검토",
    "1차 면접",
    "2차 면접",
    "과제 평가",
    "최종 합격",
    "불합격"
  ]
};

window.DB = (() => {
  const KEY = "hireflow_database_v2";

  const initial = {
    applicants: [],
    calendar: [],
    onboarding: [],
    settings: {
      version: 2
    }
  };

  function load() {
    try {
      const raw = localStorage.getItem(KEY);
      if (!raw) return structuredClone(initial);

      const data = JSON.parse(raw);

      return {
        ...structuredClone(initial),
        ...data,
        applicants: Array.isArray(data.applicants) ? data.applicants : [],
        calendar: Array.isArray(data.calendar) ? data.calendar : [],
        onboarding: Array.isArray(data.onboarding) ? data.onboarding : []
      };
    } catch {
      return structuredClone(initial);
    }
  }

  let data = load();

  function save() {
    localStorage.setItem(KEY, JSON.stringify(data));
  }

  function get(key) {
    return data[key] || [];
  }

  function set(key,value) {
    data[key] = value;
    save();
  }

  function today() {
    const d = new Date();
    return [
      d.getFullYear(),
      String(d.getMonth()+1).padStart(2,"0"),
      String(d.getDate()).padStart(2,"0")
    ].join("-");
  }

  function uid() {
    return crypto.randomUUID
      ? crypto.randomUUID()
      : Date.now().toString(36)+Math.random().toString(36).slice(2);
  }

  function esc(value) {
    return String(value ?? "").replace(/[&<>"']/g,char => ({
      "&":"&amp;",
      "<":"&lt;",
      ">":"&gt;",
      '"':"&quot;",
      "'":"&#39;"
    })[char]);
  }

  function modal(html) {
    document.getElementById("modal-content").innerHTML = html;
    document.getElementById("modal").classList.remove("hidden");
  }

  function close() {
    document.getElementById("modal").classList.add("hidden");
    document.getElementById("modal-content").innerHTML = "";
  }

  function download(filename,content,type="text/html;charset=utf-8") {
    const blob = new Blob([content],{type});
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");

    a.href = url;
    a.download = filename;
    a.click();

    setTimeout(() => URL.revokeObjectURL(url),1000);
  }

  function average(values) {
    if (!values.length) return 0;
    return Math.round(values.reduce((a,b)=>a+b,0)/values.length);
  }

  function number(value) {
    const n = Number(value);
    return Number.isFinite(n) ? n : 0;
  }

  function reset() {
    data = structuredClone(initial);
    save();
  }

  return {
    get,set,save,today,uid,esc,
    modal,close,download,average,number,reset
  };
})();
