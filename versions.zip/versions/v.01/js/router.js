
window.HireRouter = class {
  constructor(routes, root) {
    this.routes = routes;
    this.root = root;

    document.addEventListener("click", (event) => {
      const link = event.target.closest("[data-link]");

      if (!link) return;

      event.preventDefault();

      const target = link.getAttribute("href");

      if (target && target.startsWith("#")) {
        if (location.hash === target) {
          this.render();
        } else {
          location.hash = target;
        }
      }
    });

    window.addEventListener("hashchange", () => {
      this.render();
      window.scrollTo(0, 0);
    });
  }

  render() {
    const path = location.hash.replace(/^#/, "") || "/";

    const route = this.routes.find(item => item.path === path);

    if (!route) {
      this.root.innerHTML = `
        <div class="card">
          <h1>404</h1>
          <p>요청한 페이지를 찾을 수 없습니다.</p>
          <a href="#/" data-link class="btn">대시보드로 이동</a>
        </div>
      `;
    } else {
      this.root.innerHTML = route.component();
    }

    document.querySelectorAll(".sidebar [data-link]").forEach(link => {
      link.classList.toggle(
        "active",
        link.getAttribute("href") === "#" + path
      );
    });
  }
};
