
const routes = [
  { path: "/", component: HirePages.dashboard },
  ...HirePages.steps.map(step => ({
    path: "/" + step.id,
    component: () => HirePages.processPage(step)
  }))
];

const app = document.getElementById("app");

app.innerHTML = `
  <div class="layout">

    <aside class="sidebar" id="sidebar">
      <div class="logo">HIRE<span>FLOW</span></div>

      <div class="nav-label">WORKSPACE</div>

      <a href="#/" data-link class="nav-link">
        <span>⌂</span> 대시보드
      </a>

      <div class="nav-label">RECRUITMENT PROCESS</div>

      ${HirePages.steps.map((step, index) => `
        <a href="#/${step.id}" data-link class="nav-link">
          <span>${String(index + 1).padStart(2, "0")}</span>
          ${step.title}
        </a>
      `).join("")}

      <div class="nav-label">RESOURCES</div>

      <a href="#/##trends" class="nav-link" data-section="trends">
        HR 트렌드 분석
      </a>

      <a href="#/##principles" class="nav-link" data-section="principles">
        채용 운영 원칙
      </a>
    </aside>

    <main class="main">

      <header class="topbar">
        <div>
          <button class="btn secondary mobile-menu"
            id="mobile-menu">☰ 메뉴</button>
          <span class="breadcrumb">
            HR WORKSPACE / RECRUITMENT
          </span>
        </div>

        <div class="profile">
          HR Administrator
        </div>
      </header>

      <div id="page-content"></div>

      <footer class="footer">
        HIREFLOW · Recruitment Management Guide · 2026
      </footer>

    </main>
  </div>
`;

const router = new HireRouter(
  routes,
  document.getElementById("page-content")
);

// 체크리스트 변경 및 자동 저장
document.addEventListener("change", (event) => {
  if (!event.target.matches(".task-check")) return;

  const stepId = event.target.dataset.step;
  const key = "hireflow-" + stepId;

  const checked = [
    ...document.querySelectorAll(
      `.task-check[data-step="${stepId}"]:checked`
    )
  ].map(input => Number(input.dataset.index));

  localStorage.setItem(key, JSON.stringify(checked));

  const step = HirePages.steps.find(s => s.id === stepId);

  const percent = Math.round(
    checked.length / step.tasks.length * 100
  );

  const progressText = document.getElementById("progress-text");
  const progressBar = document.getElementById("progress-bar");

  if (progressText) {
    progressText.textContent =
      `${checked.length} / ${step.tasks.length} 완료 (${percent}%)`;
  }

  if (progressBar) {
    progressBar.style.width = percent + "%";
  }
});

// 모바일 메뉴
document.getElementById("mobile-menu").addEventListener("click", () => {
  document.getElementById("sidebar").classList.toggle("open");
});

// 모바일에서 메뉴 클릭 시 닫기
document.querySelectorAll(".sidebar [data-link]").forEach(link => {
  link.addEventListener("click", () => {
    document.getElementById("sidebar").classList.remove("open");
  });
});

// 최초 화면 렌더링
router.render();
