
window.HirePages = (() => {

  const steps = [
    {
      id: "planning",
      title: "채용 계획 수립",
      en: "Recruitment Planning",
      desc: "채용 필요성을 분석하고 인력 계획과 직무 요건을 정의합니다.",
      objective: "왜 이 인력을 채용해야 하는가?",
      guide: "채용을 시작하기 전 기존 인력의 재배치 가능성과 업무량을 검토하세요. 채용 목적, 기대 성과, 예산 및 일정을 명확히 정의해야 합니다.",
      tasks: [
        "조직 및 부서별 인력 현황 분석",
        "채용 필요성과 충원 사유 확인",
        "내부 인재 이동 가능성 검토",
        "직무기술서(JD) 및 자격 요건 작성",
        "채용 예산 및 일정 수립",
        "현업 담당자 및 채용 담당자 지정"
      ],
      docs: ["채용 요청서", "직무기술서(JD)", "채용 일정표"],
      kpis: ["채용 승인 소요 기간", "인력 계획 대비 충원율"]
    },
    {
      id: "posting",
      title: "채용 공고 및 모집",
      en: "Job Posting & Sourcing",
      desc: "적합한 인재에게 채용 정보를 전달하고 지원자를 모집합니다.",
      objective: "필요한 역량을 가진 인재에게 공고가 전달되었는가?",
      guide: "학력과 경력 연수만 나열하기보다 실제 수행 업무와 핵심 역량을 중심으로 공고를 작성하세요. 급여, 근무 형태, 채용 절차를 투명하게 공개하면 후보자 경험을 개선할 수 있습니다.",
      tasks: [
        "직무 중심 채용 공고 작성",
        "필수 요건과 우대 요건 구분",
        "급여 및 근무 조건 명시",
        "채용 플랫폼 및 소싱 채널 선정",
        "채용 브랜딩 콘텐츠 준비",
        "지원자 문의 및 모집 현황 관리"
      ],
      docs: ["채용 공고문", "채용 채널 리스트", "소싱 계획서"],
      kpis: ["채널별 지원자 수", "적격 지원자 비율"]
    },
    {
      id: "screening",
      title: "서류 검토 및 지원자 선별",
      en: "Resume Screening",
      desc: "직무 요건과 역량을 중심으로 지원자를 검토합니다.",
      objective: "지원자가 직무 수행에 필요한 역량을 갖추었는가?",
      guide: "직무와 무관한 개인적 특성보다 실제 업무 경험, 프로젝트 성과, 기술 및 문제 해결 역량을 중심으로 평가하세요. AI 요약을 활용하더라도 원본 서류와 평가 근거를 사람이 검토해야 합니다.",
      tasks: [
        "지원서 및 이력서 검토",
        "필수 자격 요건 충족 여부 확인",
        "직무 관련 프로젝트 및 경험 분석",
        "핵심 역량별 평가 기준 적용",
        "평가 근거 및 점수 기록",
        "면접 대상자 선정 및 결과 안내"
      ],
      docs: ["서류 평가표", "지원자 평가 기록", "면접 대상자 명단"],
      kpis: ["서류 검토 소요 시간", "서류 합격률"]
    },
    {
      id: "interview",
      title: "면접 진행",
      en: "Structured Interview",
      desc: "표준화된 질문과 평가 기준으로 후보자를 평가합니다.",
      objective: "실제 업무 환경에서 성과를 낼 수 있는가?",
      guide: "모든 후보자에게 핵심 공통 질문을 적용하고 STAR 기법을 활용하세요. 면접관 개인의 주관적인 인상보다 실제 경험과 구체적인 행동을 평가하는 것이 중요합니다.",
      tasks: [
        "직무별 면접 평가 항목 정의",
        "공통 면접 질문 설계",
        "면접관별 평가 역할 배분",
        "면접 일정 및 후보자 안내",
        "STAR 기반 행동 질문 진행",
        "면접 종료 후 개별 평가 기록"
      ],
      docs: ["면접 질문지", "면접 평가표", "면접 결과 기록"],
      kpis: ["면접 합격률", "면접관 평가 일관성"]
    },
    {
      id: "assessment",
      title: "직무 역량 평가",
      en: "Skills Assessment",
      desc: "실제 업무와 유사한 과제로 직무 수행 역량을 검증합니다.",
      objective: "실제 수행 능력을 객관적으로 확인했는가?",
      guide: "과제는 실제 직무와 관련성이 있어야 합니다. 평가 루브릭을 사전에 정의하고 과도한 무상 노동을 요구하지 않도록 설계하세요.",
      tasks: [
        "직무별 핵심 역량 정의",
        "실무 과제 및 테스트 설계",
        "평가 기준과 채점 루브릭 작성",
        "후보자에게 과제 조건 안내",
        "과제 결과 및 수행 과정 평가",
        "면접 및 역량 평가 결과 종합"
      ],
      docs: ["직무 과제", "역량 평가표", "종합 평가 기록"],
      kpis: ["과제 수행률", "직무 역량 평가 점수"]
    },
    {
      id: "decision",
      title: "최종 합격자 선정",
      en: "Final Decision",
      desc: "평가 결과를 종합하고 최종 후보자와 처우를 결정합니다.",
      objective: "일관된 평가 근거를 바탕으로 결정했는가?",
      guide: "최종 결정은 사전에 합의한 직무 역량과 평가 기록을 근거로 내려야 합니다. 평가자 간 의견이 다르면 구체적인 행동과 증거를 중심으로 논의하세요.",
      tasks: [
        "서류 및 면접 평가 결과 종합",
        "직무 역량 평가 결과 확인",
        "면접관 간 평가 의견 조율",
        "최종 후보자 선정 및 승인",
        "필요한 검증 및 레퍼런스 체크",
        "처우 협의 및 오퍼레터 전달",
        "불합격자 결과 안내"
      ],
      docs: ["최종 평가표", "합격 승인 기록", "오퍼레터"],
      kpis: ["오퍼 수락률", "채용 소요 기간"]
    },
    {
      id: "onboarding",
      title: "입사 및 온보딩",
      en: "Onboarding",
      desc: "신규 입사자의 조직 적응과 초기 업무 수행을 지원합니다.",
      objective: "신규 입사자가 조직과 업무에 안정적으로 적응했는가?",
      guide: "온보딩은 입사 당일로 끝나지 않습니다. 30·60·90일 단위로 업무 목표와 적응 현황을 확인하고 필요한 지원을 제공하세요.",
      tasks: [
        "입사 서류 및 근로계약 준비",
        "계정 및 업무 장비 세팅",
        "조직 및 직무 소개",
        "버디 또는 멘토 지정",
        "30일 업무 적응 목표 수립",
        "30·60·90일 적응 현황 확인",
        "신규 입사자 피드백 수집"
      ],
      docs: ["입사 체크리스트", "온보딩 계획서", "수습 평가 기록"],
      kpis: ["온보딩 완료율", "초기 적응 만족도"]
    }
  ];

  function savedTasks(id) {
    try {
      return JSON.parse(localStorage.getItem("hireflow-" + id) || "[]");
    } catch {
      return [];
    }
  }

  function processCard(step, index) {
    const saved = savedTasks(step.id);
    const percent = Math.round(saved.length / step.tasks.length * 100);

    return `
      <a href="#/${step.id}" data-link class="process-card">
        <span class="step-number">STEP 0${index + 1}</span>
        <h3>${step.title}</h3>
        <p>${step.desc}</p>
        <div class="progress">
          <div class="progress-bar" style="width:${percent}%"></div>
        </div>
        <span class="tag">${percent}% 완료</span>
      </a>
    `;
  }

  function dashboard() {
    const totalTasks = steps.reduce((sum, s) => sum + s.tasks.length, 0);
    const completed = steps.reduce((sum, s) => sum + savedTasks(s.id).length, 0);
    const percent = Math.round(completed / totalTasks * 100);

    return `
      <h1>Recruitment Dashboard</h1>
      <p class="subtitle">
        체계적인 인재 확보를 위한 채용 프로세스 통합 관리
      </p>

      <div class="stats-grid">
        <div class="card">
          <div class="stat-label">TOTAL PROCESS</div>
          <div class="stat-value">07</div>
          <div class="stat-note">채용 전체 단계</div>
        </div>
        <div class="card">
          <div class="stat-label">CHECKLIST PROGRESS</div>
          <div class="stat-value">${percent}%</div>
          <div class="stat-note">${completed} / ${totalTasks}개 완료</div>
        </div>
        <div class="card">
          <div class="stat-label">HR FRAMEWORK</div>
          <div class="stat-value">2026</div>
          <div class="stat-note">최신 HR 트렌드 반영</div>
        </div>
      </div>

      <div class="section-header">
        <h2>Recruitment Process</h2>
        <span class="tag">7 STEPS</span>
      </div>

      <div class="process-grid">
        ${steps.map(processCard).join("")}
      </div>

      <div class="section-header" id="trends">
        <h2>2026 HR Trends</h2>
        <span class="tag green">TREND INSIGHT</span>
      </div>

      <div class="trend-grid">
        <div class="trend-card">
          <span class="tag">TREND 01</span>
          <h3 style="margin-top:13px">AI-Assisted Recruitment</h3>
          <p>AI를 활용한 채용 공고 작성, 문서 요약, 일정 관리. 중요한 평가와 최종 판단은 사람이 수행합니다.</p>
        </div>
        <div class="trend-card">
          <span class="tag">TREND 02</span>
          <h3 style="margin-top:13px">Skills-Based Hiring</h3>
          <p>학력과 직함보다 실제 직무 역량, 프로젝트 경험, 문제 해결 능력을 중심으로 평가합니다.</p>
        </div>
        <div class="trend-card">
          <span class="tag">TREND 03</span>
          <h3 style="margin-top:13px">Structured Interview</h3>
          <p>표준 질문, 명확한 평가 루브릭, 면접관 간 평가 일관성을 확보합니다.</p>
        </div>
        <div class="trend-card">
          <span class="tag">TREND 04</span>
          <h3 style="margin-top:13px">Candidate Experience</h3>
          <p>지원부터 결과 통보까지 투명하고 신속한 커뮤니케이션을 제공합니다.</p>
        </div>
        <div class="trend-card">
          <span class="tag">TREND 05</span>
          <h3 style="margin-top:13px">Internal Mobility</h3>
          <p>외부 채용에 앞서 조직 내부의 인재와 재배치 가능성을 검토합니다.</p>
        </div>
        <div class="trend-card">
          <span class="tag">TREND 06</span>
          <h3 style="margin-top:13px">Data-Driven HR</h3>
          <p>채용 소요 기간, 채널별 전환율, 오퍼 수락률 등을 분석해 채용 전략을 개선합니다.</p>
        </div>
      </div>

      <div class="section-header" id="principles">
        <h2>Recruitment Operating Principles</h2>
      </div>

      <div class="card">
        <table>
          <thead>
            <tr>
              <th>운영 원칙</th>
              <th>실무 적용 기준</th>
            </tr>
          </thead>
          <tbody>
            <tr><td>공정성</td><td>직무 관련 평가 기준을 모든 후보자에게 일관되게 적용</td></tr>
            <tr><td>투명성</td><td>채용 일정, 조건 및 결과를 명확하게 안내</td></tr>
            <tr><td>데이터 기반</td><td>평가 근거와 채용 성과 지표를 기록하고 분석</td></tr>
            <tr><td>Human + AI</td><td>AI는 업무 보조에 활용하고 중요한 판단은 사람이 수행</td></tr>
            <tr><td>개인정보 보호</td><td>지원자 정보를 적법한 목적과 범위 내에서 관리</td></tr>
          </tbody>
        </table>
      </div>
    `;
  }

  function processPage(step) {
    const index = steps.indexOf(step);
    const saved = savedTasks(step.id);
    const percent = Math.round(saved.length / step.tasks.length * 100);

    return `
      <h1>${step.title}</h1>
      <p class="subtitle">${step.en} · ${step.desc}</p>

      <div class="stats-grid">
        <div class="card">
          <div class="stat-label">PROCESS STEP</div>
          <div class="stat-value">0${index + 1} / 07</div>
          <span class="tag">채용 프로세스</span>
        </div>
        <div class="card">
          <div class="stat-label">CHECKLIST PROGRESS</div>
          <div class="stat-value">${percent}%</div>
          <span class="tag green">${saved.length}/${step.tasks.length} 완료</span>
        </div>
        <div class="card">
          <div class="stat-label">CORE OBJECTIVE</div>
          <p style="line-height:1.7;font-weight:600">${step.objective}</p>
        </div>
      </div>

      <div class="section-header">
        <h2>단계별 실무 가이드</h2>
        <span class="tag green">HR GUIDE</span>
      </div>

      <div class="guide-box">${step.guide}</div>

      <div class="card">
        <div class="section-header" style="margin-top:0">
          <h2>실무 체크리스트</h2>
          <span class="tag">AUTO SAVE</span>
        </div>

        <div class="progress-text" id="progress-text">
          ${saved.length} / ${step.tasks.length} 완료 (${percent}%)
        </div>

        <div class="progress">
          <div class="progress-bar" id="progress-bar" style="width:${percent}%"></div>
        </div>

        <ul class="checklist">
          ${step.tasks.map((task, i) => `
            <li>
              <input
                type="checkbox"
                class="task-check"
                data-step="${step.id}"
                data-index="${i}"
                ${saved.includes(i) ? "checked" : ""}
              >
              <span>${task}</span>
            </li>
          `).join("")}
        </ul>
      </div>

      <div class="card">
        <h2>핵심 성과 지표 (KPI)</h2>
        ${step.kpis.map(kpi => `
          <div style="padding:12px 0;border-bottom:1px solid var(--border)">
            ✓ ${kpi}
          </div>
        `).join("")}
      </div>

      <div class="card">
        <h2>필수 산출물</h2>
        <div class="trend-grid">
          ${step.docs.map((doc, i) => `
            <div class="trend-card">
              <span class="tag">DOCUMENT 0${i+1}</span>
              <h3 style="margin-top:13px">${doc}</h3>
              <p>해당 단계에서 준비하고 관리해야 하는 핵심 문서입니다.</p>
            </div>
          `).join("")}
        </div>
      </div>

      <div class="page-nav">
        <a class="btn secondary"
           href="${index === 0 ? '#/' : '#/' + steps[index - 1].id}"
           data-link>← 이전 단계</a>

        <a class="btn"
           href="${index === steps.length - 1 ? '#/' : '#/' + steps[index + 1].id}"
           data-link>
           ${index === steps.length - 1 ? '대시보드 →' : '다음 단계 →'}
        </a>
      </div>
    `;
  }

  return {
    steps,
    dashboard,
    processPage
  };

})();
